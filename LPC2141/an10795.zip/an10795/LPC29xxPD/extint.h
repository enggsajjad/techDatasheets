/*****************************************************************************
 *   extint.h:  Header file for NXP LPC29xx Family Microprocessors
 *
 *   Copyright(C) 2007, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2007.09.01  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#ifndef __EXTINT_H 
#define __EXTINT_H

// select a external interrupt number for sleep and wakeup (0-7)
// MCB2900 from keil uses 4 and 5
#define EXINT_sleep 4
#define EXINT_wake 5

extern void EventRouter_Handler(void);
extern void EventRouter_Init( void );

#endif /* end __EXTINT_H */
/*****************************************************************************
**                            End Of File
******************************************************************************/

#include <LPC214x.H> 

#include "global.h"


WORD forward  = 0;                                 // DALI forward frame
BYTE answer   = 0;                                 // DALI slave answer
BYTE f_dalitx = 0;
BYTE f_dalirx = 0;


void GetInReport(BYTE *rep)                        // USB host is asking for an InReport
{
    if (f_dalirx)                                  // answer from slave received ?
    {
        rep[0] = 1;                                // send answer
        rep[1] = answer;
    }
    else
        rep[0] = 0;                                // no answer
}

void SetOutReport(BYTE *rep)                       // OutReport received from USB host
{
    forward = (rep[0] << 8) | rep[1];
    f_dalitx = 1;                                  // set DALI send flag
}

int main(void)
{
    USB_Init();                                    // USB Initialization
    USB_Connect(TRUE);                             // USB Connect
    DALI_Init();
	    
    while (1)
    {
        if (f_dalitx)                              // flag set from USB or the DALI module
        {
            f_dalitx = 0;                          // clear DALI send flag
            f_dalirx = 0;                          // clear DALI receive (answer) flag
            DALI_Send();                           // DALI send data to slave(s)
        }   
    }
}

/********************************************************************
;
;  DALI master
;
;  For transmit, this module uses GPIO - P0.28 (DALI send pin)
;  DALI forward frame format:
;
;      | S |        8 address bits         |        8 command bits         | stop  |
;      | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |   |   |
;
;   ---+ +-+ +---+ +-+ +-+ +-+ +-+   +-+ +---+   +-+ +-+ +-+ +---+ +-+ +-+ +------------
;      | | | |   | | | | | | | | |   | | |   |   | | | | | | |   | | | | | |
;      +-+ +-+   +-+ +-+ +-+ +-+ +---+ +-+   +---+ +-+ +-+ +-+   +-+ +-+ +-+
;
;      |2TE|2TE|2TE|2TE|2TE|2TE|2TE|2TE|2TE|2TE|2TE|2TE|2TE|2TE|2TE|2TE|2TE|  4TE  |
;
;
;  For receive, this module uses T0-CAP0 input (capture and interrupt on both edges)
;  CAP0.0 (P0.30) is connected to P0.29 (to check high / low level by software)
;  DALI slave backward frame format:
;
;                    | S |         8 data bits           | stop  |
;                    | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |   |   |
;
;    +---------------+ +-+ +---+ +-+ +-+ +-+ +-+   +-+ +-------------
;    |               | | | |   | | | | | | | | |   | | |
;   -+               +-+ +-+   +-+ +-+ +-+ +-+ +---+ +-+
;
;    |4 + 7 to 22 TE |2TE|2TE|2TE|2TE|2TE|2TE|2TE|2TE|2TE|  4TE  |
;
;  2TE = 834 usec (1200 bps)
;
*******************************************************************************************/

#include <LPC214x.h>                               // LPC21xx definitions

#include "global.h"

#define INITIALISE     0xA500                      // command for starting initialization mode
#define RANDOMISE      0xA700                      // command for generating a random address

#define TE             834/2                       // half bit time = 417 usec
#define MIN_TE         TE - 60                     // minimum half bit time
#define MAX_TE         TE + 60                     // maximum half bit time
#define MIN_2TE        2*TE - 60                   // minimum full bit time
#define MAX_2TE        2*TE + 60                   // maximum full bit time

static int  low_time;                              // captured puls low time
static int  high_time;                             // captured puls high time

static BYTE value;                                 // used for dali send bit
static BYTE position;                              // keeps track of sending bit position
static BYTE previous;                              // previous received bit
static WORD frame;                                 // holds the received slave backward frame
static BYTE f_repeat;                              // flag command shall be repeated
static BYTE f_busy;                                // flag DALI transfer busy


static void DALI_Shift_Bit(BYTE val)
{
    if (frame & 0x100)                             // frame full ?
        frame = 0;                                 // yes, ERROR
    else
        frame = (frame << 1) | val;                // shift bit
}

/************************************************************************
; DALI_Decode (we only take action at a rising edge)
;
; Half(prev) Bit   Low Time        High Time      Action     New Half Bit
; -------------------------------------------------------------------
;     0               0               0          Shift 0         0
;     0               0               1          -ERROR-         *
;     0               1               0          Shift 0,1       1
;     0               1               1          -ERROR-         *
;     1               0               0          Shift 1         1
;     1               0               1          Shift 0         0
;     1               1               0          -ERROR-         *
;     1               1               1          Shift 0,1       1
;
***********************************************************************/
static void DALI_Decode(void)
{
  BYTE action;

    action = previous << 2;

    if ((high_time > MIN_2TE) && (high_time < MAX_2TE))
        action = action | 1;                       // high_time = long
    else if (!((high_time > MIN_TE) && (high_time < MAX_TE)))
    {
        frame = 0;                                 // DALI ERROR
        return;
    }

    if ((low_time > MIN_2TE) && (low_time < MAX_2TE))
        action = action | 2;                       // low_time = long
    else if (!((low_time > MIN_TE) && (low_time < MAX_TE)))
    {
        frame = 0;                                 // DALI ERROR
        return;
    }

    switch (action)
    {
      case 0:  DALI_Shift_Bit(0);                  // short low, short high, shift 0
               break;
      case 1:  frame = 0;                          // short low, long high, ERROR
               break;
      case 2:  DALI_Shift_Bit(0);                  // long low, short high, shift 0,1
               DALI_Shift_Bit(1);
               previous = 1;                       // new half bit is 1
               break;
      case 3:  frame = 0;                          // long low, long high, ERROR
               break;
      case 4:  DALI_Shift_Bit(1);                  // short low, short high, shift 1
               break;
      case 5:  DALI_Shift_Bit(0);                  // short low, long high, shift 0
               previous = 0;                       // new half bit is 0
               break;
      case 6:  frame = 0;                          // long low, short high, ERROR
               break;
      case 7:  DALI_Shift_Bit(0);                  // long low, long high, shift 0,1
               DALI_Shift_Bit(1);
      default: break;                              // invalid
    }
}

__irq void DALI_Isr(void)
{
    T0TC = 0;                                      // reset timer

    if (T0IR & 1)                                  // match 0 interrupt for DALI send
    {
        if (value)
            IOSET0 |= 0x10000000;                  // DALI output pin high
        else
            IOCLR0 |= 0x10000000;                  // DALI output pin low

        if (position == 0)                         // 0TE second half of start bit = 1
        {
		    value = 1;
        }
        else if (position < 33)                    // 1TE - 32TE, so address + command
        {
            value = (forward >> ((32 - position)/2)) & 1;
            if (position & 1)
                value = !value;                    // invert if first half of data bit
        }
        else if (position == 33)                   // 33TE start of stop bit (4TE)
        {                                          // and start of minimum settling time (7TE)
		    value = 1;
        }
        else if (position == 44)                   // 44TE, end of stopbits and settling time
        {
		    T0MR0 = 9174;                          // receive slave answer, timeout of 22TE = 9,174 msec
            T0CCR = 0x0007;                        // enable receive, capture on both edges
        }
        else if (position == 45)                   // end of transfer
		{
		    T0TCR = 2;                             // stop and reset timer
            if (frame & 0x100)                     // backward frame (answer) completed ?
            {
                 answer = (BYTE)frame;             // OK ! save answer
                 f_dalirx = 1;                     // and set flag to signal application
            }
            frame  = 0;                            // reset receive frame
            f_busy = 0;                            // end of transmission
            if (f_repeat)                          // repeat forward frame ?
                f_dalitx = 1;                      // yes, set flag to signal application
        }
        position++;
        T0IR = 0x01;                               // clear MR0 interrupt flag
    }
    else                                           // capture interrupt for DALI receive
    {
        if (IO0PIN & 0x20000000)                   // P0.29 = P0.30 to check rising or falling edge
        {
            if (frame != 0)                        // not first pulse ?
            {
                low_time = T0CR0;                  // rising, so capture low time
                DALI_Decode();                     // decode received bit
            }
            else
            {
                previous = 1;                      // first pulse, so shift 1
                DALI_Shift_Bit(1);
            }
        }
        else
            high_time = T0CR0;                     // falling, so capture high time

        T0IR = 0x10;                               // reset interrupt flag
    }
    VICVectAddr = 0;                               // Acknowledge interrupt by reseting VIC
}

void DALI_Send(void)
{
    if (f_repeat)                                  // repeat last command ?
    {
        f_repeat = 0;
    }
    else if ((forward & 0xE100) == 0xA100 || (forward & 0xE100) == 0xC100)
    {
        if ((forward & 0xFF00) == INITIALISE || forward == RANDOMISE)
        {
            f_repeat = 1;                          // special command shall be repeated within 100 ms
        }
    }
    else if ((forward & 0x1FF) >= 0x120 && (forward & 0x1FF) <= 0x180)
    {
        f_repeat = 1;                              // configuration command shall be repeated within 100 ms
    }

    while (f_busy) ;                               // Wait until dali port is idle

    frame    = 0;
    value    = 0;                                  // first half of start bit = 0
    position = 0;
    f_busy   = 1;                                  // Activate the timer module to transfer

    T0MR0 = TE;                                    // ~ 2400 Hz
    T0CCR = 0x0000;                                // disable capture interrupt
    T0MCR = 0x0003;                                // interrupt on MR0, reset timer on match 0
    T0TC  = 0;                                     // reset timer
    T0TCR = 1;                                     // enable timer
}

void DALI_Init(void)
{
    VICVectAddr1  = (LONG) &DALI_Isr;
    VICVectCntl1  = 0x24;                          // channel0 on Source#4 ... enabled
    VICIntEnable |= 0x10;                          // channel#4 is the Timer 0

	IODIR0  |= 0x10000000;                         // P0.28 = DALI send pin
	IOSET0  |= 0x10000000;
    PINSEL1 |= 0x30000000;                         // P0.30 as CAP0.0 = DALI receive pin

    T0PR  = 60;                                    // prescaler timer runs at 60 MHz / 60 = 1 MHz
}

// Global definitions

#define NULL    ((void *)0)
#define FALSE   (0)
#define TRUE    (1)

typedef unsigned char  BYTE;
typedef unsigned short WORD;
typedef unsigned long  LONG;
typedef unsigned int   BOOL;

extern WORD forward;
extern BYTE answer;
extern BYTE f_dalitx;
extern BYTE f_dalirx;

extern void GetInReport(BYTE *rep);
extern void SetOutReport(BYTE *rep);
extern void USB_Init(void);
extern void USB_Connect(BOOL con);

extern void DALI_Init(void);
extern void DALI_Send(void);

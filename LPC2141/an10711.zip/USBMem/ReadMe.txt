This is a USB Memory Device demonstration for
the Keil MCB2140 Board with Philips LPC2148.

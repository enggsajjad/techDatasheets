﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DataLogForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DataLogForm))
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel
        Me.ButtonClear = New System.Windows.Forms.Button
        Me.ButtonAdd = New System.Windows.Forms.Button
        Me.TextBoxSeparator = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.ButtonStart = New System.Windows.Forms.Button
        Me.ButtonSelectFile = New System.Windows.Forms.Button
        Me.TextBoxLogFilePath = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(15, 94)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(534, 136)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'ButtonClear
        '
        Me.ButtonClear.Location = New System.Drawing.Point(78, 65)
        Me.ButtonClear.Name = "ButtonClear"
        Me.ButtonClear.Size = New System.Drawing.Size(57, 23)
        Me.ButtonClear.TabIndex = 1
        Me.ButtonClear.Text = "Delete"
        Me.ButtonClear.UseVisualStyleBackColor = True
        Me.ButtonClear.Visible = False
        '
        'ButtonAdd
        '
        Me.ButtonAdd.Location = New System.Drawing.Point(15, 65)
        Me.ButtonAdd.Name = "ButtonAdd"
        Me.ButtonAdd.Size = New System.Drawing.Size(57, 23)
        Me.ButtonAdd.TabIndex = 0
        Me.ButtonAdd.Text = "Add"
        Me.ButtonAdd.UseVisualStyleBackColor = True
        '
        'TextBoxSeparator
        '
        Me.TextBoxSeparator.Location = New System.Drawing.Point(115, 38)
        Me.TextBoxSeparator.Name = "TextBoxSeparator"
        Me.TextBoxSeparator.Size = New System.Drawing.Size(20, 20)
        Me.TextBoxSeparator.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(89, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Column separator"
        '
        'ButtonStart
        '
        Me.ButtonStart.Enabled = False
        Me.ButtonStart.Location = New System.Drawing.Point(474, 11)
        Me.ButtonStart.Name = "ButtonStart"
        Me.ButtonStart.Size = New System.Drawing.Size(75, 23)
        Me.ButtonStart.TabIndex = 5
        Me.ButtonStart.Text = "Start log"
        Me.ButtonStart.UseVisualStyleBackColor = True
        '
        'ButtonSelectFile
        '
        Me.ButtonSelectFile.Location = New System.Drawing.Point(294, 11)
        Me.ButtonSelectFile.Name = "ButtonSelectFile"
        Me.ButtonSelectFile.Size = New System.Drawing.Size(23, 22)
        Me.ButtonSelectFile.TabIndex = 315
        Me.ButtonSelectFile.Text = ".."
        Me.ButtonSelectFile.UseVisualStyleBackColor = True
        '
        'TextBoxLogFilePath
        '
        Me.TextBoxLogFilePath.Enabled = False
        Me.TextBoxLogFilePath.Location = New System.Drawing.Point(12, 12)
        Me.TextBoxLogFilePath.Name = "TextBoxLogFilePath"
        Me.TextBoxLogFilePath.Size = New System.Drawing.Size(278, 20)
        Me.TextBoxLogFilePath.TabIndex = 314
        '
        'DataLogForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(561, 243)
        Me.Controls.Add(Me.ButtonClear)
        Me.Controls.Add(Me.ButtonSelectFile)
        Me.Controls.Add(Me.ButtonAdd)
        Me.Controls.Add(Me.TextBoxLogFilePath)
        Me.Controls.Add(Me.ButtonStart)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBoxSeparator)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "DataLogForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Datalogger"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents TextBoxSeparator As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ButtonStart As System.Windows.Forms.Button
    Friend WithEvents ButtonSelectFile As System.Windows.Forms.Button
    Friend WithEvents TextBoxLogFilePath As System.Windows.Forms.TextBox
    Friend WithEvents ButtonAdd As System.Windows.Forms.Button
    Friend WithEvents ButtonClear As System.Windows.Forms.Button
End Class

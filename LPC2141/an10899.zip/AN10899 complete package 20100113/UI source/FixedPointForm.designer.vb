﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FixedPointForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FixedPointForm))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.NumericTextBoxFractPart = New FOCinterface.NumericTextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.NumericTextBoxIntPart = New FOCinterface.NumericTextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.NumericTextBoxFull = New FOCinterface.NumericTextBox
        Me.NumericTextBoxFP = New FOCinterface.NumericTextBox
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer
        Me.LineShape2 = New Microsoft.VisualBasic.PowerPacks.LineShape
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.CheckBoxSigned = New System.Windows.Forms.CheckBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.TextBoxFract = New FOCinterface.NumericTextBox
        Me.TextBoxInt = New FOCinterface.NumericTextBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.TextBoxCode = New System.Windows.Forms.TextBox
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.NumericTextBoxFractPart)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.NumericTextBoxIntPart)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.NumericTextBoxFull)
        Me.GroupBox1.Controls.Add(Me.NumericTextBoxFP)
        Me.GroupBox1.Controls.Add(Me.ShapeContainer1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 79)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(627, 130)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Conversion"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Image = Global.FOCinterface.My.Resources.Resources.arrows
        Me.PictureBox1.Location = New System.Drawing.Point(99, 30)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(68, 37)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(309, 80)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 13)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "fractional part value"
        '
        'NumericTextBoxFractPart
        '
        Me.NumericTextBoxFractPart.AllowNegative = True
        Me.NumericTextBoxFractPart.AllowSpace = False
        Me.NumericTextBoxFractPart.Location = New System.Drawing.Point(312, 96)
        Me.NumericTextBoxFractPart.Name = "NumericTextBoxFractPart"
        Me.NumericTextBoxFractPart.Size = New System.Drawing.Size(70, 20)
        Me.NumericTextBoxFractPart.TabIndex = 20
        Me.NumericTextBoxFractPart.Text = "6"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(309, 23)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(89, 13)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "integer part value"
        '
        'NumericTextBoxIntPart
        '
        Me.NumericTextBoxIntPart.AllowNegative = True
        Me.NumericTextBoxIntPart.AllowSpace = False
        Me.NumericTextBoxIntPart.Location = New System.Drawing.Point(312, 39)
        Me.NumericTextBoxIntPart.Name = "NumericTextBoxIntPart"
        Me.NumericTextBoxIntPart.Size = New System.Drawing.Size(70, 20)
        Me.NumericTextBoxIntPart.TabIndex = 18
        Me.NumericTextBoxIntPart.Text = "6"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(182, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = ".full value"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 13)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Fixed point value"
        '
        'NumericTextBoxFull
        '
        Me.NumericTextBoxFull.AllowNegative = True
        Me.NumericTextBoxFull.AllowSpace = False
        Me.NumericTextBoxFull.Location = New System.Drawing.Point(185, 39)
        Me.NumericTextBoxFull.Name = "NumericTextBoxFull"
        Me.NumericTextBoxFull.Size = New System.Drawing.Size(70, 20)
        Me.NumericTextBoxFull.TabIndex = 15
        Me.NumericTextBoxFull.Text = "6"
        '
        'NumericTextBoxFP
        '
        Me.NumericTextBoxFP.AllowNegative = False
        Me.NumericTextBoxFP.AllowSpace = False
        Me.NumericTextBoxFP.Location = New System.Drawing.Point(9, 39)
        Me.NumericTextBoxFP.Name = "NumericTextBoxFP"
        Me.NumericTextBoxFP.Size = New System.Drawing.Size(70, 20)
        Me.NumericTextBoxFP.TabIndex = 14
        Me.NumericTextBoxFP.Text = "0"
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(3, 16)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.LineShape2, Me.LineShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(621, 111)
        Me.ShapeContainer1.TabIndex = 23
        Me.ShapeContainer1.TabStop = False
        '
        'LineShape2
        '
        Me.LineShape2.Name = "LineShape2"
        Me.LineShape2.X1 = 257
        Me.LineShape2.X2 = 303
        Me.LineShape2.Y1 = 33
        Me.LineShape2.Y2 = 89
        '
        'LineShape1
        '
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 257
        Me.LineShape1.X2 = 304
        Me.LineShape1.Y1 = 33
        Me.LineShape1.Y2 = 33
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.CheckBoxSigned)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.TextBoxFract)
        Me.GroupBox2.Controls.Add(Me.TextBoxInt)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(627, 67)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Definition"
        '
        'CheckBoxSigned
        '
        Me.CheckBoxSigned.AutoSize = True
        Me.CheckBoxSigned.Location = New System.Drawing.Point(9, 19)
        Me.CheckBoxSigned.Name = "CheckBoxSigned"
        Me.CheckBoxSigned.Size = New System.Drawing.Size(61, 17)
        Me.CheckBoxSigned.TabIndex = 10
        Me.CheckBoxSigned.Text = "'signed'"
        Me.CheckBoxSigned.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(69, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Fractional bits"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(69, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Integer bits"
        '
        'TextBoxFract
        '
        Me.TextBoxFract.AllowNegative = True
        Me.TextBoxFract.AllowSpace = False
        Me.TextBoxFract.Location = New System.Drawing.Point(147, 43)
        Me.TextBoxFract.Name = "TextBoxFract"
        Me.TextBoxFract.Size = New System.Drawing.Size(21, 20)
        Me.TextBoxFract.TabIndex = 7
        Me.TextBoxFract.Text = "10"
        '
        'TextBoxInt
        '
        Me.TextBoxInt.AllowNegative = True
        Me.TextBoxInt.AllowSpace = False
        Me.TextBoxInt.Location = New System.Drawing.Point(147, 17)
        Me.TextBoxInt.Name = "TextBoxInt"
        Me.TextBoxInt.Size = New System.Drawing.Size(21, 20)
        Me.TextBoxInt.TabIndex = 6
        Me.TextBoxInt.Text = "6"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.TextBoxCode)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 215)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(627, 336)
        Me.GroupBox3.TabIndex = 17
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Code Generator"
        '
        'TextBoxCode
        '
        Me.TextBoxCode.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBoxCode.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxCode.Location = New System.Drawing.Point(3, 16)
        Me.TextBoxCode.Multiline = True
        Me.TextBoxCode.Name = "TextBoxCode"
        Me.TextBoxCode.Size = New System.Drawing.Size(621, 317)
        Me.TextBoxCode.TabIndex = 4
        '
        'FixedPointForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(651, 563)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FixedPointForm"
        Me.Text = "Fixed Point Tool"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents NumericTextBoxFractPart As NumericTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents NumericTextBoxIntPart As NumericTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents NumericTextBoxFull As NumericTextBox
    Friend WithEvents NumericTextBoxFP As NumericTextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBoxFract As NumericTextBox
    Friend WithEvents TextBoxInt As NumericTextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBoxCode As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents LineShape2 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents CheckBoxSigned As System.Windows.Forms.CheckBox

End Class

/***********************************************************************
 * $Id$
 *
 * Project: NXP LPC1850 LCD example.
 *
 * Description: Main application.
 *
 * Copyright(C) 2011, NXP Semiconductor
 * All rights reserved.
 *
 ***********************************************************************
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 **********************************************************************/
#include "LPC18xx.h"
#include "config.h"
#include "EMC.h"
#include "timer.h"
#include "type.h"
#include "lcd_params.h"
#include "lcd_driver.h"
#include "lpc_swim.h"
#include "lcd_type.h"

/* The Hitex LPC18xx Evaluation board contains a 64Mb SDRAM with a 
   16-bit data bus */
#define SDRAM_BASE_ADDR			LCD_FRAME_BUF
#define SDRAM_SIZE_BYTES		(1024UL * 1024UL * 8UL)
#define SDRAM_WIDTH				EMC_SDRAM_WIDTH_16_BITS
#define SDRAM_SIZE_MBITS		EMC_SDRAM_SIZE_64_MBITS
#define SDRAM_DATA_BUS_BITS		EMC_SDRAM_DATA_BUS_16_BITS			
#define SDRAM_COL_ADDR_BITS		8		

/**********************************************************************
 ** Function prototypes
 **********************************************************************/
extern void lcd_colorbars(void);

/**********************************************************************
 ** Local variables
 **********************************************************************/
static int32_t dev_lcd;

/**********************************************************************
 ** Function name:
 **
 ** Description:
 **
 ** Parameters:
 **
 ** Returned value:
 **********************************************************************/
int main (void)
{
	SystemInit();

#if USE_XTAL // Select XTAL or IRC in config.h
 	/* Set the XTAL oscillator frequency to 12MHz*/
	SetClock(XTAL, (CLKSRC_Type)XTAL_FREQ, DIV1); 
	/* Set PL160M */
	SetPL160M(SRC_XTAL, 7); 							
	/* Run base M3 clock from PL160M, no division */
	SetClock(BASE_M3_CLK, SRC_PL160M_0, DIV1);		
	/* Show base out clock on output */
	SetClock(BASE_OUT_CLK, SRC_XTAL, DIV1);			
#else // USE IRC
	/* Set PL160M */
	SetPL160M(SRC_IRC, 6);							
	/* Run base M3 clock from PL160M, div by 1 = no division */
	SetClock(BASE_M3_CLK, SRC_PL160M_0, DIV1);
	/* Show base out clock on output */
	SetClock(BASE_OUT_CLK, SRC_IRC, DIV1);			
#endif

	SetClock(BASE_LCD_CLK, SRC_PL160M_0, DIV1);

	/* Configure the external memory controller for SDRAM */
	vEMC_InitSRDRAM(SDRAM_BASE_ADDR, SDRAM_WIDTH, SDRAM_SIZE_MBITS, SDRAM_DATA_BUS_BITS, SDRAM_COL_ADDR_BITS);

	/* 84 MHz / 840,000 ticks = 10 Hz */
	(void)u32Timer_Init(0, 0, 8400000UL);	
	vTimer_Enable(0);
					 	
  	/* Enable LCD interrupts */  
  	NVIC_EnableIRQ(LCD_IRQn);

  	/* Open LCD */
  	if ((dev_lcd = lcd_open((int32_t)&LCD_DISPLAY)) == 0x0)
  	{
    	/* Error opening the device */
    	return 0;
  	}

	/* Set LCD display pointer */
  	lcd_ioctl(dev_lcd, LCD_SET_BUFFER, (int32_t)SDRAM_BASE_ADDR);  

  	/* Enable LCD */
  	lcd_ioctl(dev_lcd, LCD_ENABLE, 1);

  	/* Enable CLCDC Interrupt */
  	lcd_ioctl(dev_lcd, LCD_SET_INTERRUPT, CLCDC_LCD_INTERRUPT_FUF);
  	lcd_ioctl(dev_lcd, LCD_SET_INTERRUPT, CLCDC_LCD_INTERRUPT_LNBU);
  	lcd_ioctl(dev_lcd, LCD_SET_INTERRUPT, CLCDC_LCD_INTERRUPT_VCOMP);
  	lcd_ioctl(dev_lcd, LCD_SET_INTERRUPT, CLCDC_LCD_INTERRUPT_MBERROR);

  	/* Turn on LCD */
  	lcd_ioctl(dev_lcd, LCD_PWR_ON, 1);

	/* Display 3 color bars on the lcd display */
  	lcd_colorbars();
	
	while(1);  	
}

/**********************************************************************
 ** Function name:
 **
 ** Description:
 **
 ** Parameters:
 **
 ** Returned value:
 **********************************************************************/
void LCD_IRQHandler(void)
{
	int32_t status;
  
  	status = lcd_ioctl(dev_lcd, LCD_GET_STATUS, LCD_GET_INTERRUPT);

  	if (status & CLCDC_LCD_INTERRUPT_FUF)
  	{
    	lcd_ioctl(dev_lcd, LCD_CLR_INTERRUPT, CLCDC_LCD_INTERRUPT_FUF);
  	}
  	if (status & CLCDC_LCD_INTERRUPT_LNBU)
  	{
    	lcd_ioctl(dev_lcd, LCD_CLR_INTERRUPT, CLCDC_LCD_INTERRUPT_LNBU);
  	}
  	if (status & CLCDC_LCD_INTERRUPT_VCOMP)
  	{
    	lcd_ioctl(dev_lcd, LCD_CLR_INTERRUPT, CLCDC_LCD_INTERRUPT_VCOMP);
  	}
  	if (status & CLCDC_LCD_INTERRUPT_MBERROR)
  	{
    	lcd_ioctl(dev_lcd, LCD_CLR_INTERRUPT, CLCDC_LCD_INTERRUPT_MBERROR);
  	}
}

/**********************************************************************
 **                            End Of File
 **********************************************************************/

/***********************************************************************/
/*  This file is part of the ARM Toolchain package                     */
/*  Copyright KEIL ELEKTRONIK GmbH 2003 - 2006                         */
/***********************************************************************/
/*                                                                     */
/*  FlashDev.C:  Flash Programming Functions adapted                   */
/*               for SST39x3201 (16-bit Bus) on the LPC18xx and        */
/*               LPC43xx board from Hitex							   */
/*                                                                     */
/***********************************************************************/

#include "..\FlashOS.H"        // FlashOS Structures


// Defines
#define M8(adr)  (*((volatile unsigned char  *) (adr)))
#define M16(adr) (*((volatile unsigned short *) (adr)))
#define M32(adr) (*((volatile unsigned long  *) (adr)))

#define STACK_SIZE   64        // Stack Size

// Chip IDs
#define LPC4300_TC2     	0x1906002B
#define LPC1800_V00      	0x1284E02B  
#define LPC1800_V00_MF      0x3AC4E07F

// Flash type defines
#define SHARP_LHF00L28		1	   // NXP eval board
#define SST39VF3201         2	   // Hitex board
#define ATMEL_49BV322D		3	   // NXP validation board
#define MT48LC4M32B2		4	   // NXP eval board for motor



// Parameter definitions

union fsreg 	// Flash Status Register
{                  
  struct b  
  {
    unsigned int q0:1;
    unsigned int q1:1;
    unsigned int q2:1;
    unsigned int q3:1;
    unsigned int q4:1;
    unsigned int q5:1;
    unsigned int q6:1;
    unsigned int q7:1;
  } b;
  unsigned int v;
} fsr;

unsigned long base_adr;


// Function prototypes
void LPC4300TC2_emc_init( void );
void LPC4300TC2_emc_init( void );
void LPC4300TC2_emc_init( void );
int Flash_Identification( void );





/************************************************************************
 * Check if Program/Erase completed
 *    Parameter:      adr:  Block Start Address
 *    Return Value:   0 - OK,  1 - Failed
 ************************************************************************/

int Polling (unsigned long adr) 
{
  unsigned int q6;

  // Check Toggle Bit
  do 
  {
    fsr.v = M16(adr);
    q6 = fsr.b.q6;
    fsr.v = M16(adr);
  } 
  while (fsr.b.q6 != q6);

  return (0);              // Done

}


/************************************************************************
 *  Initialize Flash Programming Functions
 *    Parameter:      adr:  Device Base Address
 *                    clk:  Clock Frequency (Hz)
 *                    fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 ************************************************************************/

int Init (unsigned long adr, unsigned long clk, unsigned long fnc) 
{	
  	// Check the CHIP_ID register
	chip_id = *(volatile unsigned long *)0x40043200;  
 	
 	switch (chip_id)
 	{
	  	case LPC4300_TC2:    	// any special configuration can go here
								LPC4300TC2_emc_init();
	  							break;
		case LPC1800_V00:       // any special configuration can go here
	  							LPC1800V00_emc_init();
								break;
	    case LPC1800_V00_MF:    // any special configuration can go here
	  							LPC1800V00MF_emc_init();
								break;
	  	default:				// any default configuration can go here
	  							break; 	  
	}

    // Check for the flash type
	Flash_Identification();

	base_adr = adr;
  	return (0);
}



/************************************************************************
 *  De-Initialize Flash Programming Functions
 *    Parameter:      fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 ************************************************************************/

int UnInit (unsigned long fnc) 
{
  	return (0);
}



/************************************************************************
 *  Erase complete Flash Memory
 *    Return Value:   0 - OK,  1 - Failed
 ************************************************************************/

int EraseChip (void) 
{

  // Start Chip Erase Command
  M16(base_adr + (0x5555 << 1)) = 0x00AA;
  M16(base_adr + (0x2AAA << 1)) = 0x0055;
  M16(base_adr + (0x5555 << 1)) = 0x0080;
  M16(base_adr + (0x5555 << 1)) = 0x00AA;
  M16(base_adr + (0x2AAA << 1)) = 0x0055;
  M16(base_adr + (0x5555 << 1)) = 0x0010;

  return (Polling(base_adr));  // Wait until Erase completed
}


/************************************************************************
 *  Erase Sector in Flash Memory
 *    Parameter:      adr:  Sector Address
 *    Return Value:   0 - OK,  1 - Failed
 ************************************************************************/

int EraseSector (unsigned long adr) 
{

  // Start Erase Sector Command
  M16(base_adr + (0x5555 << 1)) = 0x00AA;
  M16(base_adr + (0x2AAA << 1)) = 0x0055;
  M16(base_adr + (0x5555 << 1)) = 0x0080;
  M16(base_adr + (0x5555 << 1)) = 0x00AA;
  M16(base_adr + (0x2AAA << 1)) = 0x0055;
  M16(adr) = 0x0030;

  return (Polling(adr));       // Wait until Erase completed
}


/************************************************************************
 *  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 ************************************************************************/

int ProgramPage (unsigned long adr, unsigned long sz, unsigned char *buf) 
{
  int i;

  for (i = 0; i < ((sz+1)/2); i++)  
  {
	// Start Program Command
    M16(base_adr + (0x5555 << 1)) = 0x00AA;
    M16(base_adr + (0x2AAA << 1)) = 0x0055;
    M16(base_adr + (0x5555 << 1)) = 0x00A0;
    M16(adr) = *((unsigned short *) buf);
    if (Polling(adr) != 0) return (1);
    buf += 2;
    adr += 2;
  }
  return (0);
}


/************************************************************************
 *  Initialise the external memory controller in LPC43xx
 *    
 ************************************************************************/
void LPC4300TC2_emc_init( void )
{
  // Set all EMI related pins to the correct function (or at least the ones 
  // which have not been set by the bootcode)
  scu_pinmux(0x01, 7, MD_PLN, FUNC0);    	// P1_7: D0 (function 0) 
  scu_pinmux(0x01, 8, MD_PLN, FUNC0);  		// P1_8: D1 (function 0) 
  scu_pinmux(0x01, 9, MD_PLN, FUNC0);  		// P1_9: D2 (function 0) 
  scu_pinmux(0x01, 10, MD_PLN, FUNC0);  	// P1_10: D3 (function 0) 
  scu_pinmux(0x01, 11, MD_PLN, FUNC0);  	// P1_11: D4 (function 0) 
  scu_pinmux(0x01, 12, MD_PLN, FUNC0);  	// P1_12: D5 (function 0) 
  scu_pinmux(0x01, 13, MD_PLN, FUNC0);  	// P1_13: D6 (function 0) 
  scu_pinmux(0x01, 14, MD_PLN, FUNC0);  	// P1_14: D7 (function 0) 
  scu_pinmux(0x05, 0, MD_PLN, FUNC0);  		// P5_0: D12 (function 0) 
  scu_pinmux(0x05, 1, MD_PLN, FUNC0);  		// P5_1: D13 (function 0) 
  scu_pinmux(0x05, 2, MD_PLN, FUNC0);  		// P5_2: D14 (function 0) 
  scu_pinmux(0x05, 3, MD_PLN, FUNC0);  		// P5_3: D15 (function 0) 
  scu_pinmux(0x05, 4, MD_PLN, FUNC0);  		// P5_4: D8 (function 0) 
  scu_pinmux(0x05, 5, MD_PLN, FUNC0);  		// P5_5: D9 (function 0) 
  scu_pinmux(0x05, 6, MD_PLN, FUNC0);  		// P5_6: D10 (function 0) 
  scu_pinmux(0x05, 7, MD_PLN, FUNC0);  		// P5_7: D11 (function 0) 
  scu_pinmux(0x0D, 2, MD_PLN, FUNC0);  		// PD_2: D16 (function 0) 
  scu_pinmux(0x0D, 3, MD_PLN, FUNC0);  		// PD_3: D17 (function 0) 
  scu_pinmux(0x0D, 4, MD_PLN, FUNC0);  		// PD_4: D18 (function 0) 
  scu_pinmux(0x0D, 5, MD_PLN, FUNC0);  		// PD_5: D19 (function 0) 
  scu_pinmux(0x0D, 6, MD_PLN, FUNC0);  		// PD_6: D20 (function 0) 
  scu_pinmux(0x0D, 7, MD_PLN, FUNC0);  		// PD_7: D21 (function 0) 
  scu_pinmux(0x0D, 8, MD_PLN, FUNC0); 		// PD_8: D22 (function 0) 
  scu_pinmux(0x0D, 9, MD_PLN, FUNC0);  		// PD_9: D23 (function 0) 
  scu_pinmux(0x0E, 5, MD_PLN, FUNC0);  		// PE_5: D24 (function 0) 
  scu_pinmux(0x0E, 6, MD_PLN, FUNC0);  		// PE_6: D25 (function 0) 
  scu_pinmux(0x0E, 7, MD_PLN, FUNC0); 		// PE_7: D26 (function 0) 
  scu_pinmux(0x0E, 8, MD_PLN, FUNC0); 		// PE_8: D27 (function 0) 
  scu_pinmux(0x0E, 9, MD_PLN, FUNC0);  		// PE_9: D28 (function 0) 
  scu_pinmux(0x0E, 10, MD_PLN, FUNC0);  	// PE_10: D29 (function 0) 
  scu_pinmux(0x0E, 11, MD_PLN, FUNC0);  	// PE_11: D30 (function 0) 
  scu_pinmux(0x0E, 12, MD_PLN, FUNC0);  	// PE_12: D31 (function 0) 
  
  scu_pinmux(0x02, 9, MD_PLN, FUNC0);  		// P2_9: A0 (function 0) 
  scu_pinmux(0x02, 10, MD_PLN, FUNC0);  	// P2_10: A1 (function 0) 
  scu_pinmux(0x02, 11, MD_PLN, FUNC0);  	// P2_11: A2 (function 0) 
  scu_pinmux(0x02, 12, MD_PLN, FUNC0);  	// P2_12: A3 (function 0) 
  scu_pinmux(0x02, 13, MD_PLN, FUNC0);  	// P2_13: A4 (function 0) 
  scu_pinmux(0x01, 0, MD_PLN, FUNC0);  		// P1_0: A5 (function 0) 
  scu_pinmux(0x01, 1, MD_PLN, FUNC2);  		// P1_1: A6 (function 2) 
  scu_pinmux(0x01, 2, MD_PLN, FUNC2);  		// P1_2: A7 (function 2)     
  scu_pinmux(0x02, 8, MD_PLN, FUNC3);  		// P2_8: A8 (function 3) 
  scu_pinmux(0x02, 7, MD_PLN, FUNC0);  		// P2_7: A9 (function 0) 
  scu_pinmux(0x02, 6, MD_PLN, FUNC2);  		// P2_6: A10 (function 2) 
  scu_pinmux(0x02, 2, MD_PLN, FUNC2);  		// P2_2: A11 (function 2) 
  scu_pinmux(0x02, 1, MD_PLN, FUNC2);  		// P2_1: A12 (function 2) 
  scu_pinmux(0x02, 0, MD_PLN, FUNC2);  		// P2_0: A13 (function 2) 
  scu_pinmux(0x06, 8, MD_PLN, FUNC1);  		// P6_8: A14 (function 1) 
  scu_pinmux(0x06, 7, MD_PLN, FUNC1);  		// P6_7: A15 (function 1) 
  scu_pinmux(0x0D, 16, MD_PLN, FUNC0);  	// PD_16: A16 (function 0) 
  scu_pinmux(0x0D, 15, MD_PLN, FUNC0);  	// PD_15: A17 (function 0) 
  scu_pinmux(0x0E, 0, MD_PLN, FUNC0);  		// PE_0: A18 (function 0) 
  scu_pinmux(0x0E, 1, MD_PLN, FUNC0);  		// PE_1: A19 (function 0) 
  scu_pinmux(0x0E, 2, MD_PLN, FUNC0);  		// PE_2: A20 (function 0) 
  scu_pinmux(0x0E, 3, MD_PLN, FUNC0);  		// PE_3: A21 (function 0) 
  scu_pinmux(0x0E, 4, MD_PLN, FUNC0);  		// PE_4: A22 (function 0) 
  scu_pinmux(0x01, 5, MD_PLN, FUNC0);  		// P1_5: CS0 (function 0) 
  scu_pinmux(0x01, 6, MD_PLN, FUNC0);  		// P1_6: WE (function 0) 
  scu_pinmux(0x01, 3, MD_PLN, FUNC0);  		// P1_3: OE (function 0) 
  
  // initialise the control pin signal registers
  // 70ns 16-bit Flash on CS0  
  *(U32 *)0x40005000 = 0x00000001;      	// Enable */
  *(U32 *)0x40005200 = 0x00000081;      	// CS0: 16 bit, WE
  *(U32 *)0x40005208 = 0x00000002;      	// CS0: WAITOEN = 1
  *(U32 *)0x4000520C = 0x00000009;      	// CS0: WAITRD = 6

}



/************************************************************************
 *  Initialise the external memory controller in LPC1800 V00
 *    
 ************************************************************************/
void LPC1800V00_emc_init( void )
{
  	// Set all EMI related pins to the correct function (or at least the ones 
	// which have not been set by the bootcode)
	scu_pinmux(2,8,MD_PLN,FUNC3);
	scu_pinmux(2,7,MD_PLN,FUNC3);
	scu_pinmux(2,6,MD_PLN,FUNC2);
	scu_pinmux(2,2,MD_PLN,FUNC2);
	scu_pinmux(2,1,MD_PLN,FUNC2);
	scu_pinmux(2,0,MD_PLN,FUNC2);
	scu_pinmux(6,8,MD_PLN,FUNC1);
	scu_pinmux(6,7,MD_PLN,FUNC1);
	scu_pinmux(13,16,MD_PLN,FUNC2);
	scu_pinmux(13,15,MD_PLN,FUNC2);
	scu_pinmux(14,0,MD_PLN,FUNC3);
	scu_pinmux(14,1,MD_PLN,FUNC3);
	scu_pinmux(14,2,MD_PLN,FUNC3);
	scu_pinmux(14,3,MD_PLN,FUNC3);
	scu_pinmux(14,4,MD_PLN,FUNC3);
	scu_pinmux(10,4,MD_PLN,FUNC3);
	scu_pinmux(1,7,MD_PLN,FUNC3);
	scu_pinmux(1,8,MD_PLN,FUNC3);
	scu_pinmux(1,9,MD_PLN,FUNC3);
	scu_pinmux(1,10,MD_PLN,FUNC3);
	scu_pinmux(2,9,MD_PLN,FUNC3);
	scu_pinmux(1,11,MD_PLN,FUNC3);
	scu_pinmux(1,12,MD_PLN,FUNC3);
	scu_pinmux(1,13,MD_PLN,FUNC3);
	scu_pinmux(1,14,MD_PLN,FUNC3);
	scu_pinmux(5,4,MD_PLN,FUNC2);
	scu_pinmux(5,5,MD_PLN,FUNC2);
	scu_pinmux(5,6,MD_PLN,FUNC2);
	scu_pinmux(5,7,MD_PLN,FUNC2);
	scu_pinmux(5,0,MD_PLN,FUNC2);
	scu_pinmux(5,1,MD_PLN,FUNC2);
	scu_pinmux(2,10,MD_PLN,FUNC3);
	scu_pinmux(5,2,MD_PLN,FUNC2);
	scu_pinmux(5,3,MD_PLN,FUNC2);
	scu_pinmux(13,2,MD_PLN,FUNC2);
	scu_pinmux(13,3,MD_PLN,FUNC2);
	scu_pinmux(13,4,MD_PLN,FUNC2);
	scu_pinmux(13,5,MD_PLN,FUNC2);
	scu_pinmux(13,6,MD_PLN,FUNC2);
	scu_pinmux(13,7,MD_PLN,FUNC2);
	scu_pinmux(13,8,MD_PLN,FUNC2);
	scu_pinmux(13,9,MD_PLN,FUNC2);
	scu_pinmux(2,11,MD_PLN,FUNC3);
	scu_pinmux(14,5,MD_PLN,FUNC3);
	scu_pinmux(14,6,MD_PLN,FUNC3);
	scu_pinmux(14,7,MD_PLN,FUNC3);
	scu_pinmux(14,8,MD_PLN,FUNC3);
	scu_pinmux(14,9,MD_PLN,FUNC3);
	scu_pinmux(14,10,MD_PLN,FUNC3);
	scu_pinmux(14,11,MD_PLN,FUNC3);
	scu_pinmux(14,12,MD_PLN,FUNC3);
	scu_pinmux(1,5,MD_PLN,FUNC3);
	scu_pinmux(6,3,MD_PLN,FUNC3);
	scu_pinmux(2,12,MD_PLN,FUNC3);
	scu_pinmux(13,12,MD_PLN,FUNC2);
	scu_pinmux(13,12,MD_PLN,FUNC2);
	scu_pinmux(1,6,MD_PLN,FUNC3);
	scu_pinmux(1,3,MD_PLN,FUNC3);
	scu_pinmux(2,13,MD_PLN,FUNC3);
	scu_pinmux(1,0,MD_PLN,FUNC2);
	scu_pinmux(1,1,MD_PLN,FUNC2);
	scu_pinmux(1,2,MD_PLN,FUNC2);
  
	// initialise the control pin signal registers
	// 70ns 16-bit Flash on CS0  
	*(U32 *)0x40005000 = 0x00000001;      // Enable
	*(U32 *)0x40005200 = 0x00000081;      // CS0: 16 bit, WE
	*(U32 *)0x40005208 = 0x00000002;      // CS0: WAITOEN = 1
	*(U32 *)0x4000520C = 0x00000009;      // CS0: WAITRD = 6
}



/************************************************************************
 *  Initialise the external memory controller in LPC1800 V00 Metal Fix
 *    
 ************************************************************************/
void LPC1800V00MF_emc_init( void )
{
  
	// Set all EMI related pins to the correct function (or at least the ones 
	// which have not been set by the bootcode)
	scu_pinmux(2,2,MD_PLN,FUNC2);
	scu_pinmux(2,6,MD_PLN,FUNC2);
	scu_pinmux(2,8,MD_PLN,FUNC3);
	scu_pinmux(6,1,MD_PLN,FUNC1);
	scu_pinmux(6,2,MD_PLN,FUNC1);
	scu_pinmux(6,6,MD_PLN,FUNC1);
	scu_pinmux(6,7,MD_PLN,FUNC1);
	scu_pinmux(6,8,MD_PLN,FUNC1);
	scu_pinmux(10,4,MD_PLN,FUNC3);
	scu_pinmux(1,1,MD_PLN,FUNC2);
	scu_pinmux(1,2,MD_PLN,FUNC2);
	scu_pinmux(2,0,MD_PLN,FUNC2);
	scu_pinmux(2,1,MD_PLN,FUNC2);

	// initialise the control pin signal registers
	// 70ns 16-bit Flash on CS0  
	*(U32 *)0x40005000 = 0x00000001;      // Enable
	*(U32 *)0x40005200 = 0x00000081;      // CS0: 16 bit, WE 
	*(U32 *)0x40005208 = 0x00000002;      // CS0: WAITOEN = 1
	*(U32 *)0x4000520C = 0x00000009;      // CS0: WAITRD = 6 
}




int Flash_Identification( void )
{
	// Read CFI information from a Sharp LHF00L28
	M16(base_adr) = 0x0098;
	mcode = M16(0x0000);
	M16(base_adr) = 0x0098;
	dcode = M16(0x0002);
	if ((mcode == 0x00B0) && (dcode == 0x00A4))
	{
	  flashtype = SHARP_LHF00L28;
	  return( 1 );
	}

	

}
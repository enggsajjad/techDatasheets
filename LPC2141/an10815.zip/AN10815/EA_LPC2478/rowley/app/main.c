/***********************************************************************
 * File:   main.c
 * Rev:    1.0
 * Date:   
 *
 * Description:
 *     This example shows how to use SWIM graphics library
 *
 * Revision History:
 * 
 * Initial revision.
 * 
 **********************************************************************/

#include "LPC23xx.h"				/* LPC23xx/24xx definitions */
#include "type.h"
#include "irq.h"
#include "target.h"
#include "ex_sdram.h"
#include "lpc_lcd_params.h"
#include "lcd_driver.h"
#include "timer.h"

#define LCD_DISPLAY truly_tft_g240320ltsw_118w_e_portrait	// EA2478 built-in display
long dev_lcd;
extern void lcd_colorbars(void);
    
/***********************************************************************
 *
 * Function: main
 *
 * Purpose: Function entry point from the startup code.
 *
 * Processing:
 *
 * Parameters: 	None
 *
 * Outputs: None
 *
 * Returns: None
 *
 **********************************************************************/
int main(void)
{

  /* Configure PLL, switch from IRC to Main OSC */
  ConfigurePLL();

  /* initialize external SDRAM interface */
  SDRAMInit();

  /* Power Control for CLCDC peripheral */ 
  PCONP |= 0x00100000;        

  /* Open LCD */
  if ((dev_lcd = lcd_open(CLCDC, (long)&LCD_DISPLAY)) == 0x0)
  {
    /* Error opening the device */
    while(1);
  }

  /* Set LCD display pointer */
  lcd_ioctl(dev_lcd, LCD_SET_BUFFER, (long)SDRAM_BASE_ADDR);
   
  /* Enable LCD */
  lcd_ioctl(dev_lcd, LCD_ENABLE, 1);

  /* Turn on LCD */
  lcd_ioctl(dev_lcd, LCD_PWR_ON, 1);

  /* initialize timer 0 */
  init_timer(0, 1000);

  /* enable timer 0 */
  enable_timer(0);

  /* Enable interrupts */
  libarm_enable_irq();

  /* Display 3 color bars on the lcd display */
  lcd_colorbars();
  	      
  while(1); 	/* loop forever, the end */

}

This is a USB Memory Device demonstration for
the Keil MCB2300 Board with the NXP LPC23xx family of microcontrollers.

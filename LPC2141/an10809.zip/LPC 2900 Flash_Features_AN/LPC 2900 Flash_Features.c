/*****************************************************************************
 *   fmctest.c:  main C entry file for NXP LPC29xx Family Microprocessors
 *
 *   Copyright(C) 2007, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2007.07.19  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#include "LPC29xx.h"                        /* LPC29xx definitions */
#include "type.h"
#include "target.h"
#include "irq.h"
#include "fmc.h"

//#define JTAG_SECURITY			    /* comment this out if JTAG security is desired */
//#define SECTOR_10_SECURITY		/* comment this out if sector 10 security is desired */

/* used to read back index sector area values 128bits */ 
DWORD index_sector[4];

typedef struct FlashWord
/*  Structure used for 128 bit software signature generation*/
{
    DWORD  word0; /* word 0 to pass to sig generator*/
    DWORD  word1; /* word 1 to pass to sig generator*/
    DWORD  word2; /* word 2 to pass to sig generator*/
    DWORD  word3; /* word 3 to pass to sig generator*/
} FlashWord_t, *pFlashWord_t;

typedef struct  Gen128BitSignature
/*  Structure to hold 128 bit signature.*/
{
    DWORD      word0; /* word 0 of the 128 bit signature */
    DWORD      word1; /* word 1 of the 128 bit signature */
    DWORD      word2; /* word 2 of the 128 bit signature */
    DWORD      word3; /* word 3 of the 128 bit signature */
} Gen128BitSignature_t, *pGen128BitSignature_t;

/*----------------------------------------------------------------------------*/
/*																			  */
/* FUNCTION:    read_index_sector:                                			  */
/*																			  */
/* DESCRIPTION: reads 128 bits from the index sector                          */
/*              at address specified, the values read are put in an array     */
/*                                                                            */
/* RETURN:                                                                    */
/*                                                                            */
/* NOTES:                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/
void read_index_sector( DWORD addr)
	{
	DWORD  *addr_ptr;
	addr_ptr =  (DWORD *)(addr);
	
	FCTR = FS_ISS | (0x1<<0); // enable access to the index sector
	
	index_sector[0] = addr_ptr[0];	 // need to read 4 words. 1 flash word is 16 bytes (128bits)
	index_sector[1] = addr_ptr[1];	 
	index_sector[2] = addr_ptr[2];	 
	index_sector[3] = addr_ptr[3];	 
	
	FCTR =  (0x1<<0); // disable index sector access
	}

/*----------------------------------------------------------------------------*/
/*																			  */
/* FUNCTION:    StartGenSignature:                                			  */
/*																			  */
/* DESCRIPTION: generates signature for flash contents of the                 */
/*              address range specified                                       */
/*                                                                            */
/* RETURN:                                                                    */
/*                                                                            */
/* NOTES:                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/
StartGenSignature (DWORD startAddr, DWORD stopAddr)
{   
    /* align flash address to refer the flash word in the array*/
    startAddr = (startAddr >> 4) & 0x0001ffff;
    stopAddr  = (stopAddr >> 4)  & 0x0001ffff;

    /* write start address of the flash contents to the register*/
    FMSSTART = startAddr;

    /* write stop address of the flash contents to the register, start generating the signature*/
    FMSSTOP = stopAddr | MISR_START;

    /* wait for signature to be generated */
#if FMC_INTERRUPT_ENABLED
    while ( eom_flag == 0 );
    eom_flag = 0;
#else   
    while ((FMC_INT_STATUS & EOM) != EOM);
    FMC_INT_CLR_STATUS = EOM;
#endif
}

/*----------------------------------------------------------------------------*/
/*																			  */
/* FUNCTION:    UpdateSignature                                			      */
/*																			  */
/* DESCRIPTION: Updates signature with Flash Word                             */
/*                                                                            */
/*  @param[in]       flashWord       FlashWord (4x 32-bit word)				  */
/*  @param[in,out]   pSignature      128 bit signature						  */
/*                                                                            */
/* RETURN:                                                                    */
/*                                                                            */
/* NOTES:                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/
void UpdateSignature(pFlashWord_t flashWord, pGen128BitSignature_t pSignature)
{
    Gen128BitSignature_t nextSign;

    /* update 128 bit signature */
    nextSign.word0 = flashWord->word0 ^ pSignature->word0>>1 ^ pSignature->word1<<31;
    nextSign.word1 = flashWord->word1 ^ pSignature->word1>>1 ^ pSignature->word2<<31;
    nextSign.word2 = flashWord->word2 ^ pSignature->word2>>1 ^ pSignature->word3<<31;
    nextSign.word3 = flashWord->word3 ^ pSignature->word3>>1 ^
                     ( pSignature->word0 & 1<<29 )<<2 ^
                     ( pSignature->word0 & 1<<27 )<<4 ^
                     ( pSignature->word0 & 1<<2 )<<29 ^
                     ( pSignature->word0 & 1<<0 )<<31;

    *pSignature = nextSign;
}

/*******************************************************************************   
Main Function  main()
******************************************************************************/
int main (void)
{
	FlashWord_t flashWord; 							/* 4 x 32bits passed to signature generator */    
	Gen128BitSignature_t refSignature = {0,0,0,0}; 	/* initialized to 0 */
	DWORD signatureValue[4]; 						/* storage for flash 128bit signature */	

	DWORD i, *PageAddr;
    BYTE TestPage[FMC_PAGE_SIZE];
				
	/* initialize the Flash memory controller */
	FMC_Init();	
		
	/* initialize a buffer with known data */
	for ( i = 0; i < FMC_PAGE_SIZE; i++ )
	{
	if ( i % 2 )
		TestPage[i] = i;
	else
		TestPage[i] = i+1;
	}

    /* erase sector 10  - this is used to verify that the sector is protected (see later) */
    FMC_EraseSector( SECTOR_ADDR_10 ); /* large 0x200b.0000 - 0x200b.ffff */

	/* program sector 10 with known data */
	for ( i = 0; i < FMC_LA_PAGE_NUM; i++ )
	{
	FMC_WritePage( SECTOR_ADDR_10 + i*FMC_PAGE_SIZE, 
						&TestPage[0], FMC_PAGE_SIZE );
	}

	/* Start address 0x20000000 -> 0x2000.1FFF; Sector 11 */
	StartGenSignature(SECTOR_ADDR_11, SECTOR_ADDR_11 + 0x1FFF);  
	
	/* get the 128bit generated signature */
	signatureValue[0] = FMSW0;
	signatureValue[1] = FMSW1;
	signatureValue[2] = FMSW2;
	signatureValue[3] = FMSW3;  
	
	/* compare to expected, load up flashWord with 4 words 
	and call UpdateSignature, do this for complete sector range*/
	PageAddr = (DWORD *)((DWORD)SECTOR_ADDR_11);
	for ( i = 0; i < FMC_SM_PAGE_NUM * FMC_PAGE_SIZE; i+=16 )
	{
	flashWord.word0 = *PageAddr;
	PageAddr++;
	flashWord.word1 = *PageAddr;
	PageAddr++;
	flashWord.word2 = *PageAddr;
	PageAddr++;
	flashWord.word3 = *PageAddr;
	PageAddr++;

	UpdateSignature(&flashWord, &refSignature );
	}
	
	/* compare */
	if((refSignature.word0 != signatureValue[0]) | (refSignature.word1 != signatureValue[1])
		| (refSignature.word0 != signatureValue[0]) | (refSignature.word0 != signatureValue[0])){
		 while(1); /* fails */
		}


#ifdef SECTOR_10_SECURITY /*  enable sector security feature on sector 10 */



/* 
   Now test the sector security feature. Each sector can be individually secured. 
   Once secured it is no longer possible to erase the sector    
   (it is not possible to change a 0 to a 1, changing a 1 to 0 is possible)
  
   1: Unprotect sector

   2: enable sector security for that sector
   	  this is done by programming the appropriate index sector address

   3: verify that the sector can not be programed

*/

  /* setup the index sector values to program*/
  	  
	  /* setup buffer with 128bits of 0x0 data */
	  for ( i = 0; i < 16; i++ )
	  {
		TestPage[i] = 0;
	  }
	
	  /* unprotect index sector */
	  FMC_INX_SECTOR = UNPROTECT;
	  FCTR = (FS_ISS| FS_LOADREQ | FS_WPB | FS_WEB | FS_WRE | FS_CS);
	  
	  /* disable the Flash ECC */
	  FTCTR=(FTCTR |(1<<29)|(1<<28)); /* disable error correction! */
	
	  /* secure sector 10 by writing to the appropriate index sector */
	  FMC_WriteIndexPage( 0x20000ca0, &TestPage[0], 16 ); /* sector #10 == 0x200b.0000 0x200b.ffff */
	   
	  /* reenable ECC */
	  FTCTR=(FTCTR & 0xCFFFFFFF); 
	
	  /* protect */
	  FMC_INX_SECTOR = PROTECT;
	  FCTR = (FS_ISS| FS_LOADREQ | FS_WPB | FS_WEB | FS_WRE | FS_CS);
	  
	  FCTR = (FS_ISS |  FS_WEB | FS_CS);  
	  FCTR =  (FS_WEB | FS_CS);
	  
	  /* to verify, reset and verify that Sector can not be erased and is hence protected */           
	
      /* sector 10, value read into index_sector array, see Watch #1 Window */
	  read_index_sector( 0x20000ca0 ); 
	
#endif	  


	  
#ifdef JTAG_SECURITY /* JTAG security is desired */

	  /* setup buffer with 128bits of data */
	  TestPage[0] = 0xff;
	  TestPage[1] = 0xff;
	  TestPage[2] = 0xff;
	  TestPage[3] = 0x7f;
	
	  TestPage[4] = 0xff;
	  TestPage[5] = 0xff;
	  TestPage[6] = 0xff;
	  TestPage[7] = 0x7f;
	
	  TestPage[8]  = 0xff;
	  TestPage[9]  = 0xff;
	  TestPage[10] = 0xff;
	  TestPage[11] = 0x7f;
	  
	  TestPage[12] = 0xff;
	  TestPage[13] = 0xff;
	  TestPage[14] = 0xff;
	  TestPage[15] = 0x7f;

	  /* unprotect index sector */
	  FMC_INX_SECTOR = UNPROTECT;
	  FCTR = (FS_ISS| FS_LOADREQ | FS_WPB | FS_WEB | FS_WRE | FS_CS);
	  
	  /* disable the Flash ECC */
	  FTCTR=(FTCTR |(1<<29)|(1<<28)); /* disable error correction! */
	
	  /* program the appropriate index sector */
	  FMC_WriteIndexPage( 0x20000a30, &TestPage[0], 16 ); /* */
	   
	  /* reenable ECC */
	  FTCTR=(FTCTR & 0xCFFFFFFF); 
	
	  /* protect */
	  FMC_INX_SECTOR = PROTECT;
	  FCTR = (FS_ISS| FS_LOADREQ | FS_WPB | FS_WEB | FS_WRE | FS_CS);
	  
	  FCTR = (FS_ISS |  FS_WEB | FS_CS);  
	  FCTR =  (FS_WEB | FS_CS);
      
	  /* value read into index_sector array, see Watch #1 Window*/
	  read_index_sector( 0x20000a30 ); 


#endif



while(1); /* finished */

}

/*********************************************************************************
**                            End Of File
*********************************************************************************/

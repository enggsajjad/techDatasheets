/*****************************************************************************
 *   target.c:  Target C file for Philips LPC29xx Family Microprocessors
 *
 *   Copyright(C) 2007, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2007.09.01  ver 1.00    Prelimnary version, first Release
 *
*****************************************************************************/
#include "LPC29xx.h"
#include "type.h"
#include "irq.h"
#include "target.h"

DWORD RGU_Status[6];
DWORD RGU_SRC_Status[23];

void Release_Security(void)
{

    SEC_DIS = 1;	// Seting this bit will diable security
    // normally enabled by the flash index sector
    return;
}


/******************************************************************************
** Function name:		TargetInit
**
** Descriptions:		Initialize the target board; it is called in a necessary
**				place, change it as needed
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TargetInit(void)
{
    /* Add your codes here */
    return;
}

/******************************************************************************
** Function name:	GPIOResetInit
**
** Descriptions:	Initialize the target board before running the main()
**					function; User may change it as needed, but may not
**					deleted it.
**
** parameters:		None
** Returned value:	None
**
******************************************************************************/
void GPIOResetInit( void )
{
    return;
}

/******************************************************************************
** Function name:	TargetResetInit
**
** Descriptions:	Initialize the target board before running the main()
**					function; User may change it as needed, but may not
**					deleted it.
**
** parameters:		None
** Returned value:	None
**
******************************************************************************/
void TargetResetInit(void)
{
    CGU_OSC_CTRL = (0x1<<2) | (0x1<<0);		// (re-)enable the osc
    while ( !(CGU_OSC_STAT & (0x1<<0)) );   // wait for osc to start up

    /* Disable all interrupts */
    init_VIC();

    FCTR = FS_DCR | FS_CS;
    FBWST = SPECALWAYS | 0x04;

    //IRAM1SanityCheck();	/* Check the second IRAM area */

    /* sys clk config, source is Xtal - 10MHz on Keil MCB2900 */
    SYS_CLK_CONF = CLK_SEL_XTAL | AUTOBLK;

    /* PLL, 3-phase output control enable, and power down PLL. */
    CGU_PLL_CTRL = P23EN | PLL_PD;
    /* PLL, MSEL=16, 3-phase output control enable, power down PLL. */
    CGU_PLL_CTRL = PLL_XTAL_SEL | (PLL_M_VALUE<<MSEL_SHIFT) | P23EN | PLL_PD;
    /* PLL, MSEL=16, 3-phase output control enable, PLL normal operation. */
    CGU_PLL_CTRL = PLL_XTAL_SEL | (PLL_M_VALUE<<MSEL_SHIFT) | P23EN;
                             
    /* Check lock bit, if unlocked, PLL_LOCK is always 0 */
    while ( !(CGU_PLL_STAT & PLL_LOCK) );
    /* Check clock detection register to make sure PLL is present now. */
    while ( !(CGU_RDET & PLL_PRESENT) );

    /* Based on if USB used or not, the multiplier is set differently,
    for 10Mhz Crystal OSC, if USB is not used, multiplier is 20,
    divider is 2, CCLK is 100Mhz. If USB is used, multiplier is 24,
    divider is 3 for CCLK, CCLK is 80Mhz, for USB clock, divider is
    5, USB_CLK is 48Mhz. */
#if !USB
#if HITEX_BOARD
    /* PLL is 192Mhz, SYS_CLK and TMR_CLK is 96Mhz */
    SYS_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;
    IVNSS_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;
    MSCSS_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;
    UART_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;
    TMR_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;

    /* Depending on the boards, on HITEX board, XTAL is 16Mhz.
    on SJA2510 or Keil board, XTAL is 10Mhz. So be careful with the
    setting. */
    SPI_CLK_CONF = CLK_SEL_XTAL | AUTOBLK | DIV2;

    /* denominator is 1250, load value is 1, configure FDIV1 to
    provide a 128kHz clock from 160Mhz PLL. */
    CGU_FDIV_CONF1 = (0x02<<24)|(1<<12)|( 1250<<0);
    /* Make sure FDIV1 is present. */
    while ( !(CGU_RDET & (0x01<<6)) );
    /* Configure the ADC clock to 32kHz (FDIV1/4)*/
    ADC_CLK_CONF = CLK_SEL_PLL_FDIV1 | AUTOBLK | DIV4;		/* For ADC */
    //  ADC_CLK_CONF = CLK_SEL_XTAL | AUTOBLK | DIV4;
#else
    /* PLL is 200Mhz, SYS_CLK and TMR_CLK is 100Mhz */
    SYS_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;
    IVNSS_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;
    MSCSS_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV4;
    UART_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV4;
    TMR_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV4;

    /* Depending on the boards, on HITEX board, XTAL is 16Mhz.
    on SJA2510 or Keil board, XTAL is 10Mhz. So be careful with the
    setting. */
    SPI_CLK_CONF = CLK_SEL_XTAL | AUTOBLK | DIV2;

    /* denominator is 1250, load value is 1, configure FDIV1 to
    provide a 128kHz clock from 160Mhz PLL. */
    CGU_FDIV_CONF1 = (0x02<<24)|(1<<12)|( 1250<<0);
    /* Make sure FDIV1 is present. */
    while ( !(CGU_RDET & (0x01<<6)) );
    /* Configure the ADC clock to 32kHz (FDIV1/4)*/
    ADC_CLK_CONF = CLK_SEL_PLL_FDIV1 | AUTOBLK | DIV4;		/* For ADC */
    //  ADC_CLK_CONF = CLK_SEL_XTAL | AUTOBLK | DIV4;
#endif
#else		/* if USB is enabled. */
#if HITEX_BOARD
    /* PLL is 192Mhz, post diver is 2, SYS_CLK and TMR_CLK is 96Mhz */
    SYS_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;
    IVNSS_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;
    MSCSS_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;
    UART_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;
    TMR_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;

    /* Depending on the boards, on HITEX board, XTAL is 16Mhz.
    on SJA2510 or Keil board, XTAL is 10Mhz. So be careful with the
    setting. */
    SPI_CLK_CONF = CLK_SEL_XTAL | AUTOBLK | DIV2;

    /* denominator is 1250, load value is 1, configure FDIV1 to
    provide a 128kHz clock from 240Mhz PLL. */
    CGU_FDIV_CONF1 = (0x02<<24)|(1<<12)|( 1250<<0);
    /* Make sure FDIV1 is present. */
    while ( !(CGU_RDET & (0x01<<6)) );
    /* Configure the ADC clock to 32kHz (FDIV1/6)*/
    ADC_CLK_CONF = CLK_SEL_PLL_FDIV1 | AUTOBLK | DIV4;		/* For ADC */

    /* USB related, ICLK1 going to CGU1 is the same as XTAL clock
    which is 10Mhz on Keil MCB2900 board */
    ICLK1_CLK_CONF = CLK_SEL_XTAL | AUTOBLK;

    /* ICLK1 as CGU1 PLL input. USB clock configuration only, for CGU1 */
    /* CGU1 PLL, 3-phase output control enable, and power down PLL. */
    CGU1_PLL_CTRL = P23EN | PLL_PD;
    /* PLL, MSEL=16, 3-phase output control enable, power down PLL. */
    /* Bit 24 is set to one, the name(PLL_XTAL_SEL) doesn't match, it's
    actually the ICLK1 from CGU0. */
    CGU1_PLL_CTRL = PLL_XTAL_SEL | (PLL1_M_VALUE<<MSEL_SHIFT) | P23EN | PLL_PD;
    /* PLL, MSEL=16, 3-phase output control enable, PLL normal operation. */
    CGU1_PLL_CTRL = PLL_XTAL_SEL | (PLL1_M_VALUE<<MSEL_SHIFT) | P23EN;

    /* Check lock bit, if unlocked, PLL_LOCK is always 0 */
    while ( !(CGU1_PLL_STAT & PLL_LOCK) );
    /* Check clock detection register to make sure PLL is present now. */
    while ( !(CGU1_RDET & PLL_PRESENT) );

    /* USB clock is 48Mhz, 192/4=48Mhz */
    USB_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV4;
    /* USB I2C clock uses ICLK1(16Mhz) from CGU0, I2C clock is 8Mhz(/2) */
    USB_I2C_CLK_CONF = CLK_SEL_XTAL | AUTOBLK | DIV2;
    /* OUT clock from CGU1 is 96Mhz */
    OUT_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV2;
#else
    /* PLL is 240Mhz, post diver is 3, SYS_CLK and TMR_CLK is 80Mhz */
    SYS_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV3;
    IVNSS_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV3;
    MSCSS_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV3;
    UART_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV3;
    TMR_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV3;

    /* Depending on the boards, on HITEX board, XTAL is 16Mhz.
    on SJA2510 or Keil board, XTAL is 10Mhz. So be careful with the
    setting. */
    SPI_CLK_CONF = CLK_SEL_XTAL | AUTOBLK | DIV2;

    /* denominator is 1250, load value is 1, configure FDIV1 to
    provide a 128kHz clock from 240Mhz PLL. */
    CGU_FDIV_CONF1 = (0x02<<24)|(1<<12)|( 1250<<0);
    /* Make sure FDIV1 is present. */
    while ( !(CGU_RDET & (0x01<<6)) );
    /* Configure the ADC clock to 32kHz (FDIV1/6)*/
    ADC_CLK_CONF = CLK_SEL_PLL_FDIV1 | AUTOBLK | DIV6;		/* For ADC */
    //  ADC_CLK_CONF = CLK_SEL_XTAL | AUTOBLK | DIV4;

    /* USB related, ICLK1 going to CGU1 is the same as XTAL clock
    which is 10Mhz on Keil MCB2900 board */
    ICLK1_CLK_CONF = CLK_SEL_XTAL | AUTOBLK;

    /* ICLK1 as CGU1 PLL input. USB clock configuration only, for CGU1 */
    /* CGU1 PLL, 3-phase output control enable, and power down PLL. */
    CGU1_PLL_CTRL = P23EN | PLL_PD;
    /* PLL, MSEL=16, 3-phase output control enable, power down PLL. */
    /* Bit 24 is set to one, the name(PLL_XTAL_SEL) doesn't match, it's
    actually the ICLK1 from CGU0. */
    CGU1_PLL_CTRL = PLL_XTAL_SEL | (PLL1_M_VALUE<<MSEL_SHIFT) | P23EN | PLL_PD;
    /* PLL, MSEL=16, 3-phase output control enable, PLL normal operation. */
    CGU1_PLL_CTRL = PLL_XTAL_SEL | (PLL1_M_VALUE<<MSEL_SHIFT) | P23EN;

    /* Check lock bit, if unlocked, PLL_LOCK is always 0 */
    while ( !(CGU1_PLL_STAT & PLL_LOCK) );
    /* Check clock detection register to make sure PLL is present now. */
    while ( !(CGU1_RDET & PLL_PRESENT) );

    /* USB clock is 48Mhz, 240/5=48Mhz */
    USB_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV5;
    /* USB I2C clock uses ICLK1(10Mhz) from CGU0, I2C clock is 5Mhz(/2) */
    USB_I2C_CLK_CONF = CLK_SEL_XTAL | AUTOBLK | DIV2;
    /* OUT clock from CGU1 is 80Mhz */
    OUT_CLK_CONF = CLK_SEL_PLL | AUTOBLK | DIV3;
#endif
#endif

    /* Add your codes here */
    GPIOResetInit();
    return;
}

/*****************************************************************************
** Function name:		Get_RGU_Status
**
** Descriptions:		Get reset status from RGU.(for RGU debugging only)
**
** parameters:			None
** Returned value:		None
**
*****************************************************************************/
void Get_RGU_Status( void )
{
    RGU_Status[0] = RGU_RESET_STAT0;
    RGU_Status[1] = RGU_RESET_STAT1;
    RGU_Status[2] = RGU_RESET_STAT2;
    RGU_Status[3] = RGU_RESET_STAT3;

    RGU_Status[4] = RGU_RST_ACTIVE_STAT0;
    RGU_Status[5] = RGU_RST_ACTIVE_STAT1;
    return;
}

/*****************************************************************************
** Function name:		Get_RGU_SRC_Status
**
** Descriptions:		Get reset source status from RGU.
**						(for RGU debugging only)
**
** parameters:			None
** Returned value:		None
**
*****************************************************************************/
void Get_RGU_SRC_Status( void )
{
    RGU_SRC_Status[0] = RGU_RST_SRC;
    RGU_SRC_Status[1] = RGU_PCR_RST_SRC;
    RGU_SRC_Status[2] = RGU_COLD_RST_SRC;
    RGU_SRC_Status[3] = RGU_WARM_RST_SRC;
    RGU_SRC_Status[4] = RGU_SCU_RST_SRC;

    RGU_SRC_Status[5] = RGU_CFID_RST_SRC;
    RGU_SRC_Status[6] = RGU_FMC_RST_SRC;
    RGU_SRC_Status[7] = RGU_EMC_RST_SRC;
    RGU_SRC_Status[8] = RGU_SMC_SRC;
    RGU_SRC_Status[9] = RGU_GESS_A2V_RST_SRC;

    RGU_SRC_Status[10] = RGU_PESS_A2V_RST_SRC;
    RGU_SRC_Status[11] = RGU_GPIO_RST_SRC;
    RGU_SRC_Status[12] = RGU_UART_RST_SRC;
    RGU_SRC_Status[13] = RGU_TMR_RST_SRC;
    RGU_SRC_Status[14] = RGU_SPI_RST_SRC;

    RGU_SRC_Status[15] = RGU_IVNSS_A2V_RST_SRC;
    RGU_SRC_Status[16] = RGU_IVNSS_CAN_RST_SRC;
    RGU_SRC_Status[17] = RGU_MSCSS_A2V_RST_SRC;
    RGU_SRC_Status[18] = RGU_MSCSS_PWM_RST_SRC;
    RGU_SRC_Status[19] = RGU_MSCSS_ADC_RST_SRC;

    RGU_SRC_Status[20] = RGU_MSCSS_TMR_RST_SRC;
    RGU_SRC_Status[21] = RGU_VIC_RST_SRC;
    RGU_SRC_Status[22] = RGU_AHB_RST_SRC;
    return;
}

/******************************************************************************
** Function name:	IRAM1SanityCheck
**
** Descriptions:	Verify IRAM Instance 1 access.
**					If fail, spin forever.
**
** parameters:		None
** Returned value:	None
**
******************************************************************************/
void IRAM1SanityCheck( void )
{
    volatile BYTE *wrb_ptr, *rdb_ptr;
    volatile DWORD *wr_ptr, *rd_ptr;
    DWORD i;

    wrb_ptr = (BYTE *)IRAM1_BASE_ADDR;
    for ( i = 0; i < IRAM1_SIZE; i++ )
        *wrb_ptr++ = 0x55;

    rdb_ptr = (BYTE *)IRAM1_BASE_ADDR;
    for ( i = 0; i < IRAM1_SIZE; i++ )
    {
        if ( *rdb_ptr++ != 0x55 )
            while ( 1 );		/* Fatal error */
    }

    wr_ptr = (DWORD *)IRAM1_BASE_ADDR;
    for ( i = 0; i < IRAM1_SIZE/4; i++ )
        *wr_ptr++ = 0x12345678;

    rd_ptr = (DWORD *)IRAM1_BASE_ADDR;
    for ( i = 0; i < IRAM1_SIZE/4; i++ )
    {
        if ( *rd_ptr++ != 0x12345678 )
            while ( 1 );		/* Fatal error */
    }
    return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/

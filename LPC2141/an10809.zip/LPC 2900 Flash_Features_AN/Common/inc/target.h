/*****************************************************************************
 *   target.h:  Header file for NXP LPC29xx Family Microprocessors
 *
 *   Copyright(C) 2007, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2007.09.01  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#ifndef __TARGET_H 
#define __TARGET_H

#ifdef __cplusplus
   extern "C" {
#endif

#define DEVICE_TYPE LPC291901



/* In below definition, only one is enabled at a time */
#define HITEX_BOARD		0	/* 0 is Keil MCB2900 board */
/* The ring osc is 400Khz. */ 
#define RING_OSC	475000

#define USB				0
#define USB_PORT1		1		/* 1 is port1, otherwise it's port2 */
#define USB_PORT2		1
#define HOST_PORT_NUM	2

#if USB
    #if HITEX_BOARD
	    #define PLL_M_VALUE		12-1	/* CGU0, OSC is 16Mhz, multiplier is 12 */
	    #define PLL1_M_VALUE	12-1	/* CGU1 OSC is 16Mhz, multiplier is 12 */
	    /* CCO is 192Mhz, CCLK and all the peripheral clocks are divided by 2 
	    or 96Mhz, USB clock is divided by 4 down to 48Mhz. */
	    #define CPU_CLK		120000000
	    /* Below PERIPH_CLK can be configured in different frequencies for 
	    different peripherals. This clock is used for TIMER block only. */ 
	    #define PERIPH_CLK	120000000     
    #else
	    #define PLL_M_VALUE		24-1	/* CGU0, OSC is 10Mhz, multiplier is 24 */
	    #define PLL1_M_VALUE	24-1	/* CGU1 OSC is 10Mhz, multiplier is 24 */
	    /* CCO is 240Mhz, CCLK and all the peripheral clocks are divided by 3 
	    or 6 down to 80Mhz or 40Mhz, USB clock is divided by 5 down to 48Mhz. */
		#define CPU_CLK		120000000
		/* Below PERIPH_CLK can be configured in different frequencies for 
		different peripherals. This clock is used for TIMER block only. */ 
		#define PERIPH_CLK	120000000
    #endif

	

#else  // !USB
  #if HITEX_BOARD
    /* The CCO clock is 192Mhz, the Post divider is 2. So, the 
    CPU_CLK is Clk_CCO/P = 96Mhz */
    #define PLL_M_VALUE		15-1	/* OSC is 16Mhz, multiplier is 12 */
    #define CPU_CLK		120000000
    
    /* Below PERIPH_CLK can be configured in different frequencies for 
    different peripherals. This clock is used for TIMER block only. */
    #define PERIPH_CLK	120000000
  #else // !HITEX
    /* The CCO clock is either 160Mhz or 200Mhz, the Post divider 
     is always 2. So, the CPU_CLK is Clk_CCO/P = 80Mhz/100Mhz */
    #define PLL_M_VALUE		12-1	/* OSC is 10Mhz, multiplier is 20 */
    
    #define CPU_CLK		120000000
    
    /* Below PERIPH_CLK can be configured in different frequencies for 
    different peripherals. This clock is used for TIMER block only. */ 
    #define PERIPH_CLK	120000000
  #endif
#endif

#define IRAM0_BASE_ADDR	0x80000000
#define IRAM0_SIZE	0x8000
#define IRAM1_BASE_ADDR	0x80008000
#define IRAM1_SIZE	0x4000

/*****************************************************************************
** Function name:		TargetInit
**
** Descriptions:		Initialize the target board; it is called in a 
**				necessary place, change it as needed
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
extern void TargetInit(void);
extern void TargetResetInit( void );
extern void GpioResetInit( void );
/* The IRAM1 test prototyping */
extern void IRAM1SanityCheck( void );

/* A RGU test module needs to be called in startup.s, move these
two modules to target.c to faciliate compatibility with all the
other modules. Only RGU test uses below two modules. */
void Get_RGU_Status( void );
void Get_RGU_SRC_Status( void );

#ifdef __cplusplus
   }
#endif
 
#endif /* end __TARGET_H */
/******************************************************************************
**                            End Of File
******************************************************************************/

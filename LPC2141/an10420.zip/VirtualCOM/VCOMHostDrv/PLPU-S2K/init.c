/*++

Module Name:

    Init.c 

Abstract:

    Main module

Environment:

    kernel mode only

Notes:

  Copyright (c) 1997-2000 Maverick Corporation.  All Rights Reserved.

Revision History:

    04/26/00: created

--*/


#include "wdm.h"
#include "stdarg.h"
#include "stdio.h"

#include "usbdi.h"
#include "usbdlib.h"
#include "usbcom.h"
#include "GUID829.h"

static ULONG UsbCom_CallUSBD_Counter = 0;

NTSTATUS
DriverEntry(
    IN PDRIVER_OBJECT DriverObject,
    IN PUNICODE_STRING RegistryPath
    )
/*++

Routine Description:

    Installable driver initialization entry point.
    This entry point is called directly by the I/O system.

Arguments:

    DriverObject - pointer to the driver object

    RegistryPath - pointer to a unicode string representing the path
                   to driver-specific key in the registry

Return Value:

    STATUS_SUCCESS if successful,
    STATUS_UNSUCCESSFUL otherwise

--*/
{
    //NTSTATUS ntStatus = STATUS_SUCCESS;
    PDEVICE_OBJECT deviceObject = NULL;
    BOOLEAN fRes;

	DbgPrint ("-----------------------------------------------------------\n");
	DbgPrint ("Maintained by CodeMachine Incorporated (www.codemachine.com)\n");
	DbgPrint ("Module %s built on %s at %s\n", "plpu-s2k" , __DATE__, __TIME__ );
	DbgPrint ("-----------------------------------------------------------\n");

    DbgPrint("Entering DriverEntry(), RegistryPath=\n    %ws\n", RegistryPath->Buffer );

    //
    // Create dispatch points for create, close, unload
    DriverObject->MajorFunction[IRP_MJ_CREATE] = UsbCom_Create;
    DriverObject->MajorFunction[IRP_MJ_CLOSE] = UsbCom_Close;
	DriverObject->MajorFunction[IRP_MJ_CLEANUP] = UsbCom_Cleanup;
    DriverObject->DriverUnload = UsbCom_Unload;

    // User mode DeviceIoControl() calls will be routed here
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = UsbCom_ProcessIOCTL;
	DriverObject->MajorFunction[IRP_MJ_INTERNAL_DEVICE_CONTROL]
      = SerialInternalIoControl;								// Added by Henry

    // User mode ReadFile()/WriteFile() calls will be routed here
    DriverObject->MajorFunction[IRP_MJ_WRITE] = SerialWrite;	// Modified by Henry
    DriverObject->MajorFunction[IRP_MJ_READ] = SerialRead;		// Modified by Henry

    // routines for handling system PNP and power management requests
    DriverObject->MajorFunction[IRP_MJ_SYSTEM_CONTROL] = UsbCom_ProcessSysControlIrp;
    DriverObject->MajorFunction[IRP_MJ_PNP] = UsbCom_ProcessPnPIrp;
    DriverObject->MajorFunction[IRP_MJ_POWER] = UsbCom_ProcessPowerIrp;

    // The Functional Device Object (FDO) will not be created for PNP devices until 
    // this routine is called upon device plug-in.
    DriverObject->DriverExtension->AddDevice = UsbCom_PnPAddDevice;

	DriverObject->MajorFunction[IRP_MJ_QUERY_INFORMATION]
		= SerialQueryInformationFile;
	DriverObject->MajorFunction[IRP_MJ_SET_INFORMATION]
		= SerialSetInformationFile;

    DbgPrint("exiting DriverEntry \n");

    return STATUS_SUCCESS;
}


NTSTATUS
UsbCom_ProcessSysControlIrp(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP           Irp
    )
/*++

Routine Description:

    Main dispatch table routine for IRP_MJ_SYSTEM_CONTROL
	We basically just pass these down to the PDO

Arguments:

    DeviceObject - pointer to FDO device object

    Irp          - pointer to an I/O Request Packet

Return Value:

	Status returned from lower driver


--*/
{

    PIO_STACK_LOCATION irpStack;
    PDEVICE_EXTENSION deviceExtension;
    NTSTATUS ntStatus = STATUS_SUCCESS;
    NTSTATUS waitStatus;
    PDEVICE_OBJECT stackDeviceObject;

    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;

    //
    // Get a pointer to the current location in the Irp. This is where
    //     the function codes and parameters are located.
    //

    irpStack = IoGetCurrentIrpStackLocation (Irp);

    //
    // Get a pointer to the device extension
    //

    deviceExtension = DeviceObject->DeviceExtension;
    stackDeviceObject = deviceExtension->TopOfStackDeviceObject;

    DbgPrint("enter UsbCom_ProcessSysControlIrp()\n");

    UsbCom_IncrementIoCount(DeviceObject);

    UsbCom_ASSERT( IRP_MJ_SYSTEM_CONTROL == irpStack->MajorFunction );

    IoCopyCurrentIrpStackLocationToNext(Irp);


    ntStatus = IoCallDriver(stackDeviceObject,
                            Irp);

    UsbCom_DecrementIoCount(DeviceObject);

    DbgPrint("UsbCom_ProcessSysControlIrp() Exit UsbCom_ProcessSysControlIrp %x\n", ntStatus);

    return ntStatus;
}


VOID
UsbCom_Unload(
    IN PDRIVER_OBJECT DriverObject
    )
/*++

Routine Description:

    Free all the allocated resources, etc.

Arguments:

    DriverObject - pointer to a driver object

Return Value:


--*/
{
    DbgPrint("enter UsbCom_Unload\n");

    //
    // Free any global resources allocated
    // in DriverEntry.
	// We have few or none because for a PNP device, almost all
	// allocation is done in PnpAddDevice() and all freeing 
	// while handling IRP_MN_REMOVE_DEVICE:
    
	//UsbCom_ASSERT( gExAllocCount == 0 );




    DbgPrint("exit UsbCom_Unload\n");

}


NTSTATUS
UsbCom_SymbolicLink(
    IN PDEVICE_OBJECT DeviceObject,
    IN OUT PUNICODE_STRING deviceLinkUnicodeString

    )
/*++

Routine Description:

    This routine is called to create and initialize
    a GUID-based symbolic link to our device to be used to open/create 
    instances of us from user mode.

    Called from UsbCom_CreateDeviceObject() to create the link. 

Arguments:

    DeviceObject - pointer to our Physical Device Object ( PDO )

    deviceLinkUnicodeString - Points to a unicode string structure allocated by the caller. 
        If this routine is successful, it initializes the unicode string and allocates 
        the string buffer containing the kernel-mode path to the symbolic link for this 
        device interface. 


Return Value:

    STATUS_SUCCESS if successful,
    STATUS_UNSUCCESSFUL otherwise

--*/
{
    NTSTATUS ntStatus = STATUS_SUCCESS;



    //  Create the symbolic link
     
    // IoRegisterDeviceInterface registers device functionality (a device interface) 
    // that a driver will enable for use by applications or other system components.

    ntStatus = IoRegisterDeviceInterface(
                DeviceObject,
                (LPGUID)&GUID_CLASS_COMPORT,
                NULL,
                deviceLinkUnicodeString);

   if (NT_SUCCESS(ntStatus)) {

       // IoSetDeviceInterfaceState enables or disables a previously 
       // registered device interface. Applications and other system components 
       // can open only interfaces that are enabled.

        ntStatus = IoSetDeviceInterfaceState(deviceLinkUnicodeString, TRUE);

		if(NT_SUCCESS(ntStatus))
			DbgPrint("SUCCEEDED  IoSetDeviceInterfaceState()\n");
		else
			DbgPrint("FAILED to IoSetDeviceInterfaceState()\n");

    }
	else
		DbgPrint("FAILED to IoRegisterDeviceInterface()\n");

    return ntStatus;
}



NTSTATUS
UsbCom_CreateDeviceObject(
    IN PDRIVER_OBJECT DriverObject,
    IN PDEVICE_OBJECT PhysicalDeviceObject,
    IN PDEVICE_OBJECT *DeviceObject
    )
/*++

Routine Description:

    Creates a Functional DeviceObject

Arguments:

    DriverObject - pointer to the driver object for device

    DeviceObject - pointer to DeviceObject pointer to return
                    created device object.

    Instance - instance of the device create.

Return Value:

    STATUS_SUCCESS if successful,
    STATUS_UNSUCCESSFUL otherwise

--*/
{
    NTSTATUS ntStatus;
    UNICODE_STRING deviceLinkUnicodeString, deviceObjName, linkName;
    PDEVICE_EXTENSION deviceExtension;
	PWCHAR PhysicalDeviceName, pRegName;
	ULONG nameLength, regLength;
	HANDLE keyHandle;
	USHORT i;

    DbgPrint("enter UsbCom_CreateDeviceObject() \n");

	*DeviceObject = NULL;
	pRegName = NULL;

	ntStatus = IoOpenDeviceRegistryKey(PhysicalDeviceObject, PLUGPLAY_REGKEY_DEVICE,
                                    STANDARD_RIGHTS_READ, &keyHandle);

	//
	// Check to see if we are allowed to do external naming; if not,
	// then we just return success
	//
	if (!NT_SUCCESS(ntStatus)) {
		DbgPrint("Couldn't open registry!\n");
		goto ErrorFreeBuffer;
	}

	pRegName = ExAllocatePool(PagedPool, SYMBOLIC_NAME_LENGTH * sizeof(WCHAR)
                            + sizeof(WCHAR));

	if (pRegName == NULL) {
		DbgPrint("Couldn't allocate memory for pRegName\n");
		ntStatus = STATUS_INSUFFICIENT_RESOURCES;
		ZwClose(keyHandle);
		goto ErrorFreeBuffer;
	}

	//
	// Fetch PortName which contains the suggested REG_SZ symbolic name.
	//
	regLength = SYMBOLIC_NAME_LENGTH * sizeof(WCHAR);
	ntStatus = SerialGetRegistryKeyValue(keyHandle, L"PortName",
                                      sizeof(L"PortName"), pRegName,
                                      &regLength);

	if (!NT_SUCCESS(ntStatus)) {
		DbgPrint("Getting PortName failed - %x\n", ntStatus);
        ZwClose (keyHandle);
		goto ErrorFreeBuffer;
    }

	ZwClose (keyHandle);

	//
	// Zero out allocated memory pointers so we know if they must be freed
	//
	RtlZeroMemory(&deviceObjName, sizeof(UNICODE_STRING));
	RtlZeroMemory(&deviceLinkUnicodeString, sizeof(UNICODE_STRING));
	RtlZeroMemory(&linkName, sizeof(UNICODE_STRING));
	
	
	// BEGIN CODEMACHINE 
	// change the way device names are allocated and used
	
	/*
	deviceObjName.MaximumLength = DEVICE_OBJECT_NAME_LENGTH * sizeof(WCHAR);
	deviceObjName.Buffer = ExAllocatePool(PagedPool, deviceObjName.MaximumLength
                                     + sizeof(WCHAR));


	if (deviceObjName.Buffer == NULL) {
		DbgPrint("Couldn't allocate memory for device object name\n");
		ntStatus = STATUS_INSUFFICIENT_RESOURCES;
		goto ErrorFreeBuffer;
	}

	RtlZeroMemory(deviceObjName.Buffer, deviceObjName.MaximumLength
                 + sizeof(WCHAR));
	RtlAppendUnicodeToString(&deviceObjName, L"\\Device\\SOPE1USB0");

	//
	// Create the device object
	//
	ntStatus = IoCreateDevice(DriverObject, sizeof(DEVICE_EXTENSION),
                           &deviceObjName, FILE_DEVICE_SERIAL_PORT,
                           FILE_DEVICE_SECURE_OPEN, TRUE, DeviceObject);

	if (!NT_SUCCESS(ntStatus))  {
		DbgPrint("UsbCom_CreateDeviceObject() IoCreateDevice() FAILED\n");
		goto ErrorFreeBuffer;
	}
	*/
	{
		ANSI_STRING DeviceNameAnsi;
		ULONG DeviceNumber;
		CHAR DeviceNameAscii[32]; 

		for (DeviceNumber = 1; ; DeviceNumber++) {
			sprintf ( DeviceNameAscii, "\\Device\\SOPE1USB%d", DeviceNumber );
			RtlInitAnsiString ( &DeviceNameAnsi, DeviceNameAscii );
			if ( ( ntStatus = RtlAnsiStringToUnicodeString ( &deviceObjName, &DeviceNameAnsi, TRUE ) ) != STATUS_SUCCESS ) {
				DbgPrint("UsbCom_CreateDeviceObject():RtlAnsiStringToUnicodeString() PDO=%08x %s : FAIL=%08x\n", 
					PhysicalDeviceObject, DeviceNameAscii, ntStatus );
				goto ErrorFreeBuffer;
			}

			ntStatus = IoCreateDevice (
				DriverObject,
				sizeof(DEVICE_EXTENSION),
				&deviceObjName,
				FILE_DEVICE_SERIAL_PORT,
				0,
				FALSE,
				DeviceObject );

			if ( NT_SUCCESS ( ntStatus ) ) {
				break;
			}
			
			RtlFreeUnicodeString ( &deviceObjName );
			
			if ( ntStatus != STATUS_OBJECT_NAME_COLLISION ) {
				DbgPrint("UsbCom_CreateDeviceObject() IoCreateDevice() PDO=%08x (%wZ) FAIL=%08x\n", 
					PhysicalDeviceObject, &deviceObjName, ntStatus );
				goto ErrorFreeBuffer;
			}
		}
	}

	DbgPrint("***** DRV=%08x PDO=%08x FDO=%08x (%wZ) ***** \n", 
		DriverObject, PhysicalDeviceObject, *DeviceObject, &deviceObjName );
		
	// END CODEMACHINE 
	
	deviceExtension = (PDEVICE_EXTENSION) ((*DeviceObject)->DeviceExtension);
 
	RtlZeroMemory(&deviceExtension->DeviceName, sizeof(UNICODE_STRING));
	RtlZeroMemory(&deviceExtension->SymbolicLinkName, sizeof(UNICODE_STRING));

	//
	// Allocate Pool and save the nt device name in the device extension.
	//
	deviceExtension->DeviceName.Buffer =
		ExAllocatePool(PagedPool, deviceObjName.Length + sizeof(WCHAR));

	if (!deviceExtension->DeviceName.Buffer) {
		DbgPrint("Couldn't allocate memory for DeviceName\n");
		ntStatus = STATUS_INSUFFICIENT_RESOURCES;
		goto ErrorFreeBuffer;
	}

	deviceExtension->DeviceName.MaximumLength = deviceObjName.Length
		+ sizeof(WCHAR);

	//
	// Zero fill it.
	//
	RtlZeroMemory(deviceExtension->DeviceName.Buffer,
                 deviceExtension->DeviceName.MaximumLength);

	RtlAppendUnicodeStringToString(&deviceExtension->DeviceName, &deviceObjName);

    //default maximum transfer size per staged io request
    deviceExtension->MaximumTransferSize =  UsbCom_MAX_TRANSFER_SIZE ;
	
	// this event is triggered when there is no pending io of any kind and device is removed
    KeInitializeEvent(&deviceExtension->RemoveEvent, NotificationEvent, FALSE);

    // this event is triggered when self-requested power irps complete
    KeInitializeEvent(&deviceExtension->SelfRequestedPowerIrpEvent, NotificationEvent, FALSE);

	// this event is triggered when there is no pending io  (pending io count == 1 )
    KeInitializeEvent(&deviceExtension->NoPendingIoEvent, NotificationEvent, FALSE);

	// spinlock used to protect inc/dec iocount logic
	KeInitializeSpinLock (&deviceExtension->IoCountSpinLock);

	KeInitializeEvent(&deviceExtension->PendingIRPEvent, SynchronizationEvent, FALSE);
	KeInitializeEvent(&deviceExtension->PendingDpcEvent, SynchronizationEvent, FALSE);

	deviceExtension->DeviceIsOpened = FALSE;

	InitializeListHead(&deviceExtension->ReadQueue);
	InitializeListHead(&deviceExtension->WriteQueue);
	InitializeListHead(&deviceExtension->MaskQueue);
	InitializeListHead(&deviceExtension->PurgeQueue);
	InitializeListHead(&deviceExtension->StalledIrpQueue);

	//
	// Initialize the timers used to timeout operations.
	//

	KeInitializeTimer(&deviceExtension->ReadRequestTotalTimer);
	KeInitializeTimer(&deviceExtension->ReadRequestIntervalTimer);
	KeInitializeTimer(&deviceExtension->WriteRequestTotalTimer);
	KeInitializeTimer(&deviceExtension->ImmediateTotalTimer);
	KeInitializeTimer(&deviceExtension->XoffCountTimer);
	KeInitializeTimer(&deviceExtension->LowerRTSTimer);

   //
   // Intialialize the dpcs that will be used to complete
   // or timeout various IO operations.
   //
   KeInitializeDpc(&deviceExtension->CompleteWriteDpc, SerialCompleteWrite, deviceExtension);
   KeInitializeDpc(&deviceExtension->CompleteReadDpc, SerialCompleteRead, deviceExtension);
   KeInitializeDpc(&deviceExtension->TotalReadTimeoutDpc, SerialReadTimeout, deviceExtension);
   KeInitializeDpc(&deviceExtension->IntervalReadTimeoutDpc, SerialIntervalReadTimeout,
                   deviceExtension);
   KeInitializeDpc(&deviceExtension->TotalWriteTimeoutDpc, SerialWriteTimeout, deviceExtension);
//   KeInitializeDpc(&deviceExtension->CommErrorDpc, SerialCommError, deviceExtension);
//   KeInitializeDpc(&deviceExtension->CompleteImmediateDpc, SerialCompleteImmediate,
//                   deviceExtension);
//   KeInitializeDpc(&deviceExtension->TotalImmediateTimeoutDpc, SerialTimeoutImmediate,
//                   deviceExtension);
   KeInitializeDpc(&deviceExtension->CommWaitDpc, SerialCompleteWait, deviceExtension);
   KeInitializeDpc(&deviceExtension->XoffCountTimeoutDpc, SerialTimeoutXoff, deviceExtension);
   KeInitializeDpc(&deviceExtension->XoffCountCompleteDpc, SerialCompleteXoff, deviceExtension);
   KeInitializeDpc(&deviceExtension->StartTimerLowerRTSDpc, SerialStartTimerLowerRTS,
                   deviceExtension);
   KeInitializeDpc(&deviceExtension->PerhapsLowerRTSDpc, SerialInvokePerhapsLowerRTS,
                   deviceExtension);
//   KeInitializeDpc(&deviceExtension->IsrUnlockPagesDpc, SerialUnlockPages, deviceExtension);

	//
	// Initialize the count of IRP's pending
	//

	deviceExtension->PendingIRPCnt = 1;

   //
   // Initialize the count of DPC's pending
   //

   deviceExtension->DpcCount = 1;

   //
   // Initialize the spinlock associated with fields read (& set)
   // by IO Control functions and the flags spinlock.
   //

   KeInitializeSpinLock(&deviceExtension->ControlLock);
   KeInitializeSpinLock(&deviceExtension->FlagsLock);
   KeInitializeSpinLock(&deviceExtension->IntBufferLock);


	// The workitem is never used.
	deviceExtension->WorkItem = IoAllocateWorkItem(*DeviceObject);
  
	if (deviceExtension->WorkItem == NULL) {
		DbgPrint("Insufficient memory for WorkItem Routine.\n");
		ntStatus = STATUS_INSUFFICIENT_RESOURCES;
		goto ErrorFreeBuffer;
	}

	KeInitializeMutex(&deviceExtension->CompleteRequestMutex,  0);
	
	// Create SymbolicLink name -- ComX.
	deviceExtension->CreatedSymbolicLink = FALSE;

	deviceExtension->CreatedSerialCommEntry = FALSE;

	linkName.MaximumLength = SYMBOLIC_NAME_LENGTH*sizeof(WCHAR);
	linkName.Buffer = ExAllocatePool(PagedPool, linkName.MaximumLength
                                    + sizeof(WCHAR));

	if (linkName.Buffer == NULL) {
		DbgPrint("Couldn't allocate memory for linkName\n");
		ntStatus = STATUS_INSUFFICIENT_RESOURCES;
		goto ErrorFreeBuffer;
	}

	RtlZeroMemory(linkName.Buffer, linkName.MaximumLength + sizeof(WCHAR));
	//
	// Create the "\\DosDevices\\<symbolicName>" string
	//
	RtlAppendUnicodeToString(&linkName, L"\\DosDevices\\");
	RtlAppendUnicodeToString(&linkName, pRegName);

	//
	// Allocate Pool and save the symbolic link name in the device extension.
	//
	deviceExtension->SymbolicLinkName.MaximumLength = linkName.Length + sizeof(WCHAR);
	deviceExtension->SymbolicLinkName.Buffer
		= ExAllocatePool(PagedPool, deviceExtension->SymbolicLinkName.MaximumLength);

	if (!deviceExtension->SymbolicLinkName.Buffer) {

		DbgPrint("Couldn't allocate memory for symbolic link name\n");
		ntStatus = STATUS_INSUFFICIENT_RESOURCES;
		goto ErrorFreeBuffer;
	}

	//
	// Zero fill it.
	//
	RtlZeroMemory(deviceExtension->SymbolicLinkName.Buffer,
                 deviceExtension->SymbolicLinkName.MaximumLength);

	RtlAppendUnicodeStringToString(&deviceExtension->SymbolicLinkName,
                                  &linkName);

	ntStatus = IoCreateSymbolicLink (&deviceExtension->SymbolicLinkName,
                                  &deviceExtension->DeviceName);
	if (!NT_SUCCESS(ntStatus)) {

		//
		// Oh well, couldn't create the symbolic link.  No point
		// in trying to create the device map entry.
		//
        DbgPrint("IoCreateSymbolicLink() (%wZ -> %wZ) FAIL=%08x\n", 
			&deviceExtension->SymbolicLinkName,
			&deviceExtension->DeviceName,
			ntStatus );
		goto ErrorFreeBuffer;
	}

	deviceExtension->CreatedSymbolicLink = TRUE;

	// Write comm port name to registry, USBSwt.exe will use this value
	ntStatus = RtlWriteRegistryValue(RTL_REGISTRY_DEVICEMAP, L"SERIALCOMM",
                                   deviceObjName.Buffer, REG_SZ,
                                   pRegName,
                                   regLength);

	if (!NT_SUCCESS(ntStatus)) {

		DbgPrint("Couldn't create the device map entry\n");
		goto ErrorFreeBuffer;
	}

	deviceExtension->CreatedSerialCommEntry = TRUE;
	
	// option: client can use GUID interface open our fake comm port.
    ntStatus = UsbCom_SymbolicLink( PhysicalDeviceObject, &deviceLinkUnicodeString);

    if (!NT_SUCCESS(ntStatus)) {
		DbgPrint("Couldn't register symbolic link interface!\n");
		goto ErrorFreeBuffer;
	}

    // Name buffer for our named Functional device object link
    // The name is generated based on the driver's class GUID
    RtlCopyMemory(deviceExtension->DeviceLinkNameBuffer,
                      deviceLinkUnicodeString.Buffer,
                      deviceLinkUnicodeString.Length);

	RtlInitUnicodeString ( &deviceExtension->DeviceNameLink, deviceExtension->DeviceLinkNameBuffer );

	DbgPrint ( "DO=%08x SYMBOLIC LINK = %wZ\n", (*DeviceObject), &deviceExtension->DeviceNameLink );

	// don't confuse with this lable, only ntStatus != STATUS_SUCCESS
	// means error.
ErrorFreeBuffer: 

	if (!NT_SUCCESS(ntStatus) && (*DeviceObject != NULL)) {

		//
		// Create Device Object failed, Clean up error conditions
		//
		DbgPrint("AddDevice Error: Clean up error conditions\n");

		if (deviceExtension->WorkItem != NULL) {
			IoFreeWorkItem(deviceExtension->WorkItem);
		}
		DbgPrint("AddDevice Error: Clean up error conditions\n");

		if (deviceExtension->CreatedSymbolicLink ==  TRUE) {
			IoDeleteSymbolicLink(&deviceExtension->SymbolicLinkName);
			deviceExtension->CreatedSymbolicLink = FALSE;
		}

		if (deviceExtension->SymbolicLinkName.Buffer != NULL) {
			 ExFreePool(deviceExtension->SymbolicLinkName.Buffer);
			 deviceExtension->SymbolicLinkName.Buffer = NULL;
		}

		if (deviceExtension->DeviceName.Buffer != NULL) {
			 RtlDeleteRegistryValue(RTL_REGISTRY_DEVICEMAP, SERIAL_DEVICE_MAP,
									deviceExtension->DeviceName.Buffer);
		}

		if (deviceExtension->DeviceName.Buffer != NULL) {
			ExFreePool(deviceExtension->DeviceName.Buffer);
		}



		if (*DeviceObject) {
			IoDeleteDevice(*DeviceObject);
		}
	}

	//
	// Always clean up our temp buffers.
	//
	if (linkName.Buffer != NULL) {
		ExFreePool(linkName.Buffer);
	}

	if (pRegName != NULL) {
		ExFreePool(pRegName);
	}
	
	if (deviceObjName.Buffer != NULL) {
		ExFreePool(deviceObjName.Buffer);
	}

	//free buffer from unicode string we used to init interface
	if (deviceLinkUnicodeString.Buffer != NULL){
		IoSetDeviceInterfaceState (&deviceLinkUnicodeString, FALSE);
		ExFreePool( deviceLinkUnicodeString.Buffer );
	}

    return ntStatus;
}


NTSTATUS
UsbCom_CallUSBD(
    IN PDEVICE_OBJECT DeviceObject,
    IN PURB Urb
    )
/*++

Routine Description:

    Passes a URB to the USBD class driver
	The client device driver passes USB request block (URB) structures 
	to the class driver as a parameter in an IRP with Irp->MajorFunction
	set to IRP_MJ_INTERNAL_DEVICE_CONTROL and the next IRP stack location 
	Parameters.DeviceIoControl.IoControlCode field set to 
	IOCTL_INTERNAL_USB_SUBMIT_URB. 

Arguments:

    DeviceObject - pointer to the physical device object (PDO)

    Urb - pointer to an already-formatted Urb request block

Return Value:

    STATUS_SUCCESS if successful,
    STATUS_UNSUCCESSFUL otherwise

--*/
{
    NTSTATUS ntStatus, status = STATUS_SUCCESS;
    PDEVICE_EXTENSION deviceExtension;
    PIRP irp;
    KEVENT event;
    IO_STATUS_BLOCK ioStatus;
    PIO_STACK_LOCATION nextStack;


    deviceExtension = DeviceObject->DeviceExtension;

    KeInitializeEvent(&event, NotificationEvent, FALSE);

    irp = IoBuildDeviceIoControlRequest(
                IOCTL_INTERNAL_USB_SUBMIT_URB,
                deviceExtension->TopOfStackDeviceObject, //Points to the next-lower driver's device object
                NULL, // optional input bufer; none needed here
                0,	  // input buffer len if used
                NULL, // optional output bufer; none needed here
                0,    // output buffer len if used
                TRUE, // If InternalDeviceControl is TRUE the target driver's Dispatch
				      //  outine for IRP_MJ_INTERNAL_DEVICE_CONTROL or IRP_MJ_SCSI 
					  // is called; otherwise, the Dispatch routine for 
					  // IRP_MJ_DEVICE_CONTROL is called.
                &event,     // event to be signalled on completion
                &ioStatus);  // Specifies an I/O status block to be set when the request is completed the lower driver. 


    //
    // As an alternative, we could call KeDelayExecutionThread, wait for some
    // period of time, and try again....but we keep it simple for right now
    //
    if (!irp) {
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    //
    // Call the class driver to perform the operation.  If the returned status
    // is PENDING, wait for the request to complete.
    //

    nextStack = IoGetNextIrpStackLocation(irp);

    //
    // pass the URB to the USB driver stack
    //
    nextStack->Parameters.Others.Argument1 = Urb;

    DbgPrint("UsbCom_CallUSBD() (%u) DO=%08x Urb=%08x Irp=%08x\n", UsbCom_CallUSBD_Counter++,
		DeviceObject, Urb, irp );
		
    ntStatus = IoCallDriver(deviceExtension->TopOfStackDeviceObject, irp);

    //DbgPrint("UsbCom_CallUSBD() return from IoCallDriver USBD %x\n", ntStatus);

    if (ntStatus == STATUS_PENDING) {
        KeWaitForSingleObject(
                       &event,
                       Suspended,
                       KernelMode,
                       FALSE,
                       NULL);

    } else {
        ioStatus.Status = ntStatus;
    }

//    DbgPrint("exit UsbCom_CallUSBD DO=%08x Urb=%08x(%08x) Irp=%08x(%08x)\n", DeviceObject, 
//		Urb, Urb->UrbHeader.Status, irp, ioStatus.Status );

    //
    // USBD maps the error code for us
    //
    ntStatus = ioStatus.Status;

    return ntStatus;
}


NTSTATUS
UsbCom_ConfigureDevice(
    IN  PDEVICE_OBJECT DeviceObject
    )
{
    PDEVICE_EXTENSION deviceExtension;
    NTSTATUS ntStatus;
    PURB urb;
    ULONG Size;

    DbgPrint("enter UsbCom_ConfigureDevice\n");

    deviceExtension = DeviceObject->DeviceExtension;

    if ( ( urb = ExAllocatePool(NonPagedPool, sizeof(struct _URB_CONTROL_DESCRIPTOR_REQUEST)) ) == NULL ) { 
		DbgPrint("UsbCom_ConfigureDevice() DO=%08x ExAllocatePool(URB_CONTROL_DESCRIPTOR_REQUEST) : FAIL\n",
						DeviceObject );
		ntStatus = STATUS_INSUFFICIENT_RESOURCES;	
		goto UsbCom_ConfigureDevice_Exit1;
	}

	if ( ( deviceExtension->UsbConfigurationDescriptor = ExAllocatePool(NonPagedPool, sizeof(USB_CONFIGURATION_DESCRIPTOR) ) ) == NULL ) {		
		DbgPrint("UsbCom_ConfigureDevice() DO=%08x ExAllocatePool(USB_CONFIGURATION_DESCRIPTOR+512) : FAIL\n",
						DeviceObject );
		ntStatus = STATUS_INSUFFICIENT_RESOURCES;	
		goto UsbCom_ConfigureDevice_Exit2;
	}

	UsbBuildGetDescriptorRequest(
		urb,
		(USHORT) sizeof (struct _URB_CONTROL_DESCRIPTOR_REQUEST),
		USB_CONFIGURATION_DESCRIPTOR_TYPE,
		0,
		0,
		deviceExtension->UsbConfigurationDescriptor,
		NULL,
		sizeof (USB_CONFIGURATION_DESCRIPTOR),
		NULL);

	ntStatus = UsbCom_CallUSBD(DeviceObject, urb);

	if (!(NT_SUCCESS(ntStatus))) {	
		DbgPrint("UsbCom_ConfigureDevice() DO=%08x Urb=%08x CallUSBD() 1 FAIL=%08x\n", 
			DeviceObject, urb, ntStatus );
		goto UsbCom_ConfigureDevice_Exit3;
	}
	
	Size = deviceExtension->UsbConfigurationDescriptor->wTotalLength;

    ExFreePool(deviceExtension->UsbConfigurationDescriptor);

	if ( ( deviceExtension->UsbConfigurationDescriptor = ExAllocatePool(NonPagedPool, Size ) ) == NULL ) {		
		DbgPrint("UsbCom_ConfigureDevice() DO=%08x ExAllocatePool(%d) : FAIL\n", DeviceObject, Size );
		ntStatus = STATUS_INSUFFICIENT_RESOURCES;	
		goto UsbCom_ConfigureDevice_Exit2;
	}
	

	UsbBuildGetDescriptorRequest(
		urb,
		(USHORT) sizeof (struct _URB_CONTROL_DESCRIPTOR_REQUEST),
		USB_CONFIGURATION_DESCRIPTOR_TYPE,
		0,
		0,
		deviceExtension->UsbConfigurationDescriptor,
		NULL,
		Size,
		NULL);

	ntStatus = UsbCom_CallUSBD(DeviceObject, urb);

	if (!(NT_SUCCESS(ntStatus))) {	
		DbgPrint("UsbCom_ConfigureDevice() DO=%08x Urb=%08x CallUSBD() 2 FAIL=%08x\n", 
			DeviceObject, urb, ntStatus );
		goto UsbCom_ConfigureDevice_Exit3;
	}
	
    ExFreePool(urb);

    ntStatus = UsbCom_SelectInterface(DeviceObject,
        deviceExtension->UsbConfigurationDescriptor);

	return ntStatus;
	
UsbCom_ConfigureDevice_Exit3 :
	ExFreePool ( deviceExtension->UsbConfigurationDescriptor );	

UsbCom_ConfigureDevice_Exit2 :
    ExFreePool(urb);

UsbCom_ConfigureDevice_Exit1 :
    return ntStatus;
} 


NTSTATUS
UsbCom_SelectInterface(
    IN PDEVICE_OBJECT DeviceObject,
    IN PUSB_CONFIGURATION_DESCRIPTOR ConfigurationDescriptor
    )
/*++

Routine Description:

    Initializes interface;
	This minidriver only supports one interface (with multiple endpoints).

Arguments:

    DeviceObject - pointer to the device object for this instance of the 82930
                    device.

    ConfigurationDescriptor - pointer to the USB configuration
                    descriptor containing the interface and endpoint
                    descriptors.

Return Value:

    NT status code

--*/
{
    PDEVICE_EXTENSION deviceExtension;
    NTSTATUS ntStatus;
    PURB urb = NULL;
    ULONG i;
    PUSB_INTERFACE_DESCRIPTOR InterfaceDescriptor = NULL;
	PUSBD_INTERFACE_INFORMATION InterfaceInformation = NULL;
    USHORT siz;
    ULONG j;
    ULONG x;
	PVOID StartPosition;
	ULONG lTotalInterfaces;
   	USBD_INTERFACE_LIST_ENTRY InterfaceList[2];
 
    deviceExtension = DeviceObject->DeviceExtension;
    
   	lTotalInterfaces = ConfigurationDescriptor->bNumInterfaces;

	for ( i = 0 ; i < 2 ; i ++ ) {
		InterfaceList[i].InterfaceDescriptor = NULL;
		InterfaceList[i].Interface           = NULL;
	}

	DbgPrint("UsbCom_SelectInterface() DO=%08x Interfaces=%d\n", DeviceObject, lTotalInterfaces );

	StartPosition = (PVOID)((ULONG)ConfigurationDescriptor + (ULONG)(ConfigurationDescriptor->bLength));

    InterfaceList[0].InterfaceDescriptor = USBD_ParseConfigurationDescriptorEx (
			ConfigurationDescriptor,
			StartPosition, //search from start of config  descriptro
			0,		// try interface #0
			-1,   // not interested in alternate setting here either
			-1,   // interface class not a criteria
			-1,   // interface subclass not a criteria
			-1 );   // interface protocol not a criteria

	deviceExtension->ChannelNumber = 0;

	if ( InterfaceList[0].InterfaceDescriptor == NULL ) {

		DbgPrint("UsbCom_SelectInterface() DO=%08x USBD_ParseConfigurationDescriptorEx() Interfaces[0] : FAIL \n", DeviceObject );

		InterfaceList[0].InterfaceDescriptor = USBD_ParseConfigurationDescriptorEx (
				ConfigurationDescriptor,
				StartPosition, //search from start of config  descriptro
				1,		// try interface #1
				-1,   // not interested in alternate setting here either
				-1,   // interface class not a criteria
				-1,   // interface subclass not a criteria
				-1 );   // interface protocol not a criteria
				
		deviceExtension->ChannelNumber = 1;
	}
	
	if ( InterfaceList[0].InterfaceDescriptor == NULL ) {
		DbgPrint("UsbCom_SelectInterface() DO=%08x USBD_ParseConfigurationDescriptorEx() Interfaces[1] : FAIL \n", DeviceObject );
		goto UsbCom_SelectInterface_Exit1;
	}
  
    if ( ( urb = USBD_CreateConfigurationRequestEx(ConfigurationDescriptor, InterfaceList) ) == NULL ) {
        DbgPrint("UsbCom_SelectInterface() DO=%08x USBD_CreateConfigurationRequest() : FAIL\n", DeviceObject );
        ntStatus = STATUS_INSUFFICIENT_RESOURCES;    
		goto UsbCom_SelectInterface_Exit1;
    }

	InterfaceDescriptor = InterfaceList[0].InterfaceDescriptor;
	InterfaceInformation = InterfaceList[0].Interface;

	for (x = 0 ; x < InterfaceInformation->NumberOfPipes ; x++) {
		InterfaceInformation->Pipes[x].MaximumTransferSize = deviceExtension->MaximumTransferSize;
		InterfaceInformation->Pipes[x].PipeFlags = 0;
	}

	InterfaceInformation->Length = GET_USBD_INTERFACE_SIZE( InterfaceDescriptor->bNumEndpoints );
	InterfaceInformation->InterfaceNumber = InterfaceDescriptor->bInterfaceNumber;
	InterfaceInformation->AlternateSetting = InterfaceDescriptor->bAlternateSetting;
 
    ntStatus = UsbCom_CallUSBD(DeviceObject, urb);

	if ( ! NT_SUCCESS(ntStatus)) {
		DbgPrint("UsbCom_SelectInterface() DO=%08x UsbCom_CallUSBD() : FAIL=%08x\n", DeviceObject, ntStatus );
		goto UsbCom_SelectInterface_Exit2;
	}
	
    deviceExtension->UsbConfigurationHandle =  urb->UrbSelectConfiguration.ConfigurationHandle;
	
	ExFreePool  ( urb );

    //
    // Save the configuration handle for this device
    //

    //deviceExtension->UsbConfigurationHandle =
        //urb->UrbSelectConfiguration.ConfigurationHandle;

    if ( ( deviceExtension->UsbInterface = ExAllocatePool(NonPagedPool, InterfaceInformation->Length) ) == NULL ) {
		DbgPrint("UsbCom_SelectInterface() DO=%08x ExAllocatePool(%d) : FAIL\n", DeviceObject, InterfaceInformation->Length );
		goto UsbCom_SelectInterface_Exit1;
    }


    //
    // save a copy of the interface information returned
    //
    RtlCopyMemory(deviceExtension->UsbInterface, InterfaceInformation, InterfaceInformation->Length);

    //
    // Dump the interface to the debugger
    //
    DbgPrint("---------\n");
    DbgPrint("NumberOfPipes 0x%x\n", deviceExtension->UsbInterface->NumberOfPipes);
    DbgPrint("Length 0x%x\n", deviceExtension->UsbInterface->Length);
    DbgPrint("Alt Setting 0x%x\n", deviceExtension->UsbInterface->AlternateSetting);
    DbgPrint("Interface Number 0x%x\n", deviceExtension->UsbInterface->InterfaceNumber);
    DbgPrint("Class, subclass, protocol 0x%x 0x%x 0x%x\n",
        deviceExtension->UsbInterface->Class,
        deviceExtension->UsbInterface->SubClass,
        deviceExtension->UsbInterface->Protocol);

    // Dump the pipe info

    for (j=0; j<InterfaceInformation->NumberOfPipes; j++) {
        PUSBD_PIPE_INFORMATION pipeInformation;

        pipeInformation = &deviceExtension->UsbInterface->Pipes[j];

        DbgPrint("---------\n");
        DbgPrint("PipeType 0x%x\n", pipeInformation->PipeType);
        DbgPrint("EndpointAddress 0x%x\n", pipeInformation->EndpointAddress);
        DbgPrint("MaxPacketSize 0x%x\n", pipeInformation->MaximumPacketSize);
        DbgPrint("Interval 0x%x\n", pipeInformation->Interval);
        DbgPrint("Handle 0x%x\n", pipeInformation->PipeHandle);
        DbgPrint("MaximumTransferSize 0x%x\n", pipeInformation->MaximumTransferSize);
        switch (pipeInformation->PipeType) {       

                case UsbdPipeTypeBulk:
                    if (USBD_PIPE_DIRECTION_IN(pipeInformation)) {
                        DbgPrint("DataInPipe 0x%x\n", j);
                        deviceExtension->DataInPipe = j;
                    } else {
                        DbgPrint("DataOutPipe 0x%x\n", j);
                        deviceExtension->DataOutPipe = j;
                    }
                    break;
	

                case UsbdPipeTypeInterrupt:
                    DbgPrint("InterruptPipe 0x%x\n", j);
                    deviceExtension->InterruptPipe = j;
                    break;


                default:
                    DbgPrint("Unknown pipe 0x%x\n", j);
                    break;
		}
	}

    DbgPrint("---------\n");
    
    return STATUS_SUCCESS;

 /*
#ifndef USE_SMARTNIC

    // .........Kawshol........
    // Retrieve the selected Configuration and Interface setting from the
    // device.  (The only purpose of doing this here is to exercise the
    // URB_FUNCTION_GET_CONFIGURATION and URB_FUNCTION_GET_INTERFACE
    // requests).
    //
   if (NT_SUCCESS(ntStatus)) {

        urb = ExAllocatePool(
                  NonPagedPool,
                  sizeof(struct _URB_CONTROL_GET_CONFIGURATION_REQUEST) + 1);

        if (urb)
        {
            PUCHAR configuration;

            configuration = (PUCHAR)urb + sizeof(struct 
            _URB_CONTROL_GET_CONFIGURATION_REQUEST);
            *configuration = 0xFF;

            urb->UrbHeader.Function = URB_FUNCTION_GET_CONFIGURATION;
            urb->UrbHeader.Length = sizeof(struct 
            _URB_CONTROL_GET_CONFIGURATION_REQUEST);
            urb->UrbControlGetConfigurationRequest.TransferBufferLength = 1;
            urb->UrbControlGetConfigurationRequest.TransferBuffer = 
            configuration;
            urb->UrbControlGetConfigurationRequest.TransferBufferMDL = NULL;
            urb->UrbControlGetConfigurationRequest.UrbLink = NULL;

            ntStatus = UsbCom_CallUSBD(DeviceObject, urb);

            DbgPrint ("D12TEST.SYS: Configuration %d (%x)\n",
                             *configuration, ntStatus);

            ExFreePool(urb);
            urb = NULL;
        }

        urb = ExAllocatePool(
                  NonPagedPool,
                  sizeof(struct _URB_CONTROL_GET_INTERFACE_REQUEST) + 1);

        if (urb)
        {
            PUCHAR interface;

            interface = (PUCHAR)urb + sizeof(struct 
            _URB_CONTROL_GET_INTERFACE_REQUEST);
            *interface = 0xFF;

            urb->UrbHeader.Function = URB_FUNCTION_GET_INTERFACE;
            urb->UrbHeader.Length = sizeof(struct 
            _URB_CONTROL_GET_INTERFACE_REQUEST);
            urb->UrbControlGetInterfaceRequest.TransferBufferLength = 1;
            urb->UrbControlGetInterfaceRequest.TransferBuffer = interface;
            urb->UrbControlGetInterfaceRequest.TransferBufferMDL = NULL;
            urb->UrbControlGetInterfaceRequest.UrbLink = NULL;
            urb->UrbControlGetInterfaceRequest.Interface =
                deviceExtension->UsbInterface->InterfaceNumber;

            ntStatus = UsbCom_CallUSBD(DeviceObject, urb);

            DbgPrint ("D12TEST.SYS: Interface %d (%x)\n",
                             *interface, ntStatus);

            ExFreePool(urb);
            urb = NULL;
        }
    } 
   
   // kawshol
#endif
*/

UsbCom_SelectInterface_Exit2:
	ExFreePool ( urb );
	
UsbCom_SelectInterface_Exit1:
    return ntStatus; 
}



NTSTATUS
UsbCom_ResetPipe(
    IN PDEVICE_OBJECT DeviceObject,
    IN PUSBD_PIPE_INFORMATION PipeInfo
    )
/*++

Routine Description:

    Reset a given USB pipe.

    NOTES:

    This will reset the host to Data0 and should also reset the device to Data0 

Arguments:

    Ptrs to our FDO and a USBD_PIPE_INFORMATION struct

Return Value:

    NT status code

--*/
{
    NTSTATUS ntStatus;
    PURB urb;
    PDEVICE_EXTENSION deviceExtension;

    deviceExtension = DeviceObject->DeviceExtension;

    DbgPrint("UsbCom_ResetPipe() Reset Pipe %x\n", PipeInfo);

    urb = ExAllocatePool(NonPagedPool,
                         sizeof(struct _URB_PIPE_REQUEST));

    if (urb) {

        urb->UrbHeader.Length = (USHORT) sizeof (struct _URB_PIPE_REQUEST);
        urb->UrbHeader.Function = URB_FUNCTION_RESET_PIPE;
        urb->UrbPipeRequest.PipeHandle =
            PipeInfo->PipeHandle;

        ntStatus = UsbCom_CallUSBD(DeviceObject, urb);

        ExFreePool(urb);

    } else {
        ntStatus = STATUS_INSUFFICIENT_RESOURCES;
    }

    if (!(NT_SUCCESS(ntStatus))) {
        DbgPrint("UsbCom_ResetPipe() FAILED, ntStatus =0x%x\n", ntStatus );
    }
    else {
        DbgPrint("UsbCom_ResetPipe() SUCCESS, ntStatus =0x%x\n", ntStatus );
    }

    return ntStatus;
}


NTSTATUS
UsbCom_Create(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    )
/*++

Routine Description:

    This is the dispatch table routine for IRP_MJ_CREATE.
    It's the entry point for CreateFile() calls

Arguments:

    DeviceObject - pointer to our FDO ( Functional Device Object )


Return Value:

    NT status code

--*/
{
    NTSTATUS ntStatus = STATUS_SUCCESS;
    PFILE_OBJECT fileObject;
    PIO_STACK_LOCATION irpStack;
    PDEVICE_EXTENSION deviceExtension;
    ULONG i, ix;
	NTSTATUS actStat;
    PUSBD_INTERFACE_INFORMATION interface;
	PUSBD_PIPE_INFORMATION PipeInfo;
    PUsbCom_PIPEINFO ourPipeInfo = NULL;


    deviceExtension = DeviceObject->DeviceExtension;
    interface = deviceExtension->UsbInterface;

    DbgPrint("entering UsbCom_Create DO=%8x Irp=%08x\n", DeviceObject, Irp );

    UsbCom_IncrementIoCount(DeviceObject);

    // Can't accept a new io request if:
    //  1) device is removed, 
    //  2) has never been started, 
    //  3) is stopped,
    //  4) has a remove request pending,
    //  5) has a stop device pending
    if ( !UsbCom_CanAcceptIoRequests( DeviceObject ) ) {
        ntStatus = STATUS_DELETE_PENDING;

		DbgPrint("ABORTING UsbCom_Create\n");
        goto done;
    }
    
    irpStack = IoGetCurrentIrpStackLocation (Irp);

    //
    // Create a buffer for the RX data when no reads are outstanding.
    //

    deviceExtension->InterruptReadBuffer = NULL;
    deviceExtension->BufferSize = 0;

    switch (MmQuerySystemSize()) {

        case MmLargeSystem: {

            deviceExtension->BufferSize = 4096;
            deviceExtension->InterruptReadBuffer = ExAllocatePool(
                                                 NonPagedPool,
                                                 deviceExtension->BufferSize
                                                 );

            if (deviceExtension->InterruptReadBuffer) {

                break;

            }

        }

        case MmMediumSystem: {

            deviceExtension->BufferSize = 1024;
            deviceExtension->InterruptReadBuffer = ExAllocatePool(
                                                 NonPagedPool,
                                                 deviceExtension->BufferSize
                                                 );

            if (deviceExtension->InterruptReadBuffer) {

                break;

            }

        }

        case MmSmallSystem: {

            deviceExtension->BufferSize = 128;
            deviceExtension->InterruptReadBuffer = ExAllocatePool(
                                                 NonPagedPool,
                                                 deviceExtension->BufferSize
                                                 );

        }

    }

	//DbgPrint("Interrupt buffer size is %d\n", deviceExtension->BufferSize);

    if (!deviceExtension->InterruptReadBuffer) {
       ExReleaseFastMutex(&deviceExtension->OpenMutex);

        deviceExtension->BufferSize = 0;
        Irp->IoStatus.Status = STATUS_INSUFFICIENT_RESOURCES;
        Irp->IoStatus.Information = 0;

        SerialDump(
            SERIRPPATH,
            ("SERIAL: Complete Irp: %x\n",Irp)
            );

        InterlockedDecrement(&deviceExtension->OpenCount);
        SerialCompleteRequest(deviceExtension, Irp, IO_NO_INCREMENT);

        return STATUS_INSUFFICIENT_RESOURCES;

    }

    //
    // Ok, it looks like we really are going to open.  Lock down the
    // driver.
    //
//    SerialLockPagableSectionByHandle(SerialGlobals.PAGESER_Handle); henry

    //
    // Power up the stack
    //

//    (void)SerialGotoPowerState(DeviceObject, deviceExtension, PowerDeviceD0); henry

    //
    // Not currently waiting for wake up
    //

    deviceExtension->SendWaitWake = FALSE;

    //
    // On a new open we "flush" the read queue by initializing the
    // count of characters.
    //

    deviceExtension->CharsInInterruptBuffer = 0;
    deviceExtension->LastCharSlot = deviceExtension->InterruptReadBuffer +
                              (deviceExtension->BufferSize - 1);

    deviceExtension->ReadBufferBase = deviceExtension->InterruptReadBuffer;
    deviceExtension->CurrentCharSlot = deviceExtension->InterruptReadBuffer;
    deviceExtension->FirstReadableChar = deviceExtension->InterruptReadBuffer;

    deviceExtension->TotalCharsQueued = 0;

    //
    // We set up the default xon/xoff limits.
    //

    deviceExtension->HandFlow.XoffLimit = deviceExtension->BufferSize >> 3;
    deviceExtension->HandFlow.XonLimit = deviceExtension->BufferSize >> 1;

    deviceExtension->WmiCommData.XoffXmitThreshold = deviceExtension->HandFlow.XoffLimit;
    deviceExtension->WmiCommData.XonXmitThreshold = deviceExtension->HandFlow.XonLimit;

    deviceExtension->BufferSizePt8 = ((3*(deviceExtension->BufferSize>>2))+
                                   (deviceExtension->BufferSize>>4));

	deviceExtension->ToSubmitReadUrb = TRUE;
	deviceExtension->NoReadUrb = FALSE;

    //
    // Mark the device as busy for WMI
    //

    deviceExtension->WmiCommData.IsBusy = TRUE;

    deviceExtension->IrpMaskLocation = NULL;
    deviceExtension->HistoryMask = 0;
    deviceExtension->IsrWaitMask = 0;

    deviceExtension->SendXonChar = FALSE;
    deviceExtension->SendXoffChar = FALSE;


    //
    // The escape char replacement must be reset upon every open.
    //

    deviceExtension->EscapeChar = 0;

done:

	Irp->IoStatus.Status = ntStatus;
    Irp->IoStatus.Information = 0;
	deviceExtension->DeviceIsOpened = TRUE;

    IoCompleteRequest (Irp,
                       IO_NO_INCREMENT
                       );

    UsbCom_DecrementIoCount(DeviceObject);                               

    DbgPrint("exit UsbCom_Create %x\n", ntStatus);


    return ntStatus;
}



LONG
UsbCom_DecrementIoCount(
    IN PDEVICE_OBJECT DeviceObject
    )
/*++

Routine Description:

        We keep a pending IO count ( extension->PendingIoCount )  in the device extension.
        The first increment of this count is done on adding the device.
        Subsequently, the count is incremented for each new IRP received and
        decremented when each IRP is completed or passed on.

        Transition to 'one' therefore indicates no IO is pending and signals
        deviceExtension->NoPendingIoEvent. This is needed for processing
        IRP_MN_QUERY_REMOVE_DEVICE

        Transition to 'zero' signals an event ( deviceExtension->RemoveEvent )
        to enable device removal. This is used in processing for IRP_MN_REMOVE_DEVICE
 
Arguments:

        DeviceObject -- ptr to our FDO

Return Value:

        deviceExtension->PendingIoCount


--*/

{
    PDEVICE_EXTENSION deviceExtension;
    LONG ioCount;
    KIRQL             oldIrql;

    deviceExtension = DeviceObject->DeviceExtension;
	KeAcquireSpinLock (&deviceExtension->IoCountSpinLock, &oldIrql);

    ioCount = InterlockedDecrement(&deviceExtension->PendingIoCount);

//    ASSERT(0 <= ioCount);

	if (ioCount > 1)
		KeResetEvent(&deviceExtension->NoPendingIoEvent);

    if (ioCount==1) {
        // trigger no pending io
        KeSetEvent(&deviceExtension->NoPendingIoEvent,
                   1,
                   FALSE);
    }

    if (ioCount==0) {
        // trigger remove-device event
        KeSetEvent(&deviceExtension->RemoveEvent,
                   1,
                   FALSE);
    }
	KeReleaseSpinLock (&deviceExtension->IoCountSpinLock, oldIrql);

//    DbgPrint("Exit UsbCom_DecrementIoCount() Pending io count = %x\n", ioCount);
    return ioCount;
}


VOID
UsbCom_IncrementIoCount(
    IN PDEVICE_OBJECT DeviceObject
    )
/*++

Routine Description:

        We keep a pending IO count ( extension->PendingIoCount )  in the device extension.
        The first increment of this count is done on adding the device.
        Subsequently, the count is incremented for each new IRP received and
        decremented when each IRP is completed or passed on.

 
Arguments:

        DeviceObject -- ptr to our FDO

Return Value:

        None


--*/
{
    PDEVICE_EXTENSION deviceExtension;
    KIRQL             oldIrql;

    deviceExtension = DeviceObject->DeviceExtension;

//    DbgPrint("Enter UsbCom_IncrementIoCount() Pending io count = %x\n", deviceExtension->PendingIoCount);

	KeAcquireSpinLock (&deviceExtension->IoCountSpinLock, &oldIrql);

    InterlockedIncrement(&deviceExtension->PendingIoCount);

	KeReleaseSpinLock (&deviceExtension->IoCountSpinLock, oldIrql);

  //  DbgPrint("Exit UsbCom_IncrementIoCount() Pending io count = %x\n", deviceExtension->PendingIoCount);
}

NTSTATUS 
SerialGetRegistryKeyValue (
                          IN HANDLE Handle,
                          IN PWCHAR KeyNameString,
                          IN ULONG KeyNameStringLength,
                          IN OUT PVOID Data,
                          IN OUT PULONG DataLength
                          )
/*++

Routine Description:

    Reads a registry key value from an already opened registry key.
    
Arguments:

    Handle              Handle to the opened registry key
    
    KeyNameString       ANSI string to the desired key

    KeyNameStringLength Length of the KeyNameString

    Data                Buffer to place the key value in

    DataLength          Length of the data buffer

Return Value:

    STATUS_SUCCESS if all works, otherwise status of system call that
    went wrong.

--*/
{
   UNICODE_STRING              keyName;
   ULONG                       length;
   PKEY_VALUE_FULL_INFORMATION fullInfo;

   NTSTATUS                    ntStatus = STATUS_INSUFFICIENT_RESOURCES;

   PAGED_CODE();

   DbgPrint("Enter SerialGetRegistryKeyValue\n");


   RtlInitUnicodeString (&keyName, KeyNameString);

   length = sizeof(KEY_VALUE_FULL_INFORMATION) + KeyNameStringLength
      + *DataLength;
   fullInfo = ExAllocatePool(PagedPool, length); 

   if (fullInfo) {
      ntStatus = ZwQueryValueKey (Handle,
                                  &keyName,
                                  KeyValueFullInformation,
                                  fullInfo,
                                  length,
                                  &length);

      if (NT_SUCCESS(ntStatus)) {
         //
         // If there is enough room in the data buffer, copy the output
         //

         if (*DataLength >= fullInfo->DataLength) {
			*DataLength = fullInfo->DataLength;
            RtlCopyMemory (Data, 
                           ((PUCHAR) fullInfo) + fullInfo->DataOffset, 
                           fullInfo->DataLength);
         }
      }

      ExFreePool(fullInfo);
   }

   return ntStatus;
}

LARGE_INTEGER
SerialGetCharTime(
    IN PDEVICE_EXTENSION Extension
    )

/*++

Routine Description:

    This function will return the number of 100 nanosecond intervals
    there are in one character time (based on the present form
    of flow control.

Arguments:

    Extension - Just what it says.

Return Value:

    100 nanosecond intervals in a character time.

--*/

{

    ULONG dataSize;
    ULONG paritySize;
    ULONG stopSize;
    ULONG charTime;
    ULONG bitTime;
    LARGE_INTEGER tmp;


    if ((Extension->LineControl & SERIAL_DATA_MASK) == SERIAL_5_DATA) {
        dataSize = 5;
    } else if ((Extension->LineControl & SERIAL_DATA_MASK)
                == SERIAL_6_DATA) {
        dataSize = 6;
    } else if ((Extension->LineControl & SERIAL_DATA_MASK)
                == SERIAL_7_DATA) {
        dataSize = 7;
    } else if ((Extension->LineControl & SERIAL_DATA_MASK)
                == SERIAL_8_DATA) {
        dataSize = 8;
    }

    paritySize = 1;
    if ((Extension->LineControl & SERIAL_PARITY_MASK)
            == SERIAL_NONE_PARITY) {

        paritySize = 0;

    }

    if (Extension->LineControl & SERIAL_2_STOP) {

        //
        // Even if it is 1.5, for sanities sake were going
        // to say 2.
        //

        stopSize = 2;

    } else {

        stopSize = 1;

    }

    //
    // First we calculate the number of 100 nanosecond intervals
    // are in a single bit time (Approximately).
    //

    bitTime = (10000000+(Extension->CurrentBaud-1))/Extension->CurrentBaud;
    charTime = bitTime + ((dataSize+paritySize+stopSize)*bitTime);

    tmp.QuadPart = charTime;
    return tmp;

}


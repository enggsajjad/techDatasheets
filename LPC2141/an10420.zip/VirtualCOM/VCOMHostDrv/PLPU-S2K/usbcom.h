/*++

Module Name:

    USBCOM.H

Abstract:

	Kernel mode definitions and function prototypes

Environment:

    Kernel mode

Notes:

  Copyright (c) 1997-2000 Maverick Corporation.  All Rights Reserved.

Revision History:

    04/26/00 : created

--*/
#ifndef USBCOM_INCD
#define USBCOM_INCD


#include "ntddser.h"
#include "BusbDbg.h"
#include "serial.h"
#include "wmidata.h"
#include "wmilib.h"

// the size of the transfer buffer on your test board or device
#define UsbCom_TEST_BOARD_TRANSFER_BUFFER_SIZE (64 *1024 )
#define THREAD_DELAY_VALUE            (ULONG)(-1 * 1 * 1000)     // 0.5 ms
//
// Default xon/xoff characters.
//
#define SERIAL_DEF_XON 0x11
#define SERIAL_DEF_XOFF 0x13

#define THREAD_NOTIFIED 0
#define DATA_REQUEST_EVENT   1
#define BULK_REQUEST_COMPLETED 2
#define WRITE_DATA_EVENT   1
#define WRITE_COMPLETE_NOTIFY 2

//Flags values
#define IO_FLAGS_DATA_IN 1
#define IO_FLAGS_DATA_OUT 2
#define IO_FLAGS_SCATTER_GATHER 4

#define READ_REQUEST		0 
#define	WRITE_REQUEST		1

#define SYMBOLIC_NAME_LENGTH        128
#define DEVICE_OBJECT_NAME_LENGTH   128
#define UsbCom_MAX_TRANSFER_SIZE	256
#define SERIAL_DEVICE_MAP           L"SERIALCOMM"
//#define DEFAULT_DIRECTORY			L"DosDevices"

#define MIN(a,b) ((a) < (b) ? (a) :(b))
#define max(a, b)  (((a) > (b)) ? (a) : (b))

// used to track driver-generated io irps for staged read/write processing
typedef struct _UsbCom_RW_CONTEXT {
    PURB Urb;
    PDEVICE_OBJECT DeviceObject;
    PIRP  Irp;
    PMDL  Mdl;
} UsbCom_RW_CONTEXT, *PUsbCom_RW_CONTEXT;

typedef struct _IOPACKET
{
        ULONG   Fdo;
        PVOID   Iop;
        UCHAR*  Cdb;
        UCHAR   CdbLength ;
        PUCHAR   DataBuffer;
        ULONG   DataLength;
        ULONG   BlockSize;
        ULONG   Flags;
        ULONG   Status;
        ULONG   BytesXmitOrRecv;
        ULONG   RequestType;
        ULONG   VxdSerObjContext;
        ULONG   VxdSerIOPacketContext;
        ULONG   WdmSerialContext;
        UCHAR   DummyBuffer[2048];
} IOPACKET, *PIOPACKET;

typedef struct _pack_2_pointers
{
   PVOID pointer1;
   PVOID pointer2;
}  PACK_TWO_POINTERS, * P_PACK_TWO_POINTERS;

// used to track information on pipes in use;
//  currently just to flag if opened or closed
typedef struct UsbCom_PIPEINFO {

    BOOLEAN fPipeOpened;

} UsbCom_PIPEINFO, *PUsbCom_PIPEINFO;


extern ULONG GlobalPdaCount;

#define OutPipeMaxSize	16

//
// A structure representing the instance information associated with
// this particular device.
//
typedef struct _DEVICE_EXTENSION {

    // Device object we call when submitting Urbs
    PDEVICE_OBJECT TopOfStackDeviceObject;

	// The bus driver object
    PDEVICE_OBJECT PhysicalDeviceObject;

    //
    // This points to the symbolic link name that will be
    // linked to the actual nt device name.
    //
    UNICODE_STRING SymbolicLinkName;

    //
    // We keep a pointer around to our device name for dumps
    // and for creating "external" symbolic links to this
    // device.
    //
    UNICODE_STRING DeviceName;

    //
    // Points to the device object that contains
    // this device extension.
    //
    PDEVICE_OBJECT DeviceObject;

	ULONG VxdSerObjContext;  

	// In data bulk pipe
	ULONG DataInPipe;

	// Out data bulk pipe
	ULONG DataOutPipe;

	// Status interrupt pipe
	ULONG InterruptPipe;

	// IRP used to poll for interrupts
	PIRP PollingIrp;

	// URB used to poll for interrupts
	PURB PollingUrb;
	
	BOOLEAN pollpending;					// polling irp is pending (interrupt pipe)

	// interrupt data
	UCHAR intdata[4];

	// IRP used to read
	PIRP ReadingIrp;

	// URB used to read
	PURB ReadingUrb;
	
	// Read data
	UCHAR ReadData[64];

	BOOLEAN readpending;					// reading irp is pending (IN BULK pipe)

	// IRP used to write
	PIRP WritingIrp;

	// URB used to write
	PURB WritingUrb;
	
	// Read data
	UCHAR WriteData[16];

	// Indicates number of bytes in array, WriteData to transfer.
	ULONG WriteSize;

	BOOLEAN writepending;					// writing irp is pending (OUT BULK pipe)

	ULONG CurrentSGD;
  
	PIO_WORKITEM WorkItem;
	
 	KDPC IoCtrlTimerDpc;

	KTIMER IoCtrlTimer;

	// use mutex to guard somethings.
	// Since there is a single I/O completion handler we need to make
	// sure that it is not pre-empted or called twice
	KMUTEX  CompleteRequestMutex;

	PIRP ReadIrp;
	PIRP WriteIrp;
	PIRP IoCtrlIrp;

    DEVICE_POWER_STATE CurrentDevicePowerState;

    // USB configuration handle and ptr for the configuration the
    // device is currently in
    USBD_CONFIGURATION_HANDLE UsbConfigurationHandle;
	PUSB_CONFIGURATION_DESCRIPTOR UsbConfigurationDescriptor;


    // ptr to the USB device descriptor
    // for this device
    PUSB_DEVICE_DESCRIPTOR UsbDeviceDescriptor;

    // we support one interface
    // this is a copy of the info structure
    // returned from select_configuration or
    // select_interface
    PUSBD_INTERFACE_INFORMATION UsbInterface;

	//Bus drivers set the appropriate values in this structure in response
	//to an IRP_MN_QUERY_CAPABILITIES IRP. Function and filter drivers might
	//alter the capabilities set by the bus driver.
    DEVICE_CAPABILITIES DeviceCapabilities;

	// used to save the currently-being-handled system-requested power irp request
    PIRP PowerIrp;

	// used to save base Irp ( user-originated via IOCTL ) of staged read/write request
	PIRP BaseIrp;

	// used to save  URB of short, non-staged read/write requests
	PURB BaseUrb;

	// count of self-staged irps pending
    ULONG StagedPendingIrpCount;

	// count of self-staged bytes read or written so far
    ULONG StagedBytesTransferred;

	// set when PendingIoCount goes to 0; flags device can be removed
    KEVENT RemoveEvent;

	// set when PendingIoCount goes to 1 ( 1st increment was on add device )
	// this indicates no IO requests outstanding, either user, system, or self-staged
    KEVENT NoPendingIoEvent;

	// set to signal driver-generated power request is finished
    KEVENT SelfRequestedPowerIrpEvent;

	// spinlock used to protect inc/dec iocount logic
	KSPIN_LOCK	IoCountSpinLock;

	// incremented when device is added and any IO request is received;
	// decremented when any io request is completed or passed on, and when device is removed
    ULONG PendingIoCount;

	// count of open pipes
	ULONG OpenPipeCount;

    // ptr to array of structs to track pipeinfo;
    //  in this basic sample it's only used to track if open/closed;
    PUsbCom_PIPEINFO PipeInfo;

	// save ptr to array of info on self-generated IRPS for staged read/writes;
	//  will allocate this separately
	PUsbCom_RW_CONTEXT PendingIoIrps;

	UNICODE_STRING	DeviceNameLink;

    // Name buffer for our named Functional device object link
	// The name is generated based on the driver's class GUID
    WCHAR DeviceLinkNameBuffer[ MAXIMUM_FILENAME_LENGTH ];  // MAXIMUM_FILENAME_LENGTH defined in wdm.h
	
	//flag set when processing IRP_MN_REMOVE_DEVICE
    BOOLEAN DeviceRemoved;

 	// flag set when driver has answered success to IRP_MN_QUERY_REMOVE_DEVICE
    BOOLEAN RemoveDeviceRequested;

	// flag set when driver has answered success to IRP_MN_QUERY_STOP_DEVICE
    BOOLEAN StopDeviceRequested;

	// flag set when device has been successfully started
	BOOLEAN DeviceStarted;

    // flag set when IRP_MN_WAIT_WAKE is received and we're in a power state
    // where we can signal a wait
    BOOLEAN EnabledForWakeup;

	// used to flag that we're currently handling a self-generated power request
    BOOLEAN SelfPowerIrp;

	// default power state to power down to on self-suspend 
	ULONG PowerDownLevel; 

	// default maximum transfer per staged irp size		
	ULONG MaximumTransferSize;  

	// Henry's modifications start here. 31/7/2000

    //
    // This list head is used to contain the time ordered list
    // of read requests.  Access to this list is protected by
    // the global cancel spinlock.
    //
    LIST_ENTRY ReadQueue;

    //
    // This list head is used to contain the time ordered list
    // of write requests.  Access to this list is protected by
    // the global cancel spinlock.
    //
    LIST_ENTRY WriteQueue;

    //
    // This list head is used to contain the time ordered list
    // of set and wait mask requests.  Access to this list is protected by
    // the global cancel spinlock.
    //
    LIST_ENTRY MaskQueue;

    //
    // Holds the serialized list of purge requests.
    //
    LIST_ENTRY PurgeQueue;

    //
    // This points to the irp that is currently being processed
    // for the read queue.  This field is initialized by the open to
    // NULL.
    //
    // This value is only set at dispatch level.  It may be
    // read at interrupt level.
    //
    PIRP CurrentReadIrp;

    //
    // This points to the irp that is currently being processed
    // for the write queue.
    //
    // This value is only set at dispatch level.  It may be
    // read at interrupt level.
    //
    PIRP CurrentWriteIrp;

    //
    // Points to the irp that is currently being processed to
    // affect the wait mask operations.
    //
    PIRP CurrentMaskIrp;

    //
    // Points to the irp that is currently being processed to
    // purge the read/write queues and buffers.
    //
    PIRP CurrentPurgeIrp;

    //
    // Points to the current irp that is waiting on a comm event.
    //
    PIRP CurrentWaitIrp;

    //
    // Points to the irp that is being used to send an immediate
    // character.
    //
    PIRP CurrentImmediateIrp;

    //
    // Points to the irp that is being used to count the number
    // of characters received after an xoff (as currently defined
    // by the IOCTL_SERIAL_XOFF_COUNTER ioctl) is sent.
    //
    PIRP CurrentXoffIrp;

    //
    // Holds the number of bytes remaining in the current write
    // irp.
    //
    // This location is only accessed while at interrupt level.
    //
    ULONG WriteLength;

    //
    // Holds a pointer to the current character to be sent in
    // the current write.
    //
    // This location is only accessed while at interrupt level.
    //
    PUCHAR WriteCurrentChar;

    //
    // This is a buffer for the read processing.
    //
    // The buffer works as a ring.  When the character is read from
    // the device it will be place at the end of the ring.
    //
    // Characters are only placed in this buffer at interrupt level
    // although character may be read at any level. The pointers
    // that manage this buffer may not be updated except at interrupt
    // level.
    //
    PUCHAR InterruptReadBuffer;

    //
    // This is a pointer to the first character of the buffer into
    // which the interrupt service routine is copying characters.
    //
    PUCHAR ReadBufferBase;

    //
    // This is a count of the number of characters in the interrupt
    // buffer.  This value is set and read at interrupt level.  Note
    // that this value is only *incremented* at interrupt level so
    // it is safe to read it at any level.  When characters are
    // copied out of the read buffer, this count is decremented by
    // a routine that synchronizes with the ISR.
    //
    ULONG CharsInInterruptBuffer;

    //
    // Points to the first available position for a newly received
    // character.  This variable is only accessed at interrupt level and
    // buffer initialization code.
    //
    PUCHAR CurrentCharSlot;

    //
    // This variable is used to contain the last available position
    // in the read buffer.  It is updated at open and at interrupt
    // level when switching between the users buffer and the interrupt
    // buffer.
    //
    PUCHAR LastCharSlot;

    //
    // This marks the first character that is available to satisfy
    // a read request.  Note that while this always points to valid
    // memory, it may not point to a character that can be sent to
    // the user.  This can occur when the buffer is empty.
    //
    PUCHAR FirstReadableChar;

    //
    // Pointer to the lock variable returned for this extension when
    // locking down the driver
    //
    PVOID LockPtr;


    //
    // This variable holds the size of whatever buffer we are currently
    // using.
    //
    ULONG BufferSize;

    //
    // This variable holds .8 of BufferSize. We don't want to recalculate
    // this real often - It's needed when so that an application can be
    // "notified" that the buffer is getting full.
    //
    ULONG BufferSizePt8;

	BOOLEAN ToSubmitReadUrb;

	// This flag is to indicate that there is currently no read urb in the USBD stack.
	// Although there should always be a read urb waiting for data from dongle, it is
	// stopped because the interrupt buffer is getting full (80%).
	BOOLEAN NoReadUrb;

    //
    // This value holds the number of characters desired for a
    // particular read.  It is initially set by read length in the
    // IRP.  It is decremented each time more characters are placed
    // into the "users" buffer buy the code that reads characters
    // out of the typeahead buffer into the users buffer.  If the
    // typeahead buffer is exhausted by the read, and the reads buffer
    // is given to the isr to fill, this value is becomes meaningless.
    //
    ULONG NumberNeededForRead;

    //
    // This mask will hold the bitmask sent down via the set mask
    // ioctl.  It is used by the interrupt service routine to determine
    // if the occurence of "events" (in the serial drivers understanding
    // of the concept of an event) should be noted.
    //
    ULONG IsrWaitMask;

    //
    // This mask will always be a subset of the IsrWaitMask.  While
    // at device level, if an event occurs that is "marked" as interesting
    // in the IsrWaitMask, the driver will turn on that bit in this
    // history mask.  The driver will then look to see if there is a
    // request waiting for an event to occur.  If there is one, it
    // will copy the value of the history mask into the wait irp, zero
    // the history mask, and complete the wait irp.  If there is no
    // waiting request, the driver will be satisfied with just recording
    // that the event occured.  If a wait request should be queued,
    // the driver will look to see if the history mask is non-zero.  If
    // it is non-zero, the driver will copy the history mask into the
    // irp, zero the history mask, and then complete the irp.
    //
    ULONG HistoryMask;

    //
    // This is a pointer to the where the history mask should be
    // placed when completing a wait.  It is only accessed at
    // device level.
    //
    // We have a pointer here to assist us to synchronize completing a wait.
    // If this is non-zero, then we have wait outstanding, and the isr still
    // knows about it.  We make this pointer null so that the isr won't
    // attempt to complete the wait.
    //
    // We still keep a pointer around to the wait irp, since the actual
    // pointer to the wait irp will be used for the "common" irp completion
    // path.
    //
    ULONG *IrpMaskLocation;

    //
    // This mask holds all of the reason that transmission
    // is not proceeding.  Normal transmission can not occur
    // if this is non-zero.
    //
    // This is only written from interrupt level.
    // This could be (but is not) read at any level.
    //
    ULONG TXHolding;

    //
    // This mask holds all of the reason that reception
    // is not proceeding.  Normal reception can not occur
    // if this is non-zero.
    //
    // This is only written from interrupt level.
    // This could be (but is not) read at any level.
    //
    ULONG RXHolding;

    //
    // This holds the reasons that the driver thinks it is in
    // an error state.
    //
    // This is only written from interrupt level.
    // This could be (but is not) read at any level.
    //
    ULONG ErrorWord;

    //
    // This keeps a total of the number of characters that
    // are in all of the "write" irps that the driver knows
    // about.  It is only accessed with the cancel spinlock
    // held.
    //
    ULONG TotalCharsQueued;

    //
    // This holds a count of the number of characters read
    // the last time the interval timer dpc fired.  It
    // is a long (rather than a ulong) since the other read
    // completion routines use negative values to indicate
    // to the interval timer that it should complete the read
    // if the interval timer DPC was lurking in some DPC queue when
    // some other way to complete occurs.
    //
    LONG CountOnLastRead;

    //
    // This is a count of the number of characters read by the
    // isr routine.  It is *ONLY* written at isr level.  We can
    // read it at dispatch level.
    //
    ULONG ReadByIsr;

    //
    // This holds the current baud rate for the device.
    //
    ULONG CurrentBaud;

    //
    // This is the number of characters read since the XoffCounter
    // was started.  This variable is only accessed at device level.
    // If it is greater than zero, it implies that there is an
    // XoffCounter ioctl in the queue.
    //
    LONG CountSinceXoff;

    //
    // This ulong is incremented each time something trys to start
    // the execution path that tries to lower the RTS line when
    // doing transmit toggling.  If it "bumps" into another path
    // (indicated by a false return value from queueing a dpc
    // and a TRUE return value tring to start a timer) it will
    // decrement the count.  These increments and decrements
    // are all done at device level.  Note that in the case
    // of a bump while trying to start the timer, we have to
    // go up to device level to do the decrement.
    //
    ULONG CountOfTryingToLowerRTS;

    //
    // This ULONG is used to keep track of the "named" (in ntddser.h)
    // baud rates that this particular device supports.
    //
    ULONG SupportedBauds;

    //
    // Hold the clock rate input to the serial part.
    //
    ULONG ClockRate;

    //
    // The number of characters to push out if a fifo is present.
    //
    ULONG TxFifoAmount;

    //
    // Holds the timeout controls for the device.  This value
    // is set by the Ioctl processing.
    //
    // It should only be accessed under protection of the control
    // lock since more than one request can be in the control dispatch
    // routine at one time.
    //
    SERIAL_TIMEOUTS Timeouts;

    //
    // This holds the various characters that are used
    // for replacement on errors and also for flow control.
    //
    // They are only set at interrupt level.
    //
    SERIAL_CHARS SpecialChars;

    //
    // This structure holds the handshake and control flow
    // settings for the serial driver.
    //
    // It is only set at interrupt level.  It can be
    // be read at any level with the control lock held.
    //
    SERIAL_HANDFLOW HandFlow;


    //
    // Holds performance statistics that applications can query.
    // Reset on each open.  Only set at device level.
    //
    SERIALPERF_STATS PerfStats;

    //
    // This holds what we beleive to be the current value of
    // the line control register.
    //
    // It should only be accessed under protection of the control
    // lock since more than one request can be in the control dispatch
    // routine at one time.
    //
    UCHAR LineControl;

    //
    // We keep track of whether the somebody has the device currently
    // opened with a simple boolean.  We need to know this so that
    // spurious interrupts from the device (especially during initialization)
    // will be ignored.  This value is only accessed in the ISR and
    // is only set via synchronization routines.  We may be able
    // to get rid of this boolean when the code is more fleshed out.
    //
    BOOLEAN DeviceIsOpened;

    //
    // This is only accessed at interrupt level.  It keeps track
    // of whether the holding register is empty.
    //
    BOOLEAN HoldingEmpty;

    //
    // This variable is only accessed at interrupt level.  It
    // indicates that we want to transmit a character immediately.
    // That is - in front of any characters that could be transmitting
    // from a normal write.
    //
    BOOLEAN TransmitImmediate;

    //
    // This variable is only accessed at interrupt level.  Whenever
    // a wait is initiated this variable is set to false.
    // Whenever any kind of character is written it is set to true.
    // Whenever the write queue is found to be empty the code that
    // is processing that completing irp will synchonize with the interrupt.
    // If this synchronization code finds that the variable is true and that
    // there is a wait on the transmit queue being empty then it is
    // certain that the queue was emptied and that it has happened since
    // the wait was initiated.
    //
    BOOLEAN EmptiedTransmit;

    //
    // We hold the character that should be transmitted immediately.
    //
    // Note that we can't use this to determine whether there is
    // a character to send because the character to send could be
    // zero.
    //
    UCHAR ImmediateChar;

    //
    // This holds the mask that will be used to mask off unwanted
    // data bits of the received data (valid data bits can be 5,6,7,8)
    // The mask will normally be 0xff.  This is set while the control
    // lock is held since it wouldn't have adverse effects on the
    // isr if it is changed in the middle of reading characters.
    // (What it would do to the app is another question - but then
    // the app asked the driver to do it.)
    //
    UCHAR ValidDataMask;

    //
    // The application can turn on a mode,via the
    // IOCTL_SERIAL_LSRMST_INSERT ioctl, that will cause the
    // serial driver to insert the line status or the modem
    // status into the RX stream.  The parameter with the ioctl
    // is a pointer to a UCHAR.  If the value of the UCHAR is
    // zero, then no insertion will ever take place.  If the
    // value of the UCHAR is non-zero (and not equal to the
    // xon/xoff characters), then the serial driver will insert.
    //
    UCHAR EscapeChar;

    //
    // These two booleans are used to indicate to the isr transmit
    // code that it should send the xon or xoff character.  They are
    // only accessed at open and at interrupt level.
    //
    BOOLEAN SendXonChar;
    BOOLEAN SendXoffChar;

    //
    // This boolean will be true if a 16550 is present *and* enabled.
    //
    BOOLEAN FifoPresent;

    //
    // This denotes that this particular port is an on the motherboard
    // port for the Jensen hardware.  On these ports the OUT2 bit
    // which is used to enable/disable interrupts is always hight.
    //
    BOOLEAN Jensen;

    //
    // This is the water mark that the rxfifo should be
    // set to when the fifo is turned on.  This is not the actual
    // value, but the encoded value that goes into the register.
    //
    UCHAR RxFifoTrigger;

    //
    // Says whether this device can share interrupts with devices
    // other than serial devices.
    //
    BOOLEAN InterruptShareable;

    //
    // Records whether we actually created the symbolic link name
    // at driver load time.  If we didn't create it, we won't try
    // to destroy it when we unload.
    //
    BOOLEAN CreatedSymbolicLink;

    //
    // Records whether we actually created an entry in SERIALCOMM
    // at driver load time.  If we didn't create it, we won't try
    // to destroy it when the device is removed.
    //
    BOOLEAN CreatedSerialCommEntry;

    //
    // We place all of the kernel and Io subsystem "opaque" structures
    // at the end of the extension.  We don't care about their contents.
    //

    //
    // This lock will be used to protect various fields in
    // the extension that are set (& read) in the extension
    // by the io controls.
    //
    KSPIN_LOCK ControlLock;

    //
    // This lock will be used to protect the accept / reject state
    // transitions and flags of the driver  It must be acquired
    // before a cancel lock
    //

    KSPIN_LOCK FlagsLock;

	//
	// This lock will be used to protect the interrupt buffer so that
	// there will be no reading and writing at the same time.
	//
	KSPIN_LOCK IntBufferLock;

    //
    // This points to a DPC used to complete read requests.
    //
    KDPC CompleteWriteDpc;

    //
    // This points to a DPC used to complete read requests.
    //
    KDPC CompleteReadDpc;

    //
    // This dpc is fired off if the timer for the total timeout
    // for the read expires.  It will execute a dpc routine that
    // will cause the current read to complete.
    //
    //
    KDPC TotalReadTimeoutDpc;

    //
    // This dpc is fired off if the timer for the interval timeout
    // expires.  If no more characters have been read then the
    // dpc routine will cause the read to complete.  However, if
    // more characters have been read then the dpc routine will
    // resubmit the timer.
    //
    KDPC IntervalReadTimeoutDpc;

    //
    // This dpc is fired off if the timer for the total timeout
    // for the write expires.  It will execute a dpc routine that
    // will cause the current write to complete.
    //
    //
    KDPC TotalWriteTimeoutDpc;

    //
    // This dpc is fired off if a comm error occurs.  It will
    // execute a dpc routine that will cancel all pending reads
    // and writes.
    //
    KDPC CommErrorDpc;

    //
    // This dpc is fired off if an event occurs and there was
    // a irp waiting on that event.  A dpc routine will execute
    // that completes the irp.
    //
    KDPC CommWaitDpc;

    //
    // This dpc is fired off when the transmit immediate char
    // character is given to the hardware.  It will simply complete
    // the irp.
    //
    KDPC CompleteImmediateDpc;

    //
    // This dpc is fired off if the transmit immediate char
    // character times out.  The dpc routine will "grab" the
    // irp from the isr and time it out.
    //
    KDPC TotalImmediateTimeoutDpc;

    //
    // This dpc is fired off if the timer used to "timeout" counting
    // the number of characters received after the Xoff ioctl is started
    // expired.
    //
    KDPC XoffCountTimeoutDpc;

    //
    // This dpc is fired off if the xoff counter actually runs down
    // to zero.
    //
    KDPC XoffCountCompleteDpc;

    //
    // This dpc is fired off only from device level to start off
    // a timer that will queue a dpc to check if the RTS line
    // should be lowered when we are doing transmit toggling.
    //
    KDPC StartTimerLowerRTSDpc;

    //
    // This dpc is fired off when a timer expires (after one
    // character time), so that code can be invoked that will
    // check to see if we should lower the RTS line when
    // doing transmit toggling.
    //
    KDPC PerhapsLowerRTSDpc;

    //
    // This DPC is fired to set an event stating that all other
    // DPC's have been finish for this device extension so that
    // paged code may be unlocked.
    //

    KDPC IsrUnlockPagesDpc;

    //
    // This is the kernal timer structure used to handle
    // total read request timing.
    //
    KTIMER ReadRequestTotalTimer;

    //
    // This is the kernal timer structure used to handle
    // interval read request timing.
    //
    KTIMER ReadRequestIntervalTimer;

    //
    // This is the kernal timer structure used to handle
    // total time request timing.
    //
    KTIMER WriteRequestTotalTimer;

    //
    // This is the kernal timer structure used to handle
    // total time request timing.
    //
    KTIMER ImmediateTotalTimer;

    //
    // This timer is used to timeout the xoff counter
    // io.
    //
    KTIMER XoffCountTimer;

    //
    // This timer is used to invoke a dpc one character time
    // after the timer is set.  That dpc will be used to check
    // whether we should lower the RTS line if we are doing
    // transmit toggling.
    //
    KTIMER LowerRTSTimer;

    //
    // Device stack capabilites
    //

    DEVICE_POWER_STATE DeviceStateMap[PowerSystemMaximum];

    //
    // Event to signal transition to D0 completion
    //

    KEVENT PowerD0Event;

    //
    // List of stalled IRP's
    //

    LIST_ENTRY StalledIrpQueue;

    //
    // Mutex on open status
    //

    FAST_MUTEX OpenMutex;

    //
    // Mutex on close
    //

    FAST_MUTEX CloseMutex;

    //
    // TRUE if we own power policy
    //

    BOOLEAN OwnsPowerPolicy;

    //
    // SystemWake from devcaps
    //

    SYSTEM_POWER_STATE SystemWake;

    //
    // DeviceWake from devcaps
    //

    DEVICE_POWER_STATE DeviceWake;

    //
    // Our PDO
    //

    PDEVICE_OBJECT Pdo;

    //
    // Should we enable wakeup
    //

    BOOLEAN SendWaitWake;

    //
    // Pending wait wake IRP
    //

    PIRP PendingWakeIrp;

    //
    // WMI Information
    //

    WMILIB_CONTEXT WmiLibInfo;

    //
    // Name to use as WMI identifier
    //

    UNICODE_STRING WmiIdentifier;

    //
    // WMI Comm Data
    //

    SERIAL_WMI_COMM_DATA WmiCommData;

    //
    // WMI HW Data
    //

    SERIAL_WMI_HW_DATA WmiHwData;

    //
    // WMI Performance Data
    //

    SERIAL_WMI_PERF_DATA WmiPerfData;

    //
    // Pending DPC count
    //

    ULONG DpcCount;

    //
    // Pending DPC event
    //

    KEVENT PendingDpcEvent;

    //
    // Should we expose external interfaces?
    //

    ULONG SkipNaming;
    
	
	//
    // Count of pending IRP's
    //

    ULONG PendingIRPCnt;

    //
    // Accepting requests?
    //

    ULONG DevicePNPAccept;

    //
    // No IRP's pending event
    //

    KEVENT PendingIRPEvent;

    //
    // Misc Flags
    //

    ULONG Flags;

    //
    // Open count
    //

    LONG OpenCount;

    //
    // This value is set by the read code to hold the time value
    // used for read interval timing.  We keep it in the extension
    // so that the interval timer dpc routine determine if the
    // interval time has passed for the IO.
    //
    LARGE_INTEGER IntervalTime;

    //
    // These two values hold the "constant" time that we should use
    // to delay for the read interval time.
    //
    LARGE_INTEGER ShortIntervalAmount;
    LARGE_INTEGER LongIntervalAmount;

    //
    // This holds the value that we use to determine if we should use
    // the long interval delay or the short interval delay.
    //
    LARGE_INTEGER CutOverAmount;

    //
    // This holds the system time when we last time we had
    // checked that we had actually read characters.  Used
    // for interval timing.
    //
    LARGE_INTEGER LastReadTime;

    //
    // This points the the delta time that we should use to
    // delay for interval timing.
    //
    PLARGE_INTEGER IntervalTimeToUse;


	//////////////////////////////
	//		USB definitions		//
	//////////////////////////////

	// used to save  URB of short, non-staged read/write requests
	PURB VendorUrb;

    //
    // The base address for the set of device registers
    // of the serial port.
    //
    PUCHAR Controller; //dummy variable

	ULONG ChannelNumber; // UART Channel Number ( for composite devices )

} DEVICE_EXTENSION, *PDEVICE_EXTENSION;


#define SERIAL_PNPACCEPT_OK                 0x0L
#define SERIAL_PNPACCEPT_REMOVING           0x1L
#define SERIAL_PNPACCEPT_STOPPING           0x2L
#define SERIAL_PNPACCEPT_STOPPED            0x4L
#define SERIAL_PNPACCEPT_SURPRISE_REMOVING  0x8L

#define SERIAL_PNP_ADDED                    0x0L
#define SERIAL_PNP_STARTED                  0x1L
#define SERIAL_PNP_QSTOP                    0x2L
#define SERIAL_PNP_STOPPING                 0x3L
#define SERIAL_PNP_QREMOVE                  0x4L
#define SERIAL_PNP_REMOVING                 0x5L
#define SERIAL_PNP_RESTARTING               0x6L

#define SERIAL_FLAGS_CLEAR                  0x0L
#define SERIAL_FLAGS_STARTED                0x1L
#define SERIAL_FLAGS_STOPPED                0x2L
#define SERIAL_FLAGS_BROKENHW               0x4L


// function prototypes

NTSTATUS
UsbCom_ProcessPnPIrp(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP           Irp
    );

NTSTATUS
UsbCom_ProcessSysControlIrp(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP           Irp
    );

VOID
UsbCom_Unload(
    IN PDRIVER_OBJECT DriverObject
    );

NTSTATUS
UsbCom_StartDevice(
    IN  PDEVICE_OBJECT DeviceObject
    );

NTSTATUS
UsbCom_StopDevice(
    IN  PDEVICE_OBJECT DeviceObject
    );

NTSTATUS
UsbCom_RemoveDevice(
    IN  PDEVICE_OBJECT DeviceObject
    );

NTSTATUS
UsbCom_CallUSBD(
    IN PDEVICE_OBJECT DeviceObject,
    IN PURB Urb
    );

NTSTATUS
UsbCom_PnPAddDevice(
    IN PDRIVER_OBJECT DriverObject,
    IN PDEVICE_OBJECT PhysicalDeviceObject
    );

NTSTATUS
UsbCom_CreateDeviceObject(
    IN PDRIVER_OBJECT DriverObject,
    IN PDEVICE_OBJECT PhysicalDeviceObject,
    IN PDEVICE_OBJECT *DeviceObject
    );

NTSTATUS
UsbCom_ConfigureDevice(
    IN  PDEVICE_OBJECT DeviceObject
    );

NTSTATUS
UsbCom_IrpCompletionRoutine(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp,
    IN PVOID Context
    );

NTSTATUS
UsbCom_CapabilitiesRoutine(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp,
    IN PVOID Context
    );

NTSTATUS
UsbCom_PoRequestCompletion(
    IN PDEVICE_OBJECT       DeviceObject,
    IN UCHAR                MinorFunction,
    IN POWER_STATE          PowerState,
    IN PVOID                Context,
    IN PIO_STATUS_BLOCK     IoStatus
    );

NTSTATUS
UsbCom_PoSelfRequestCompletion(
    IN PDEVICE_OBJECT       DeviceObject,
    IN UCHAR                MinorFunction,
    IN POWER_STATE          PowerState,
    IN PVOID                Context,
    IN PIO_STATUS_BLOCK     IoStatus
    );

NTSTATUS
UsbCom_SelfRequestPowerIrp(
    IN PDEVICE_OBJECT DeviceObject,
    IN POWER_STATE PowerState
    );

BOOLEAN
UsbCom_SetDevicePowerState(
    IN PDEVICE_OBJECT DeviceObject,
    IN DEVICE_POWER_STATE DeviceState
    );

NTSTATUS
UsbCom_PowerIrp_Complete(
    IN PDEVICE_OBJECT NullDeviceObject,
    IN PIRP Irp,
    IN PVOID Context
    );

NTSTATUS
UsbCom_QueryCapabilities(
    IN PDEVICE_OBJECT PdoDeviceObject,
    IN PDEVICE_CAPABILITIES DeviceCapabilities
    );


NTSTATUS
UsbCom_Create(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );


NTSTATUS
UsbCom_AbortPipes(
    IN PDEVICE_OBJECT DeviceObject
    );


NTSTATUS
UsbCom_ProcessIOCTL(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );

NTSTATUS
UsbCom_SelectInterface(
    IN PDEVICE_OBJECT DeviceObject,
    IN PUSB_CONFIGURATION_DESCRIPTOR ConfigurationDescriptor
    );

NTSTATUS
UsbCom_Close(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );

NTSTATUS
UsbCom_ResetPipe(
    IN PDEVICE_OBJECT DeviceObject,
    IN PUSBD_PIPE_INFORMATION PipeInfo
    );


VOID
UsbCom_IncrementIoCount(
    IN PDEVICE_OBJECT DeviceObject
    );

LONG
UsbCom_DecrementIoCount(
    IN PDEVICE_OBJECT DeviceObject
    );   


NTSTATUS
UsbCom_ProcessPowerIrp(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP           Irp
    );    


NTSTATUS
UsbCom_StagedReadWrite(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp,
    IN BOOLEAN Read
    );

NTSTATUS
UsbCom_SelfSuspendOrActivate(
    IN PDEVICE_OBJECT DeviceObject,
	IN BOOLEAN fSuspend
    );

NTSTATUS 
UsbCom_SymbolicLink(
    IN PDEVICE_OBJECT DeviceObject, 
	IN OUT PUNICODE_STRING deviceLinkUnicodeString
    );


BOOLEAN
UsbCom_CancelPendingIo(
    IN PDEVICE_OBJECT DeviceObject
    );

BOOLEAN
UsbCom_CanAcceptIoRequests(
    IN PDEVICE_OBJECT DeviceObject
    );

NTSTATUS
SerialGetRegistryKeyValue (IN HANDLE Handle, IN PWCHAR KeyNameString,
                           IN ULONG KeyNameStringLength, IN PVOID Data,
                           IN OUT PULONG DataLength);

NTSTATUS
UsbCom_Cleanup(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );

NTSTATUS
UsbCom_SendVendor(
    IN  PDEVICE_OBJECT DeviceObject,
	IN	UCHAR Request,
	IN	USHORT Value
    );
/*
NTSTATUS
UsbCom_SendVendor(
	IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp,
	IN	UCHAR Request,
	IN	USHORT Value
	);
*/

NTSTATUS
StartInterruptUrb(
	PDEVICE_EXTENSION Extension
	);

NTSTATUS
OnInterrupt(
	PDEVICE_OBJECT junk,
	PIRP Irp,
	PDEVICE_EXTENSION Extension
	);

NTSTATUS
StartReadUrb(
	PDEVICE_EXTENSION Extension
	);

NTSTATUS
OnReadInterrupt(
	PDEVICE_OBJECT junk,
	PIRP Irp,
	PDEVICE_EXTENSION Extension
	);

NTSTATUS
StartWriteUrb(
	PDEVICE_EXTENSION Extension
	);

NTSTATUS
OnWriteInterrupt(
	PDEVICE_OBJECT junk,
	PIRP Irp,
	PDEVICE_EXTENSION Extension
	);

VOID
TransferData(
	IN PDEVICE_EXTENSION DeviceExtension,
	IN ULONG DataLength
	);

VOID
TransmitData(
	IN PDEVICE_EXTENSION DeviceExtension
	);

#endif // already included

//////////////////////////////////////////////
//	Procedure definitions from serial.sys	//
//////////////////////////////////////////////

typedef
NTSTATUS
(*PSERIAL_START_ROUTINE) (
    IN PDEVICE_EXTENSION
    );

typedef
VOID
(*PSERIAL_GET_NEXT_ROUTINE) (
    IN PIRP *CurrentOpIrp,
    IN PLIST_ENTRY QueueToProcess,
    OUT PIRP *NewIrp,
    IN BOOLEAN CompleteCurrent,
    PDEVICE_EXTENSION Extension
    );

NTSTATUS
SerialRead(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );

NTSTATUS
SerialStartRead(
    IN PDEVICE_EXTENSION Extension
    );

VOID
SerialCompleteRead(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemContext1,
    IN PVOID SystemContext2
    );

VOID
SerialReadTimeout(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemContext1,
    IN PVOID SystemContext2
    );
/*
NTSTATUS
DriverEntry(
           IN PDRIVER_OBJECT DriverObject,
           IN PUNICODE_STRING RegistryPath
           );
*/
VOID
SerialIntervalReadTimeout(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemContext1,
    IN PVOID SystemContext2
    );
/*
NTSTATUS
SerialFlush(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );
*/
NTSTATUS
SerialWrite(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );

NTSTATUS
SerialStartWrite(
    IN PDEVICE_EXTENSION Extension
    );

VOID
SerialGetNextWrite(
    IN PIRP *CurrentOpIrp,
    IN PLIST_ENTRY QueueToProcess,
    IN PIRP *NewIrp,
    IN BOOLEAN CompleteCurrent,
    IN PDEVICE_EXTENSION Extension
    );

VOID
SerialCompleteWrite(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemContext1,
    IN PVOID SystemContext2
    );

BOOLEAN
SerialProcessEmptyTransmit(
    IN PVOID Context
    );

VOID
SerialWriteTimeout(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemContext1,
    IN PVOID SystemContext2
    );


BOOLEAN
SerialSetDTR(
    IN PVOID Context
    );

BOOLEAN
SerialClrDTR(
    IN PVOID Context
    );

BOOLEAN
SerialSetRTS(
    IN PVOID Context
    );

BOOLEAN
SerialClrRTS(
    IN PVOID Context
    );

BOOLEAN
SerialSetChars(
    IN PVOID Context
    );

BOOLEAN
SerialSetBaud(
    IN PVOID Context
    );

BOOLEAN
SerialSetLineControl(
    IN PVOID Context
    );

BOOLEAN
SerialSetupNewHandFlow(
    IN PDEVICE_EXTENSION Extension,
    IN PSERIAL_HANDFLOW NewHandFlow
    );

BOOLEAN
SerialSetHandFlow(
    IN PVOID Context
    );

BOOLEAN
SerialTurnOnBreak(
    IN PVOID Context
    );

BOOLEAN
SerialTurnOffBreak(
    IN PVOID Context
    );

BOOLEAN
SerialPretendXoff(
    IN PVOID Context
    );

BOOLEAN
SerialPretendXon(
    IN PVOID Context
    );

VOID
SerialHandleReducedIntBuffer(
    IN PDEVICE_EXTENSION Extension
    );

VOID
SerialProdXonXoff(
    IN PDEVICE_EXTENSION Extension,
    IN BOOLEAN SendXon
    );


NTSTATUS
SerialStartMask(
    IN PDEVICE_EXTENSION Extension
    );

VOID
SerialCancelWait(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );

VOID
SerialCompleteWait(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemContext1,
    IN PVOID SystemContext2
    );

/*
VOID
SerialStartImmediate(
    IN PSERIAL_DEVICE_EXTENSION Extension
    );

VOID
SerialCompleteImmediate(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemContext1,
    IN PVOID SystemContext2
    );

VOID
SerialTimeoutImmediate(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemContext1,
    IN PVOID SystemContext2
    );
*/
VOID
SerialTimeoutXoff(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemContext1,
    IN PVOID SystemContext2
    );

VOID
SerialCompleteXoff(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemContext1,
    IN PVOID SystemContext2
    );

NTSTATUS
SerialStartPurge(
    IN PDEVICE_EXTENSION Extension
    );

BOOLEAN
SerialPurgeInterruptBuff(
    IN PVOID Context
    );


NTSTATUS
SerialQueryInformationFile(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );

NTSTATUS
SerialSetInformationFile(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );

VOID
SerialKillAllReadsOrWrites(
    IN PDEVICE_OBJECT DeviceObject,
    IN PLIST_ENTRY QueueToClean,
    IN PIRP *CurrentOpIrp
    );

VOID
SerialGetNextIrp(
    IN PIRP *CurrentOpIrp,
    IN PLIST_ENTRY QueueToProcess,
    OUT PIRP *NextIrp,
    IN BOOLEAN CompleteCurrent,
    IN PDEVICE_EXTENSION extension
    );

VOID
SerialGetNextIrpLocked(IN PIRP *CurrentOpIrp, IN PLIST_ENTRY QueueToProcess,
                       OUT PIRP *NextIrp, IN BOOLEAN CompleteCurrent,
                       IN PDEVICE_EXTENSION extension, IN KIRQL OldIrql);

VOID
SerialTryToCompleteCurrent(
    IN PDEVICE_EXTENSION Extension,
    IN PKSYNCHRONIZE_ROUTINE SynchRoutine OPTIONAL,
    IN KIRQL IrqlForRelease,
    IN NTSTATUS StatusToUse,
    IN PIRP *CurrentOpIrp,
    IN PLIST_ENTRY QueueToProcess,
    IN PKTIMER IntervalTimer,
    IN PKTIMER TotalTimer,
    IN PSERIAL_START_ROUTINE Starter,
    IN PSERIAL_GET_NEXT_ROUTINE GetNextIrp,
    IN LONG RefType
    );


NTSTATUS
SerialStartOrQueue(
    IN PDEVICE_EXTENSION Extension,
    IN PIRP Irp,
    IN PLIST_ENTRY QueueToExamine,
    IN PIRP *CurrentOpIrp,
    IN PSERIAL_START_ROUTINE Starter
    );

VOID
SerialCancelQueued(
    PDEVICE_OBJECT DeviceObject,
    PIRP Irp
    );

NTSTATUS
SerialCompleteIfError(
    PDEVICE_OBJECT DeviceObject,
    PIRP Irp
    );

ULONG
SerialHandleModemUpdate(
    IN PDEVICE_EXTENSION Extension,
    IN BOOLEAN DoingTX
    );
/*
BOOLEAN
SerialISR(
    IN PKINTERRUPT InterruptObject,
    IN PVOID Context
    );

NTSTATUS
SerialGetDivisorFromBaud(
    IN ULONG ClockRate,
    IN LONG DesiredBaud,
    OUT PSHORT AppropriateDivisor
    );

VOID
SerialUnload(
    IN PDRIVER_OBJECT DriverObject
    );

BOOLEAN
SerialReset(
    IN PVOID Context
    );
*/
BOOLEAN
SerialPerhapsLowerRTS(
    IN PVOID Context
    );

VOID
SerialStartTimerLowerRTS(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemContext1,
    IN PVOID SystemContext2
    );

VOID
SerialInvokePerhapsLowerRTS(
    IN PKDPC Dpc,
    IN PVOID DeferredContext,
    IN PVOID SystemContext1,
    IN PVOID SystemContext2
    );
/*
VOID
SerialCleanupDevice(
    IN PDEVICE_EXTENSION Extension
    );

UCHAR
SerialProcessLSR(
    IN PDEVICE_EXTENSION Extension
    );
*/
LARGE_INTEGER
SerialGetCharTime(
    IN PDEVICE_EXTENSION Extension
    );
/*
BOOLEAN
SerialSharerIsr(
    IN PKINTERRUPT InterruptObject,
    IN PVOID Context
    );

BOOLEAN
SerialMarkClose(
    IN PVOID Context
    );

BOOLEAN
SerialIndexedMultiportIsr(
    IN PKINTERRUPT InterruptObject,
    IN PVOID Context
    );

BOOLEAN
SerialBitMappedMultiportIsr(
    IN PKINTERRUPT InterruptObject,
    IN PVOID Context
    );
*/
VOID
SerialPutChar(
    IN PDEVICE_EXTENSION Extension,
    IN UCHAR CharToPut
    );

BOOLEAN
SerialGetStats(
    IN PVOID Context
    );

BOOLEAN
SerialClearStats(
    IN PVOID Context
    );
/*
NTSTATUS
SerialCloseComplete(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp,
    IN PVOID Context
    );

NTSTATUS
SerialPnpDispatch(IN PDEVICE_OBJECT PDevObj, IN PIRP PIrp);

NTSTATUS
SerialPowerDispatch(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );

NTSTATUS
SerialSetPowerD0(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );

NTSTATUS
SerialSetPowerD3(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );

NTSTATUS
SerialOpenClose(
   IN PDEVICE_OBJECT DeviceObject,
   IN PIRP Irp
   );

NTSTATUS
SerialGetConfigDefaults(
    IN PSERIAL_FIRMWARE_DATA DriverDefaultsPtr,
    IN PUNICODE_STRING RegistryPath
    );
*/
VOID
SerialGetProperties(
    IN PDEVICE_EXTENSION Extension,
    IN PSERIAL_COMMPROP Properties
    );
/*
NTSTATUS
SerialEnumerateLegacy(IN PDRIVER_OBJECT DriverObject,
                      IN PUNICODE_STRING RegistryPath,
                      IN PSERIAL_FIRMWARE_DATA DriverDefaultsPtr);

NTSTATUS
SerialMigrateLegacyRegistry(IN PDEVICE_OBJECT PPdo,
                            IN PSERIAL_USER_DATA PUserData,
                            IN BOOLEAN IsMulti);

NTSTATUS
SerialBuildResourceList(OUT PCM_RESOURCE_LIST PResourceList,
                        OUT PULONG PPartialCount,
                        IN PSERIAL_USER_DATA PUserData);

NTSTATUS
SerialTranslateResourceList(IN PDRIVER_OBJECT DriverObject,
                            IN PKEY_BASIC_INFORMATION UserSubKey,
                            OUT PCM_RESOURCE_LIST PTrResourceList,
                            IN PCM_RESOURCE_LIST PResourceList,
                            IN ULONG PartialCount,
                            IN PSERIAL_USER_DATA PUserData);

NTSTATUS
SerialBuildRequirementsList(OUT PIO_RESOURCE_REQUIREMENTS_LIST PRequiredList,
                            IN ULONG PartialCount,
                            IN PSERIAL_USER_DATA PUserData);

BOOLEAN
SerialIsUserDataValid(IN PDRIVER_OBJECT DriverObject,
                      IN PKEY_BASIC_INFORMATION UserSubKey,
                      IN PRTL_QUERY_REGISTRY_TABLE Parameters,
                      IN ULONG DefaultInterfaceType,
                      IN PSERIAL_USER_DATA PUserData);

NTSTATUS
SerialControllerCallBack(
                  IN PVOID Context,
                  IN PUNICODE_STRING PathName,
                  IN INTERFACE_TYPE BusType,
                  IN ULONG BusNumber,
                  IN PKEY_VALUE_FULL_INFORMATION *BusInformation,
                  IN CONFIGURATION_TYPE ControllerType,
                  IN ULONG ControllerNumber,
                  IN PKEY_VALUE_FULL_INFORMATION *ControllerInformation,
                  IN CONFIGURATION_TYPE PeripheralType,
                  IN ULONG PeripheralNumber,
                  IN PKEY_VALUE_FULL_INFORMATION *PeripheralInformation
                  );

VOID
SerialLogError(
    IN PDRIVER_OBJECT DriverObject,
    IN PDEVICE_OBJECT DeviceObject OPTIONAL,
    IN PHYSICAL_ADDRESS P1,
    IN PHYSICAL_ADDRESS P2,
    IN ULONG SequenceNumber,
    IN UCHAR MajorFunctionCode,
    IN UCHAR RetryCount,
    IN ULONG UniqueErrorValue,
    IN NTSTATUS FinalStatus,
    IN NTSTATUS SpecificIOStatus,
    IN ULONG LengthOfInsert1,
    IN PWCHAR Insert1,
    IN ULONG LengthOfInsert2,
    IN PWCHAR Insert2
    );

NTSTATUS
SerialAddDevice(IN PDRIVER_OBJECT DriverObject, IN PDEVICE_OBJECT PLowerDevObj);

NTSTATUS
SerialCreateDevObj(IN PDRIVER_OBJECT DriverObject,
                   OUT PDEVICE_OBJECT *NewDeviceObject);

NTSTATUS
SerialStartDevice(IN PDEVICE_OBJECT PDevObj, IN PIRP PIrp);

NTSTATUS
SerialGetRegistryKeyValue (IN HANDLE Handle, IN PWCHAR KeyNameString,
                           IN ULONG KeyNameStringLength, IN PVOID Data,
                           IN ULONG DataLength);

NTSTATUS
SerialPnpDispatch(IN PDEVICE_OBJECT PDevObj, IN PIRP PIrp);

NTSTATUS
SerialGetPortInfo(IN PDEVICE_OBJECT PDevObj, IN PCM_RESOURCE_LIST PResList,
                 IN PCM_RESOURCE_LIST PTrResList, OUT PCONFIG_DATA PConfig,
                 IN PSERIAL_USER_DATA PUserData);

NTSTATUS
SerialFinishStartDevice(IN PDEVICE_OBJECT PDevObj,
                        IN PCM_RESOURCE_LIST PResList,
                        IN PCM_RESOURCE_LIST PTrResList,
                        IN PSERIAL_USER_DATA PUserData);

NTSTATUS
SerialPutRegistryKeyValue (
                          IN HANDLE Handle,
                          IN PWCHAR KeyNameString,
                          IN ULONG KeyNameStringLength,
                          IN ULONG Dtype,
                          IN PVOID Data,
                          IN ULONG DataLength
                          );

NTSTATUS
SerialInitController(IN PDEVICE_OBJECT PDevObj, IN PCONFIG_DATA PConfigData);

NTSTATUS
SerialInitMultiPort(IN PDEVICE_EXTENSION PDevExt,
                    IN PCONFIG_DATA PConfigData, IN PDEVICE_OBJECT PDevObj);

NTSTATUS
SerialFindInitController(IN PDEVICE_OBJECT PDevObj, IN PCONFIG_DATA PConfig);


BOOLEAN
SerialCIsrSw(IN PKINTERRUPT InterruptObject, IN PVOID Context);

NTSTATUS
SerialDoExternalNaming(IN PDEVICE_EXTENSION PDevExt,
                       IN PDRIVER_OBJECT PDrvObj);

PVOID
SerialGetMappedAddress(
    IN INTERFACE_TYPE BusType,
    IN ULONG BusNumber,
    PHYSICAL_ADDRESS IoAddress,
    ULONG NumberOfBytes,
    ULONG AddressSpace,
    PBOOLEAN MappedAddress
    );

NTSTATUS
SerialItemCallBack(
    IN PVOID Context,
    IN PUNICODE_STRING PathName,
    IN INTERFACE_TYPE BusType,
    IN ULONG BusNumber,
    IN PKEY_VALUE_FULL_INFORMATION *BusInformation,
    IN CONFIGURATION_TYPE ControllerType,
    IN ULONG ControllerNumber,
    IN PKEY_VALUE_FULL_INFORMATION *ControllerInformation,
    IN CONFIGURATION_TYPE PeripheralType,
    IN ULONG PeripheralNumber,
    IN PKEY_VALUE_FULL_INFORMATION *PeripheralInformation
    );

BOOLEAN
SerialDoesPortExist(
    IN PDEVICE_EXTENSION Extension,
    PUNICODE_STRING InsertString,
    IN ULONG ForceFifo,
    IN ULONG LogFifo
    );

SERIAL_MEM_COMPARES
SerialMemCompare(
    IN PHYSICAL_ADDRESS A,
    IN ULONG SpanOfA,
    IN PHYSICAL_ADDRESS B,
    IN ULONG SpanOfB
    );

VOID
SerialUndoExternalNaming(
    IN PDEVICE_EXTENSION Extension
    );

*/
NTSTATUS
SerialIRPPrologue(IN PIRP PIrp, IN PDEVICE_EXTENSION PDevExt);

VOID
SerialIRPEpilogue(IN PDEVICE_EXTENSION PDevExt);

NTSTATUS
SerialIoCallDriver(PDEVICE_EXTENSION PDevExt, PDEVICE_OBJECT PDevObj,
                   PIRP PIrp);

NTSTATUS
SerialPoCallDriver(PDEVICE_EXTENSION PDevExt, PDEVICE_OBJECT PDevObj,
                   PIRP PIrp);
/*
NTSTATUS
SerialRemoveDevObj(IN PDEVICE_OBJECT PDevObj);

VOID
SerialReleaseResources(IN PDEVICE_EXTENSION PDevExt);

VOID
SerialKillPendingIrps(PDEVICE_OBJECT DeviceObject);

VOID
SerialDisableUART(IN PVOID Context);

VOID
SerialDrainUART(IN PDEVICE_EXTENSION PDevExt,
                IN PLARGE_INTEGER PDrainTime);

NTSTATUS
SerialSystemControlDispatch(IN PDEVICE_OBJECT PDevObj, IN PIRP PIrp);

NTSTATUS
SerialSetWmiDataItem(IN PDEVICE_OBJECT PDevObj, IN PIRP PIrp,
                     IN ULONG GuidIndex, IN ULONG InstanceIndex,
                     IN ULONG DataItemId,
                     IN ULONG BufferSize, IN PUCHAR PBuffer);

NTSTATUS
SerialSetWmiDataBlock(IN PDEVICE_OBJECT PDevObj, IN PIRP PIrp,
                      IN ULONG GuidIndex, IN ULONG InstanceIndex,
                      IN ULONG BufferSize,
                      IN PUCHAR PBuffer);

NTSTATUS
SerialQueryWmiDataBlock(IN PDEVICE_OBJECT PDevObj, IN PIRP PIrp,
                        IN ULONG GuidIndex,
                        IN ULONG InstanceIndex,
                        IN ULONG InstanceCount,
                        IN OUT PULONG InstanceLengthArray,
                        IN ULONG OutBufferSize,
                        OUT PUCHAR PBuffer);

NTSTATUS
SerialQueryWmiRegInfo(IN PDEVICE_OBJECT PDevObj, OUT PULONG PRegFlags,
                      OUT PUNICODE_STRING PInstanceName,
                      OUT PUNICODE_STRING *PRegistryPath,
                      OUT PUNICODE_STRING MofResourceName,
                      OUT PDEVICE_OBJECT *Pdo);

VOID
SerialRestoreDeviceState(IN PDEVICE_EXTENSION PDevExt);

VOID
SerialSaveDeviceState(IN PDEVICE_EXTENSION PDevExt);

NTSTATUS
SerialSyncCompletion(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp,
                     IN PKEVENT SerialSyncEvent);

NTSTATUS
SerialGotoPowerState(IN PDEVICE_OBJECT PDevObj,
                     IN PDEVICE_EXTENSION PDevExt,
                     IN DEVICE_POWER_STATE DevPowerState);
*/
NTSTATUS
SerialFilterIrps(IN PIRP PIrp, IN PDEVICE_EXTENSION PDevExt);

VOID
SerialKillAllStalled(IN PDEVICE_OBJECT PDevObj);

VOID
SerialUnstallIrps(IN PDEVICE_EXTENSION PDevExt);

NTSTATUS
SerialInternalIoControl(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);
/*
NTSTATUS
SerialSendWaitWake(PDEVICE_EXTENSION PDevExt);

NTSTATUS
SerialWakeCompletion(IN PDEVICE_OBJECT PDevObj, IN UCHAR MinorFunction,
                     IN POWER_STATE PowerState, IN PVOID Context,
                     IN PIO_STATUS_BLOCK IoStatus);

UINT32
SerialReportMaxBaudRate(ULONG Bauds);

BOOLEAN
SerialSetMCRContents(IN PVOID Context);

BOOLEAN
SerialGetMCRContents(IN PVOID Context);

BOOLEAN
SerialSetFCRContents(IN PVOID Context);

NTSTATUS
SerialTossWMIRequest(IN PDEVICE_OBJECT PDevObj, IN PIRP PIrp,
                     IN ULONG GuidIndex);
*/
VOID
SerialDpcEpilogue(IN PDEVICE_EXTENSION PDevExt, IN PKDPC PDpc);

BOOLEAN
SerialInsertQueueDpc(IN PRKDPC Dpc, IN PVOID Sarg1, IN PVOID Sarg2,
                     IN PDEVICE_EXTENSION PDevExt);

BOOLEAN
SerialSetTimer(IN PKTIMER Timer, IN LARGE_INTEGER DueTime,
               IN PKDPC Dpc OPTIONAL, IN PDEVICE_EXTENSION PDevExt);

BOOLEAN
SerialCancelTimer(IN PKTIMER Timer, IN PDEVICE_EXTENSION PDevExt);

VOID
SerialUnlockPages(IN PKDPC PDpc, IN PVOID PDeferredContext,
                  IN PVOID PSysContext1, IN PVOID PSysContext2);

VOID
SerialMarkHardwareBroken(IN PDEVICE_EXTENSION PDevExt);
/*
VOID
SerialDisableInterfacesResources(IN PDEVICE_OBJECT PDevObj,
                                 IN BOOLEAN DisableUART);
*/
VOID
SerialSetDeviceFlags(IN PDEVICE_EXTENSION PDevExt, OUT PULONG PFlags,
                     IN ULONG Value, IN BOOLEAN Set);


typedef struct _SERIAL_UPDATE_CHAR {
    PDEVICE_EXTENSION Extension;
    ULONG CharsCopied;
    BOOLEAN Completed;
    } SERIAL_UPDATE_CHAR,*PSERIAL_UPDATE_CHAR;

//
// The following simple structure is used to send a pointer
// the device extension and an ioctl specific pointer
// to data.
//
typedef struct _SERIAL_IOCTL_SYNC {
    PDEVICE_EXTENSION Extension;
    PVOID Data;
    } SERIAL_IOCTL_SYNC,*PSERIAL_IOCTL_SYNC;

#define SerialSetFlags(PDevExt, Value) \
   SerialSetDeviceFlags((PDevExt), &(PDevExt)->Flags, (Value), TRUE)
#define SerialClearFlags(PDevExt, Value) \
   SerialSetDeviceFlags((PDevExt), &(PDevExt)->Flags, (Value), FALSE)
#define SerialSetAccept(PDevExt, Value) \
   SerialSetDeviceFlags((PDevExt), &(PDevExt)->DevicePNPAccept, (Value), TRUE)
#define SerialClearAccept(PDevExt, Value) \
   SerialSetDeviceFlags((PDevExt), &(PDevExt)->DevicePNPAccept, (Value), FALSE)




//
// The following three macros are used to initialize, set
// and clear references in IRPs that are used by
// this driver.  The reference is stored in the fourth
// argument of the irp, which is never used by any operation
// accepted by this driver.
//

#define SERIAL_REF_ISR         (0x00000001)
#define SERIAL_REF_CANCEL      (0x00000002)
#define SERIAL_REF_TOTAL_TIMER (0x00000004)
#define SERIAL_REF_INT_TIMER   (0x00000008)
#define SERIAL_REF_XOFF_REF    (0x00000010)


#define SERIAL_INIT_REFERENCE(Irp) { \
    ASSERT(sizeof(ULONG_PTR) <= sizeof(PVOID)); \
    IoGetCurrentIrpStackLocation((Irp))->Parameters.Others.Argument4 = NULL; \
    }

#define SERIAL_SET_REFERENCE(Irp,RefType) \
   do { \
       LONG _refType = (RefType); \
       PULONG_PTR _arg4 = (PVOID)&IoGetCurrentIrpStackLocation((Irp))->Parameters.Others.Argument4; \
       ASSERT(!(*_arg4 & _refType)); \
       *_arg4 |= _refType; \
   } while (0)

#define SERIAL_CLEAR_REFERENCE(Irp,RefType) \
   do { \
       LONG _refType = (RefType); \
       PULONG_PTR _arg4 = (PVOID)&IoGetCurrentIrpStackLocation((Irp))->Parameters.Others.Argument4; \
       ASSERT(*_arg4 & _refType); \
       *_arg4 &= ~_refType; \
   } while (0)

#define SERIAL_REFERENCE_COUNT(Irp) \
    ((ULONG_PTR)((IoGetCurrentIrpStackLocation((Irp))->Parameters.Others.Argument4)))


#define USE_SS_DBG_VendorReq 1

#ifndef USE_SS_DBG_VendorReq

#error "these are not a proper VendorRequest defines"

//	Vendor Specific device request
#define VendorBaudRate	0x00
#define VendorStopBit	0x01
#define VendorDataBit	0x02
#define VendorParity	0x03
#define VendorSetDTR	0x0A
#define VendorSetRTS	0x0B
#define VendorFlowCtrl	0x10
#define VendorSetChar	0x11

#else

#define VendorBaudRate	0x03
#define VendorStopBit	0x04
#define VendorDataBit	0x05
#define VendorParity	0x06
#define VendorSetDTR	0x08
#define VendorSetRTS	0x09
#define VendorFlowCtrl	0x07
#define VendorSetChar	0x11

#define VendorBaudRateVal9600bps	0x68
#define VendorBaudRateVal38400bps	0x1a
#define VendorBaudRateVal115200bps	0x9


#endif // !USE_SS_DBG_VendorReq












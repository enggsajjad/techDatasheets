/*++

Module Name:

    Usbios.c 

Environment:

    kernel mode only

--*/



#define GLOBAL_VARS
#define CDB 0       // send Setup-Tokan 

#include "wdm.h"
#include "stdarg.h"
#include "stdio.h"
#include "usbdi.h"
#include "usbdlib.h"
#include "usbcom.h"


VOID
TransferData(
	IN PDEVICE_EXTENSION Extension,
	IN ULONG DataLength
	)
{
    UCHAR ReceivedChar;
//	ULONG ConstantLen = Extension->CharsInRxFifo;
	UCHAR k=0;


    do {
//            READ_RECEIVE_BUFFER(Extension->Controller);
		ReceivedChar = Extension->ReadData[k];
		k++;

        Extension->PerfStats.ReceivedCount++;
        Extension->WmiPerfData.ReceivedCount++;

        ReceivedChar &= Extension->ValidDataMask;
#if 0
        if (!ReceivedChar &&
            (Extension->HandFlow.FlowReplace &
             SERIAL_NULL_STRIPPING)) {

            //
            // If what we got is a null character
            // and we're doing null stripping, then
            // we simply act as if we didn't see it.
            //

            goto ReceiveDoLineStatus;

        }

        if ((Extension->HandFlow.FlowReplace &
             SERIAL_AUTO_TRANSMIT) &&
            ((ReceivedChar ==
              Extension->SpecialChars.XonChar) ||
             (ReceivedChar ==
              Extension->SpecialChars.XoffChar))) {

            //
            // No matter what happens this character
            // will never get seen by the app.
            //

            if (ReceivedChar ==
                Extension->SpecialChars.XoffChar) {

                Extension->TXHolding |= SERIAL_TX_XOFF;

                if ((Extension->HandFlow.FlowReplace &
                     SERIAL_RTS_MASK) ==
                     SERIAL_TRANSMIT_TOGGLE) {
/*
                    SerialInsertQueueDpc(
                        &Extension->StartTimerLowerRTSDpc,
                        NULL,
                        NULL,
                        Extension
                        )?Extension->CountOfTryingToLowerRTS++:0;
*/
                }


            } else {

                if (Extension->TXHolding & SERIAL_TX_XOFF) {

                    //
                    // We got the xon char **AND*** we
                    // were being held up on transmission
                    // by xoff.  Clear that we are holding
                    // due to xoff.  Transmission will
                    // automatically restart because of
                    // the code outside the main loop that
                    // catches problems chips like the
                    // SMC and the Winbond.
                    //

                    Extension->TXHolding &= ~SERIAL_TX_XOFF;

                }

            }

            goto ReceiveDoLineStatus;

        }
#endif
/*henry
        //
        // Check to see if we should note
        // the receive character or special
        // character event.
        //

        if (Extension->IsrWaitMask) {

            if (Extension->IsrWaitMask &
                SERIAL_EV_RXCHAR) {

                Extension->HistoryMask |= SERIAL_EV_RXCHAR;

            }

            if ((Extension->IsrWaitMask &
                 SERIAL_EV_RXFLAG) &&
                (Extension->SpecialChars.EventChar ==
                 ReceivedChar)) {

                Extension->HistoryMask |= SERIAL_EV_RXFLAG;

            }

            if (Extension->IrpMaskLocation &&
                Extension->HistoryMask) {

                *Extension->IrpMaskLocation =
                 Extension->HistoryMask;
                Extension->IrpMaskLocation = NULL;
                Extension->HistoryMask = 0;

                Extension->CurrentWaitIrp->
                    IoStatus.Information = sizeof(ULONG);
                SerialInsertQueueDpc(
                    &Extension->CommWaitDpc,
                    NULL,
                    NULL,
                    Extension
                    );

            }

        }
*/
        SerialPutChar(
            Extension,
            ReceivedChar
            );

        //
        // If we're doing line status and modem
        // status insertion then we need to insert
        // a zero following the character we just
        // placed into the buffer to mark that this
        // was reception of what we are using to
        // escape.
        //
#if 0
        if (Extension->EscapeChar &&
            (Extension->EscapeChar ==
             ReceivedChar)) {

            SerialPutChar(
                Extension,
                SERIAL_LSRMST_ESCAPE
                );

        }
#endif

// SS - ReceiveDoLineStatus:   // ;
		DataLength--;
/*
        if (!((tempLSR = SerialProcessLSR(Extension)) &
              SERIAL_LSR_DR)) {

            //
            // No more characters, get out of the
            // loop.
            //

            break;

        }

        if ((tempLSR & ~(SERIAL_LSR_THRE | SERIAL_LSR_TEMT |
                         SERIAL_LSR_DR)) &&
            Extension->EscapeChar) {

           //
           // An error was indicated and inserted into the
           // stream, get out of the loop.
           //

           break;
        }
*/
    } while (DataLength);

	// Moved here from above. henry
    if (Extension->IsrWaitMask) {

        if (Extension->IsrWaitMask &
            SERIAL_EV_RXCHAR) {

            Extension->HistoryMask |= SERIAL_EV_RXCHAR;

        }

        if ((Extension->IsrWaitMask &
             SERIAL_EV_RXFLAG) &&
            (Extension->SpecialChars.EventChar ==
             ReceivedChar)) {

            Extension->HistoryMask |= SERIAL_EV_RXFLAG;

        }

        if (Extension->IrpMaskLocation &&
            Extension->HistoryMask) {

            *Extension->IrpMaskLocation =
             Extension->HistoryMask;
            Extension->IrpMaskLocation = NULL;
            Extension->HistoryMask = 0;

            Extension->CurrentWaitIrp->
                IoStatus.Information = sizeof(ULONG);
            SerialInsertQueueDpc(
                &Extension->CommWaitDpc,
                NULL,
                NULL,
                Extension
                );

        }

    }

}


VOID
SerialPutChar(
    IN PDEVICE_EXTENSION Extension,
    IN UCHAR CharToPut
    )

/*++

Routine Description:

    This routine, which only runs at device level, takes care of
    placing a character into the typeahead (receive) buffer.

Arguments:

    Extension - The serial device extension.

Return Value:

    None.

--*/

{
    KIRQL oldIrql;

//	DbgPrint("Putting character into interrupt buffer\n");
//henry   SERIAL_LOCKED_PAGED_CODE();

    //
    // If we have dsr sensitivity enabled then
    // we need to check the modem status register
    // to see if it has changed.
    //
/*henry
    if (Extension->HandFlow.ControlHandShake &
        SERIAL_DSR_SENSITIVITY) {

        SerialHandleModemUpdate(
            Extension,
            FALSE
            );

        if (Extension->RXHolding & SERIAL_RX_DSR) {

            //
            // We simply act as if we haven't
            // seen the character if we have dsr
            // sensitivity and the dsr line is low.
            //

            return;

        }

    }
*/
    //
    // If the xoff counter is non-zero then decrement it.
    // If the counter then goes to zero, complete that irp.
    //

    if (Extension->CountSinceXoff) {

        Extension->CountSinceXoff--;

        if (!Extension->CountSinceXoff) {

            Extension->CurrentXoffIrp->IoStatus.Status = STATUS_SUCCESS;
            Extension->CurrentXoffIrp->IoStatus.Information = 0;
            SerialInsertQueueDpc(
                &Extension->XoffCountCompleteDpc,
                NULL,
                NULL,
                Extension
                );

        }

    }

    //
    // Check to see if we are copying into the
    // users buffer or into the interrupt buffer.
    //
    // If we are copying into the user buffer
    // then we know there is always room for one more.
    // (We know this because if there wasn't room
    // then that read would have completed and we
    // would be using the interrupt buffer.)
    //
    // If we are copying into the interrupt buffer
    // then we will need to check if we have enough
    // room.
    //

    if (Extension->ReadBufferBase !=
        Extension->InterruptReadBuffer) {

        //
        // Increment the following value so
        // that the interval timer (if one exists
        // for this read) can know that a character
        // has been read.
        //

        Extension->ReadByIsr++;

        //
        // We are in the user buffer.  Place the
        // character into the buffer.  See if the
        // read is complete.
        //

        *Extension->CurrentCharSlot = CharToPut;

        if (Extension->CurrentCharSlot ==
            Extension->LastCharSlot) {

            //
            // We've filled up the users buffer.
            // Switch back to the interrupt buffer
            // and send off a DPC to Complete the read.
            //
            // It is inherent that when we were using
            // a user buffer that the interrupt buffer
            // was empty.
            //

            Extension->ReadBufferBase =
                Extension->InterruptReadBuffer;
            Extension->CurrentCharSlot =
                Extension->InterruptReadBuffer;
            Extension->FirstReadableChar =
                Extension->InterruptReadBuffer;
            Extension->LastCharSlot =
                Extension->InterruptReadBuffer +
                (Extension->BufferSize - 1);
            Extension->CharsInInterruptBuffer = 0;

            Extension->CurrentReadIrp->IoStatus.Information =
                IoGetCurrentIrpStackLocation(
                    Extension->CurrentReadIrp
                    )->Parameters.Read.Length;

            SerialInsertQueueDpc(
                &Extension->CompleteReadDpc,
                NULL,
                NULL,
                Extension
                );

        } else {

            //
            // Not done with the users read.
            //

            Extension->CurrentCharSlot++;

        }

    } else {

//		DbgPrint("Using interrupt buffer\n");
        //
        // We need to see if we reached our flow
        // control threshold.  If we have then
        // we turn on whatever flow control the
        // owner has specified.  If no flow
        // control was specified, well..., we keep
        // trying to receive characters and hope that
        // we have enough room.  Note that no matter
        // what flow control protocol we are using, it
        // will not prevent us from reading whatever
        // characters are available.
        //
#if 0
        if ((Extension->HandFlow.ControlHandShake
             & SERIAL_DTR_MASK) ==
            SERIAL_DTR_HANDSHAKE) {

            //
            // If we are already doing a
            // dtr hold then we don't have
            // to do anything else.
            //

            if (!(Extension->RXHolding &
                  SERIAL_RX_DTR)) {

                if ((Extension->BufferSize -
                     Extension->HandFlow.XoffLimit)
                    <= (Extension->CharsInInterruptBuffer+1)) {

                    Extension->RXHolding |= SERIAL_RX_DTR;

                    SerialClrDTR(Extension);

                }

            }

        }

        if ((Extension->HandFlow.FlowReplace
             & SERIAL_RTS_MASK) ==
            SERIAL_RTS_HANDSHAKE) {

            //
            // If we are already doing a
            // rts hold then we don't have
            // to do anything else.
            //

            if (!(Extension->RXHolding &
                  SERIAL_RX_RTS)) {

                if ((Extension->BufferSize -
                     Extension->HandFlow.XoffLimit)
                    <= (Extension->CharsInInterruptBuffer+1)) {

                    Extension->RXHolding |= SERIAL_RX_RTS;

                    SerialClrRTS(Extension);

                }

            }

        }

        if (Extension->HandFlow.FlowReplace &
            SERIAL_AUTO_RECEIVE) {

            //
            // If we are already doing a
            // xoff hold then we don't have
            // to do anything else.
            //

            if (!(Extension->RXHolding &
                  SERIAL_RX_XOFF)) {

                if ((Extension->BufferSize -
                     Extension->HandFlow.XoffLimit)
                    <= (Extension->CharsInInterruptBuffer+1)) {

                    Extension->RXHolding |= SERIAL_RX_XOFF;

                    //
                    // If necessary cause an
                    // off to be sent.
                    //

                    SerialProdXonXoff(
                        Extension,
                        FALSE
                        );

                }

            }

        }
#endif
        if (Extension->CharsInInterruptBuffer <
            Extension->BufferSize) {

            *Extension->CurrentCharSlot = CharToPut;
            Extension->CharsInInterruptBuffer++;

            //
            // If we've become 80% full on this character
            // and this is an interesting event, note it.
            //

            if (Extension->CharsInInterruptBuffer ==
                Extension->BufferSizePt8) {

				// To remember not to submit the next read URB when back in
				// read interrupt routine.
				DbgPrint("80% full reached\n");
				Extension->ToSubmitReadUrb = FALSE;
				Extension->NoReadUrb = TRUE;


                if (Extension->IsrWaitMask &
                    SERIAL_EV_RX80FULL) {

                    Extension->HistoryMask |= SERIAL_EV_RX80FULL;

                    if (Extension->IrpMaskLocation) {

                        *Extension->IrpMaskLocation =
                         Extension->HistoryMask;
                        Extension->IrpMaskLocation = NULL;
                        Extension->HistoryMask = 0;

                        Extension->CurrentWaitIrp->
                            IoStatus.Information = sizeof(ULONG);
                        SerialInsertQueueDpc(
                            &Extension->CommWaitDpc,
                            NULL,
                            NULL,
                            Extension
                            );

                    }

                }

            }

            //
            // Point to the next available space
            // for a received character.  Make sure
            // that we wrap around to the beginning
            // of the buffer if this last character
            // received was placed at the last slot
            // in the buffer.
            //

            if (Extension->CurrentCharSlot ==
                Extension->LastCharSlot) {

                Extension->CurrentCharSlot =
                    Extension->InterruptReadBuffer;

            } else {

                Extension->CurrentCharSlot++;

            }

        } else {

            //
            // We have a new character but no room for it.
            //
			DbgPrint("Buffer Overflow\n"); 

            Extension->PerfStats.BufferOverrunErrorCount++;
            Extension->WmiPerfData.BufferOverrunErrorCount++;
            Extension->ErrorWord |= SERIAL_ERROR_QUEUEOVERRUN;

            if (Extension->HandFlow.FlowReplace &
                SERIAL_ERROR_CHAR) {

                //
                // Place the error character into the last
                // valid place for a character.  Be careful!,
                // that place might not be the previous location!
                //

                if (Extension->CurrentCharSlot ==
                    Extension->InterruptReadBuffer) {

                    *(Extension->InterruptReadBuffer+
                      (Extension->BufferSize-1)) =
                      Extension->SpecialChars.ErrorChar;

                } else {

                    *(Extension->CurrentCharSlot-1) =
                     Extension->SpecialChars.ErrorChar;

                }

            }

            //
            // If the application has requested it, abort all reads
            // and writes on an error.
            //

            if (Extension->HandFlow.ControlHandShake &
                SERIAL_ERROR_ABORT) {

                SerialInsertQueueDpc(
                    &Extension->CommErrorDpc,
                    NULL,
                    NULL,
                    Extension
                    );

            }

        }

    }

}


NTSTATUS
StartInterruptUrb(
	PDEVICE_EXTENSION Extension
	)
{							// StartInterruptUrb

	// If the interrupt polling IRP is currently running, don't try to start
	// it again.
    USBD_PIPE_HANDLE PipeHandle;
	BOOLEAN startirp;
	KIRQL oldirql;
	PIRP Irp;
	PURB urb;
	PIO_STACK_LOCATION stack;

//	KeAcquireSpinLock(&Extension->polllock, &oldirql);
	if (Extension->pollpending)
		startirp = FALSE;
	else
		startirp = TRUE, Extension->pollpending = TRUE;
//	KeReleaseSpinLock(&Extension->polllock, oldirql);

	if (!startirp)
		return STATUS_DEVICE_BUSY;	// already pending

	Irp = Extension->PollingIrp;
	urb = Extension->PollingUrb;
    PipeHandle = Extension->UsbInterface->Pipes[Extension->InterruptPipe].PipeHandle;

	ASSERT(Irp && urb);

	// Acquire the remove lock so we can't remove the device while the IRP
	// is still active.
/*henry
	NTSTATUS status = IoAcquireRemoveLock(&Extension->RemoveLock, Irp);
	if (!NT_SUCCESS(status))
		{
		Extension->pollpending = 0;
		return status;
		}
*/
	// Initialize the URB we use for reading the interrupt pipe

	UsbBuildInterruptOrBulkTransferRequest(
		urb,
		sizeof (struct _URB_BULK_OR_INTERRUPT_TRANSFER),
		PipeHandle,
		&Extension->intdata,
		NULL,
		4,
		USBD_TRANSFER_DIRECTION_IN | USBD_SHORT_TRANSFER_OK,
		NULL);

	// Install "OnInterrupt" as the completion routine for the polling IRP.
	
	IoSetCompletionRoutine(
		Irp,
		(PIO_COMPLETION_ROUTINE) OnInterrupt,
		Extension,
		TRUE,
		TRUE,
		TRUE);

	// Initialize the IRP for an internal control request

	stack = IoGetNextIrpStackLocation(Irp);
	stack->MajorFunction = IRP_MJ_INTERNAL_DEVICE_CONTROL;
	stack->Parameters.DeviceIoControl.IoControlCode = IOCTL_INTERNAL_USB_SUBMIT_URB;
	stack->Parameters.Others.Argument1 = urb;

	// This IRP might have been cancelled the last time it was used, in which case
	// the cancel flag will still be on. Clear it to prevent USBD from thinking that it's
	// been cancelled again! A better way to do this would be to call IoReuseIrp,
	// but that function is not declared in WDM.H.

	Irp->Cancel = FALSE;

//	UsbCom_IncrementIoCount(Extension->DeviceObject); //henry

	return IoCallDriver(Extension->TopOfStackDeviceObject, Irp);
}							// StartInterruptUrb


NTSTATUS
OnInterrupt(
	PDEVICE_OBJECT junk,
	PIRP Irp,
	PDEVICE_EXTENSION Extension
	)
{							// OnInterrupt

	KIRQL oldirql;
//	KeAcquireSpinLock(&Extension->polllock, &oldirql);
	Extension->pollpending = FALSE;		// allow another poll to be started
//	PVOID powercontext = Extension->powercontext;
//	Extension->powercontext = NULL;
//	KeReleaseSpinLock(&Extension->polllock, oldirql);

	// If the poll completed successfully, do whatever it is we do when we
	// get an interrupt (in this sample, that's answering an IOCTL) and
	// reissue the read. We're trying to have a read outstanding on the
	// interrupt pipe all the time except when power is off.

	if (NT_SUCCESS(Irp->IoStatus.Status)) {		// device signalled an interrupt
		DbgPrint(" - Interrupt!\n");

		DbgPrint("Byte 1 = 0x%x\n", Extension->intdata[0]);
		DbgPrint("Byte 2 = 0x%x\n", Extension->intdata[1]);
		DbgPrint("Byte 3 = 0x%x\n", Extension->intdata[2]);
		DbgPrint("Byte 4 = 0x%x\n", Extension->intdata[3]);

		if (Extension->DeviceIsOpened == TRUE && 	// Ensure that device is opened.
			(Extension->intdata[2] == 0x60)) {
		
			SerialHandleModemUpdate(
				Extension,
				FALSE
				);

		}

		DbgPrint("Submitting the next interrupt URB\n");

		// Unless we're in the middle of a power-off sequence, reissue the
		// polling IRP. Normally, SaveContext would have tried to cancel the
		// IRP, and we won't get to this statement because STATUS_CANCELLED
		// will fail the NT_SUCCESS test. We don't have any guarantee that the
		// IRP will actually complete with STATUS_CANCELLED, though. Hence this test.
		
//		if (!powercontext)
			StartInterruptUrb(Extension); // issue next polling request
	}						// device signalled an interrupt
#if DBG	
	else {
		DbgPrint(" - Interrupt polling IRP %X failed - %X (USBD status %X)\n",
			Irp, Irp->IoStatus.Status, URB_STATUS(Extension->PollingUrb));
	}
#endif

//	UsbCom_DecrementIoCount(Extension->DeviceObject); //henry

	// If we cancelled the poll during a power-down sequence, notify our
	// power management code that it can continue.
/*
	if (powercontext)
		GenericSaveRestoreComplete(powercontext);

	IoReleaseRemoveLock(&Extension->RemoveLock, Irp); // balances acquisition in StartInterruptUrb
*/
	return STATUS_MORE_PROCESSING_REQUIRED;
}							// OnInterrupt


NTSTATUS
StartReadUrb(
	PDEVICE_EXTENSION Extension
	)
{							// StartInterruptUrb

	// If the interrupt polling IRP is currently running, don't try to start
	// it again.
    USBD_PIPE_HANDLE PipeHandle;
	BOOLEAN startirp;
	KIRQL oldirql;
	PIRP Irp;
	PURB urb;
	PIO_STACK_LOCATION stack;

//	KeAcquireSpinLock(&Extension->polllock, &oldirql);
	if (Extension->readpending)
		startirp = FALSE;
	else
		startirp = TRUE, Extension->readpending = TRUE;
//	KeReleaseSpinLock(&Extension->polllock, oldirql);

	if (!startirp)
		return STATUS_DEVICE_BUSY;	// already pending

	Irp = Extension->ReadingIrp;
	urb = Extension->ReadingUrb;
    PipeHandle = Extension->UsbInterface->Pipes[Extension->DataInPipe].PipeHandle;

	ASSERT(Irp && urb);

	// Acquire the remove lock so we can't remove the device while the IRP
	// is still active.
/*henry
	NTSTATUS status = IoAcquireRemoveLock(&Extension->RemoveLock, Irp);
	if (!NT_SUCCESS(status))
		{
		Extension->pollpending = 0;
		return status;
		}
*/
	// Initialize the URB we use for reading the interrupt pipe

	UsbBuildInterruptOrBulkTransferRequest(
		urb,
		sizeof (struct _URB_BULK_OR_INTERRUPT_TRANSFER),
		PipeHandle,
		&Extension->ReadData,
		NULL,
		64,
		USBD_TRANSFER_DIRECTION_IN | USBD_SHORT_TRANSFER_OK,
		NULL);

	// Install "OnInterrupt" as the completion routine for the polling IRP.
	
	IoSetCompletionRoutine(
		Irp,
		(PIO_COMPLETION_ROUTINE) OnReadInterrupt,
		Extension,
		TRUE,
		TRUE,
		TRUE);

	// Initialize the IRP for an internal control request

	stack = IoGetNextIrpStackLocation(Irp);
	stack->MajorFunction = IRP_MJ_INTERNAL_DEVICE_CONTROL;
	stack->Parameters.DeviceIoControl.IoControlCode = IOCTL_INTERNAL_USB_SUBMIT_URB;
	stack->Parameters.Others.Argument1 = urb;

	// This IRP might have been cancelled the last time it was used, in which case
	// the cancel flag will still be on. Clear it to prevent USBD from thinking that it's
	// been cancelled again! A better way to do this would be to call IoReuseIrp,
	// but that function is not declared in WDM.H.

	Irp->Cancel = FALSE;

//	UsbCom_IncrementIoCount(Extension->DeviceObject); //henry

	return IoCallDriver(Extension->TopOfStackDeviceObject, Irp);
}							// StartInterruptUrb


NTSTATUS
OnReadInterrupt(
	PDEVICE_OBJECT junk,
	PIRP Irp,
	PDEVICE_EXTENSION Extension
	)
{							// OnInterrupt
    PURB Urb;
	KIRQL oldirql;
//	KeAcquireSpinLock(&Extension->polllock, &oldirql);
	Extension->readpending = FALSE;		// allow another read to be started
//	PVOID powercontext = Extension->powercontext;
//	Extension->powercontext = NULL;
//	KeReleaseSpinLock(&Extension->polllock, oldirql);

	// If the poll completed successfully, do whatever it is we do when we
	// get an interrupt (in this sample, that's answering an IOCTL) and
	// reissue the read. We're trying to have a read outstanding on the
	// interrupt pipe all the time except when power is off.

    Urb = Extension->ReadingUrb;

    DbgPrint("ReadInterrupt_Routine: DO=%08x Irp=%08x TransferLength=%d, Urb Status=%x, Irp Status = %x\n",
        Extension->DeviceObject,
        Irp,
        Urb->UrbBulkOrInterruptTransfer.TransferBufferLength,
        Urb->UrbHeader.Status, 
        Irp->IoStatus.Status);

	if (NT_SUCCESS(Irp->IoStatus.Status)) {		// device signalled an interrupt

		if (Urb->UrbBulkOrInterruptTransfer.TransferBufferLength &&
			(Extension->DeviceIsOpened == TRUE)) {	// Ensure that device is opened.

            KeAcquireSpinLock(
                &Extension->IntBufferLock,
                &oldirql
                );

			TransferData(Extension, Urb->UrbBulkOrInterruptTransfer.TransferBufferLength);

			KeReleaseSpinLock(
                &Extension->IntBufferLock,
                oldirql
                );

		}

		// Unless we're in the middle of a power-off sequence, reissue the
		// polling IRP. Normally, SaveContext would have tried to cancel the
		// IRP, and we won't get to this statement because STATUS_CANCELLED
		// will fail the NT_SUCCESS test. We don't have any guarantee that the
		// IRP will actually complete with STATUS_CANCELLED, though. Hence this test.
		
//		if (!powercontext)
		if (Extension->ToSubmitReadUrb) {
			//DbgPrint("Submitting the next read URB\n");
			StartReadUrb(Extension); // issue next polling request
		}
	}						// device signalled an interrupt
#if DBG	
	else {
		DbgPrint(" - Read polling IRP %X failed - %X (USBD status %X)\n",
			Irp, Irp->IoStatus.Status, URB_STATUS(Extension->ReadingUrb));
	}
#endif

//	UsbCom_DecrementIoCount(Extension->DeviceObject); //henry

	// If we cancelled the poll during a power-down sequence, notify our
	// power management code that it can continue.
/*
	if (powercontext)
		GenericSaveRestoreComplete(powercontext);

	IoReleaseRemoveLock(&Extension->RemoveLock, Irp); // balances acquisition in StartInterruptUrb
*/
	return STATUS_MORE_PROCESSING_REQUIRED;
}							// OnInterrupt


NTSTATUS
StartWriteUrb(
	PDEVICE_EXTENSION Extension
	)
{							// StartInterruptUrb

	// If the interrupt polling IRP is currently running, don't try to start
	// it again.
    USBD_PIPE_HANDLE PipeHandle;
	BOOLEAN startirp;
	KIRQL oldirql;
	PIRP Irp;
	PURB urb;
	PIO_STACK_LOCATION stack;

//	DbgPrint("Enter StartWriteUrb()\n");

//	KeAcquireSpinLock(&Extension->polllock, &oldirql);
	if (Extension->writepending)
		startirp = FALSE;
	else
		startirp = TRUE, Extension->writepending = TRUE;
//	KeReleaseSpinLock(&Extension->polllock, oldirql);

	if (!startirp)
		return STATUS_DEVICE_BUSY;	// already pending

	Irp = Extension->WritingIrp;
	urb = Extension->WritingUrb;
    PipeHandle = Extension->UsbInterface->Pipes[Extension->DataOutPipe].PipeHandle;

	ASSERT(Irp && urb);

	// Acquire the remove lock so we can't remove the device while the IRP
	// is still active.
/*henry
	NTSTATUS status = IoAcquireRemoveLock(&Extension->RemoveLock, Irp);
	if (!NT_SUCCESS(status))
		{
		Extension->pollpending = 0;
		return status;
		}
*/
	// Initialize the URB we use for reading the interrupt pipe

	UsbBuildInterruptOrBulkTransferRequest(
		urb,
		sizeof (struct _URB_BULK_OR_INTERRUPT_TRANSFER),
		PipeHandle,
		Extension->WriteCurrentChar,
		NULL,
		Extension->WriteSize,
		USBD_TRANSFER_DIRECTION_OUT,
		NULL);

	// Install "OnInterrupt" as the completion routine for the polling IRP.
	
	IoSetCompletionRoutine(
		Irp,
		(PIO_COMPLETION_ROUTINE) OnWriteInterrupt,
		Extension,
		TRUE,
		TRUE,
		TRUE);

	// Initialize the IRP for an internal control request

	stack = IoGetNextIrpStackLocation(Irp);
	stack->MajorFunction = IRP_MJ_INTERNAL_DEVICE_CONTROL;
	stack->Parameters.DeviceIoControl.IoControlCode = IOCTL_INTERNAL_USB_SUBMIT_URB;
	stack->Parameters.Others.Argument1 = urb;

	// This IRP might have been cancelled the last time it was used, in which case
	// the cancel flag will still be on. Clear it to prevent USBD from thinking that it's
	// been cancelled again! A better way to do this would be to call IoReuseIrp,
	// but that function is not declared in WDM.H.

	Irp->Cancel = FALSE;

//	UsbCom_IncrementIoCount(Extension->DeviceObject); //henry
//	DbgPrint("Exit StartWriteUrb()\n");

	return IoCallDriver(Extension->TopOfStackDeviceObject, Irp);
}							// StartInterruptUrb


NTSTATUS
OnWriteInterrupt(
	PDEVICE_OBJECT junk,
	PIRP Irp,
	PDEVICE_EXTENSION Extension
	)
{							// OnInterrupt
    PURB Urb;
	KIRQL oldirql;
//	KeAcquireSpinLock(&Extension->polllock, &oldirql);
	Extension->writepending = FALSE;		// allow another write to be started
//	PVOID powercontext = Extension->powercontext;
//	Extension->powercontext = NULL;
//	KeReleaseSpinLock(&Extension->polllock, oldirql);

	// If the poll completed successfully, do whatever it is we do when we
	// get an interrupt (in this sample, that's answering an IOCTL) and
	// reissue the read. We're trying to have a read outstanding on the
	// interrupt pipe all the time except when power is off.

    Urb = Extension->WritingUrb;

    DbgPrint("WriteInterrupt_Routine: DO=%08x Irp=%08x TransferLength=%d, Urb Status=%x, Irp Status = %x\n",
        Extension->DeviceObject,
        Irp,
        Urb->UrbBulkOrInterruptTransfer.TransferBufferLength,
        Urb->UrbHeader.Status, 
        Irp->IoStatus.Status);


	if (NT_SUCCESS(Irp->IoStatus.Status)) {		// device signalled an interrupt

//		if (Urb->UrbBulkOrInterruptTransfer.TransferBufferLength)
//			TransferData(Extension, Urb->UrbBulkOrInterruptTransfer.TransferBufferLength);
		TransmitData(Extension);
//		DbgPrint("Submitting the next read URB\n");
		// Unless we're in the middle of a power-off sequence, reissue the
		// polling IRP. Normally, SaveContext would have tried to cancel the
		// IRP, and we won't get to this statement because STATUS_CANCELLED
		// will fail the NT_SUCCESS test. We don't have any guarantee that the
		// IRP will actually complete with STATUS_CANCELLED, though. Hence this test.
		
//		if (!powercontext)
//			StartReadUrb(Extension); // issue next polling request
	}						// device signalled an interrupt
#if DBG	
	else {
		DbgPrint(" - Write polling IRP %X failed - %X (USBD status %X)\n",
			Irp, Irp->IoStatus.Status, URB_STATUS(Extension->WritingUrb));
	}
#endif

//	UsbCom_DecrementIoCount(Extension->DeviceObject); //henry

	// If we cancelled the poll during a power-down sequence, notify our
	// power management code that it can continue.
/*
	if (powercontext)
		GenericSaveRestoreComplete(powercontext);

	IoReleaseRemoveLock(&Extension->RemoveLock, Irp); // balances acquisition in StartInterruptUrb
*/
	return STATUS_MORE_PROCESSING_REQUIRED;
}							// OnInterrupt


VOID
TransmitData(
	IN PDEVICE_EXTENSION Extension
	)
{

    Extension->HoldingEmpty = TRUE;

    if (Extension->WriteLength ||
        Extension->TransmitImmediate ||
        Extension->SendXoffChar ||
        Extension->SendXonChar) {

        //
        // Even though all of the characters being
        // sent haven't all been sent, this variable
        // will be checked when the transmit queue is
        // empty.  If it is still true and there is a
        // wait on the transmit queue being empty then
        // we know we finished transmitting all characters
        // following the initiation of the wait since
        // the code that initiates the wait will set
        // this variable to false.
        //
        // One reason it could be false is that
        // the writes were cancelled before they
        // actually started, or that the writes
        // failed due to timeouts.  This variable
        // basically says a character was written
        // by the isr at some point following the
        // initiation of the wait.
        //

        Extension->EmptiedTransmit = TRUE;

        //
        // If we have output flow control based on
        // the modem status lines, then we have to do
        // all the modem work before we output each
        // character. (Otherwise we might miss a
        // status line change.)
        //

        if (Extension->HandFlow.ControlHandShake &
            SERIAL_OUT_HANDSHAKEMASK) {

            SerialHandleModemUpdate(
                Extension,
                TRUE
                );

        }

        //
        // We can only send the xon character if
        // the only reason we are holding is because
        // of the xoff.  (Hardware flow control or
        // sending break preclude putting a new character
        // on the wire.)
        //

        if (Extension->SendXonChar &&
            !(Extension->TXHolding & ~SERIAL_TX_XOFF)) {

            if ((Extension->HandFlow.FlowReplace &
                 SERIAL_RTS_MASK) ==
                 SERIAL_TRANSMIT_TOGGLE) {

                //
                // We have to raise if we're sending
                // this character.
                //

                SerialSetRTS(Extension);

                Extension->PerfStats.TransmittedCount++;
                Extension->WmiPerfData.TransmittedCount++;
/*                WRITE_TRANSMIT_HOLDING(
                    Extension->Controller,
                    Extension->SpecialChars.XonChar
                    );
*/

                SerialInsertQueueDpc(
                    &Extension->StartTimerLowerRTSDpc,
                    NULL,
                    NULL,
                    Extension
                    )?Extension->CountOfTryingToLowerRTS++:0;


            } else {

                Extension->PerfStats.TransmittedCount++;
                Extension->WmiPerfData.TransmittedCount++;
/*                WRITE_TRANSMIT_HOLDING(
                    Extension->Controller,
                    Extension->SpecialChars.XonChar
                    );
*/
            }


            Extension->SendXonChar = FALSE;
            Extension->HoldingEmpty = FALSE;

            //
            // If we send an xon, by definition we
            // can't be holding by Xoff.
            //

            Extension->TXHolding &= ~SERIAL_TX_XOFF;

            //
            // If we are sending an xon char then
            // by definition we can't be "holding"
            // up reception by Xoff.
            //

            Extension->RXHolding &= ~SERIAL_RX_XOFF;

        } else if (Extension->SendXoffChar &&
              !Extension->TXHolding) {

            if ((Extension->HandFlow.FlowReplace &
                 SERIAL_RTS_MASK) ==
                 SERIAL_TRANSMIT_TOGGLE) {

                //
                // We have to raise if we're sending
                // this character.
                //

                SerialSetRTS(Extension);

                Extension->PerfStats.TransmittedCount++;
                Extension->WmiPerfData.TransmittedCount++;
/*                WRITE_TRANSMIT_HOLDING(
                    Extension->Controller,
                    Extension->SpecialChars.XoffChar
                    );
*/

                SerialInsertQueueDpc(
                    &Extension->StartTimerLowerRTSDpc,
                    NULL,
                    NULL,
                    Extension
                    )?Extension->CountOfTryingToLowerRTS++:0;

            } else {

                Extension->PerfStats.TransmittedCount++;
                Extension->WmiPerfData.TransmittedCount++;
/*                WRITE_TRANSMIT_HOLDING(
                    Extension->Controller,
                    Extension->SpecialChars.XoffChar
                    );
*/
            }

            //
            // We can't be sending an Xoff character
            // if the transmission is already held
            // up because of Xoff.  Therefore, if we
            // are holding then we can't send the char.
            //

            //
            // If the application has set xoff continue
            // mode then we don't actually stop sending
            // characters if we send an xoff to the other
            // side.
            //

            if (!(Extension->HandFlow.FlowReplace &
                  SERIAL_XOFF_CONTINUE)) {

                Extension->TXHolding |= SERIAL_TX_XOFF;

                if ((Extension->HandFlow.FlowReplace &
                     SERIAL_RTS_MASK) ==
                     SERIAL_TRANSMIT_TOGGLE) {

                    SerialInsertQueueDpc(
                        &Extension->StartTimerLowerRTSDpc,
                        NULL,
                        NULL,
                        Extension
                        )?Extension->CountOfTryingToLowerRTS++:0;

                }

            }

            Extension->SendXoffChar = FALSE;
            Extension->HoldingEmpty = FALSE;

        //
        // Even if transmission is being held
        // up, we should still transmit an immediate
        // character if all that is holding us
        // up is xon/xoff (OS/2 rules).
        //

        } else if (Extension->TransmitImmediate &&
            (!Extension->TXHolding ||
             (Extension->TXHolding == SERIAL_TX_XOFF)
            )) {

            Extension->TransmitImmediate = FALSE;

            if ((Extension->HandFlow.FlowReplace &
                 SERIAL_RTS_MASK) ==
                 SERIAL_TRANSMIT_TOGGLE) {

                //
                // We have to raise if we're sending
                // this character.
                //

                SerialSetRTS(Extension);

                Extension->PerfStats.TransmittedCount++;
                Extension->WmiPerfData.TransmittedCount++;
/*                WRITE_TRANSMIT_HOLDING(
                    Extension->Controller,
                    Extension->ImmediateChar
                    );
*/

                SerialInsertQueueDpc(
                    &Extension->StartTimerLowerRTSDpc,
                    NULL,
                    NULL,
                    Extension
                    )?Extension->CountOfTryingToLowerRTS++:0;

            } else {

                Extension->PerfStats.TransmittedCount++;
                Extension->WmiPerfData.TransmittedCount++;

/*                WRITE_TRANSMIT_HOLDING(
                    Extension->Controller,
                    Extension->ImmediateChar
                    );
*/
            }

            Extension->HoldingEmpty = FALSE;

            SerialInsertQueueDpc(
                &Extension->CompleteImmediateDpc,
                NULL,
                NULL,
                Extension
                );

        } else if (!Extension->TXHolding) {

            ULONG amountToWrite;
/*
            if (Extension->FifoPresent) {

                amountToWrite = (Extension->TxFifoAmount <
                                 Extension->WriteLength)?
                                Extension->TxFifoAmount:
                                Extension->WriteLength;

            } else {

                amountToWrite = 1;

            }
*/
                amountToWrite = (OutPipeMaxSize <
                                 Extension->WriteLength)?
                                OutPipeMaxSize:
                                Extension->WriteLength;

			Extension->WriteSize = amountToWrite;	// Pass this information to StartWriteUrb.

            if ((Extension->HandFlow.FlowReplace &
                 SERIAL_RTS_MASK) ==
                 SERIAL_TRANSMIT_TOGGLE) {

                //
                // We have to raise if we're sending
                // this character.
                //

                SerialSetRTS(Extension);

                if (amountToWrite == 1) {

                    Extension->PerfStats.TransmittedCount++;
                    Extension->WmiPerfData.TransmittedCount++;
/*
                    WRITE_TRANSMIT_HOLDING(
                        Extension->Controller,
                        *(Extension->WriteCurrentChar)
                        );
*/
					StartWriteUrb(Extension);

                } else {

                    Extension->PerfStats.TransmittedCount +=
                        amountToWrite;
                    Extension->WmiPerfData.TransmittedCount +=
                       amountToWrite;
/*
                    WRITE_TRANSMIT_FIFO_HOLDING(
                        Extension->Controller,
                        Extension->WriteCurrentChar,
                        amountToWrite
                        );
*/
					StartWriteUrb(Extension);

                }

                SerialInsertQueueDpc(
                    &Extension->StartTimerLowerRTSDpc,
                    NULL,
                    NULL,
                    Extension
                    )?Extension->CountOfTryingToLowerRTS++:0;

            } else {

                if (amountToWrite == 1) {

                    Extension->PerfStats.TransmittedCount++;
                    Extension->WmiPerfData.TransmittedCount++;
/*
                    WRITE_TRANSMIT_HOLDING(
                        Extension->Controller,
                        *(Extension->WriteCurrentChar)
                        );
*/
					StartWriteUrb(Extension);

                } else {

                    Extension->PerfStats.TransmittedCount +=
                        amountToWrite;
                    Extension->WmiPerfData.TransmittedCount +=
                        amountToWrite;
/*
                    WRITE_TRANSMIT_FIFO_HOLDING(
                        Extension->Controller,
                        Extension->WriteCurrentChar,
                        amountToWrite
                        );
*/
					StartWriteUrb(Extension);

                }

            }

            Extension->HoldingEmpty = FALSE;
            Extension->WriteCurrentChar += amountToWrite;
            Extension->WriteLength -= amountToWrite;
/*
            if (!Extension->WriteLength) {

                PIO_STACK_LOCATION IrpSp;
                //
                // No More characters left.  This
                // write is complete.  Take care
                // when updating the information field,
                // we could have an xoff counter masquerading
                // as a write irp.
                //

                IrpSp = IoGetCurrentIrpStackLocation(
                            Extension->CurrentWriteIrp
                            );

                Extension->CurrentWriteIrp->
                    IoStatus.Information =
                    (IrpSp->MajorFunction == IRP_MJ_WRITE)?
                        (IrpSp->Parameters.Write.Length):
                        (1);

                SerialInsertQueueDpc(
                    &Extension->CompleteWriteDpc,
                    NULL,
                    NULL,
                    Extension
                    );

            }
*/
        }

    } else if (!Extension->WriteLength) {

        PIO_STACK_LOCATION IrpSp;
        //
        // No More characters left.  This
        // write is complete.  Take care
        // when updating the information field,
        // we could have an xoff counter masquerading
        // as a write irp.
        //

        IrpSp = IoGetCurrentIrpStackLocation(
                    Extension->CurrentWriteIrp
                    );

        Extension->CurrentWriteIrp->
            IoStatus.Information =
            (IrpSp->MajorFunction == IRP_MJ_WRITE)?
                (IrpSp->Parameters.Write.Length):
                (1);

        SerialInsertQueueDpc(
            &Extension->CompleteWriteDpc,
            NULL,
            NULL,
            Extension
            );

    }

}

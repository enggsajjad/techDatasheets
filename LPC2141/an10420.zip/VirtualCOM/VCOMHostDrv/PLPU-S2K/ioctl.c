/*++

Module Name:

   ioctlblk.c

Abstract:

    IOCTL handlers

Environment:

    kernel mode only

--*/


#include "wdm.h"
#include "stdarg.h"
#include "stdio.h"

#include "usbdi.h"
#include "usbdlib.h"
#include "BulkUsb.h"

#include "usbdlib.h"
#include "usbcom.h"
#include "precomp.h"


BOOLEAN
SerialGetModemUpdate(
    IN PVOID Context
    );

/*
NTSTATUS
UsbCom_SetBaud(
    IN PDEVICE_OBJECT DeviceObject,
	IN ULONG baudrate
    );
*/


NTSTATUS
UsbCom_SetBaud(
	IN PDEVICE_OBJECT DeviceObject,
	IN PIRP Irp,
	IN ULONG baudrate
	);

/*
NTSTATUS
UsbCom_SendVendor(
	IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp,
	IN	UCHAR Request,
	IN	USHORT Value
	);

NTSTATUS
UsbCom_VendorCommand_Complete(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp,
    IN PVOID Context
    );
*/

BOOLEAN
SerialGetCommStatus(
    IN PVOID Context
    );

BOOLEAN
SerialSetEscapeChar(
    IN PVOID Context
    );



BOOLEAN
SerialGetStats(
    IN PVOID Context
    )

/*++

Routine Description:

    In sync with the interrpt service routine (which sets the perf stats)
    return the perf stats to the caller.


Arguments:

    Context - Pointer to a the irp.

Return Value:

    This routine always returns FALSE.

--*/

{

    PIO_STACK_LOCATION irpSp = IoGetCurrentIrpStackLocation((PIRP)Context);
    PDEVICE_EXTENSION extension = irpSp->DeviceObject->DeviceExtension;
    PSERIALPERF_STATS sp = ((PIRP)Context)->AssociatedIrp.SystemBuffer;

//    SERIAL_LOCKED_PAGED_CODE();

    *sp = extension->PerfStats;
    return FALSE;

}

BOOLEAN
SerialClearStats(
    IN PVOID Context
    )

/*++

Routine Description:

    In sync with the interrpt service routine (which sets the perf stats)
    clear the perf stats.


Arguments:

    Context - Pointer to a the extension.

Return Value:

    This routine always returns FALSE.

--*/

{
//   SERIAL_LOCKED_PAGED_CODE();

    RtlZeroMemory(
        &((PDEVICE_EXTENSION)Context)->PerfStats,
        sizeof(SERIALPERF_STATS)
        );

    RtlZeroMemory(&((PDEVICE_EXTENSION)Context)->WmiPerfData,
                 sizeof(SERIAL_WMI_PERF_DATA));
    return FALSE;

}


BOOLEAN
SerialSetChars(
    IN PVOID Context
    )

/*++

Routine Description:

    This routine is used to set the special characters for the
    driver.

Arguments:

    Context - Pointer to a structure that contains a pointer to
              the device extension and a pointer to a special characters
              structure.

Return Value:

    This routine always returns FALSE.

--*/

{

    ((PSERIAL_IOCTL_SYNC)Context)->Extension->SpecialChars =
        *((PSERIAL_CHARS)(((PSERIAL_IOCTL_SYNC)Context)->Data));

//    SERIAL_LOCKED_PAGED_CODE();

    return FALSE;

}

BOOLEAN
SerialGetModemUpdate(
    IN PVOID Context
    )

/*++

Routine Description:

    This routine is simply used to call the interrupt level routine
    that handles modem status update.

Arguments:

    Context - Pointer to a structure that contains a pointer to
              the device extension and a pointer to a ulong.

Return Value:

    This routine always returns FALSE.

--*/

{

    PDEVICE_EXTENSION Extension = ((PSERIAL_IOCTL_SYNC)Context)->Extension;
    ULONG *Result = (ULONG *)(((PSERIAL_IOCTL_SYNC)Context)->Data);

//    SERIAL_LOCKED_PAGED_CODE();


    *Result = SerialHandleModemUpdate(
                  Extension,
                  FALSE
                  );

    return FALSE;

}


BOOLEAN
SerialGetCommStatus(
    IN PVOID Context
    )

/*++

Routine Description:

    This is used to get the current state of the serial driver.

Arguments:

    Context - Pointer to a structure that contains a pointer to
              the device extension and a pointer to a serial status
              record.

Return Value:

    This routine always returns FALSE.

--*/

{

    PDEVICE_EXTENSION Extension = ((PSERIAL_IOCTL_SYNC)Context)->Extension;
    PSERIAL_STATUS Stat = ((PSERIAL_IOCTL_SYNC)Context)->Data;

//    SERIAL_LOCKED_PAGED_CODE();


    Stat->Errors = Extension->ErrorWord;
    Extension->ErrorWord = 0;

    //
    // BUG BUG We need to do something about eof (binary mode).
    //
    Stat->EofReceived = FALSE;

    Stat->AmountInInQueue = Extension->CharsInInterruptBuffer;
	DbgPrint("CharsInInterruptBuffer = %d\n", Extension->CharsInInterruptBuffer);
    Stat->AmountInOutQueue = Extension->TotalCharsQueued;

    if (Extension->WriteLength) {

        //
        // By definition if we have a writelength the we have
        // a current write irp.
        //

        ASSERT(Extension->CurrentWriteIrp);
        ASSERT(Stat->AmountInOutQueue >= Extension->WriteLength);

        Stat->AmountInOutQueue -=
            IoGetCurrentIrpStackLocation(Extension->CurrentWriteIrp)
            ->Parameters.Write.Length - (Extension->WriteLength);

    }

    Stat->WaitForImmediate = Extension->TransmitImmediate;

    Stat->HoldReasons = 0;
    if (Extension->TXHolding) {

        if (Extension->TXHolding & SERIAL_TX_CTS) {

            Stat->HoldReasons |= SERIAL_TX_WAITING_FOR_CTS;

        }

        if (Extension->TXHolding & SERIAL_TX_DSR) {

            Stat->HoldReasons |= SERIAL_TX_WAITING_FOR_DSR;

        }

        if (Extension->TXHolding & SERIAL_TX_DCD) {

            Stat->HoldReasons |= SERIAL_TX_WAITING_FOR_DCD;

        }

        if (Extension->TXHolding & SERIAL_TX_XOFF) {

            Stat->HoldReasons |= SERIAL_TX_WAITING_FOR_XON;

        }

        if (Extension->TXHolding & SERIAL_TX_BREAK) {

            Stat->HoldReasons |= SERIAL_TX_WAITING_ON_BREAK;

        }

    }

    if (Extension->RXHolding & SERIAL_RX_DSR) {

        Stat->HoldReasons |= SERIAL_RX_WAITING_FOR_DSR;

    }

    if (Extension->RXHolding & SERIAL_RX_XOFF) {

        Stat->HoldReasons |= SERIAL_TX_WAITING_XOFF_SENT;

    }

    return FALSE;

}


BOOLEAN
SerialSetEscapeChar(
    IN PVOID Context
    )

/*++

Routine Description:

    This is used to set the character that will be used to escape
    line status and modem status information when the application
    has set up that line status and modem status should be passed
    back in the data stream.

Arguments:

    Context - Pointer to the irp that is specify the escape character.
              Implicitly - An escape character of 0 means no escaping
              will occur.

Return Value:

    This routine always returns FALSE.

--*/

{
   PDEVICE_EXTENSION extension =
      IoGetCurrentIrpStackLocation((PIRP)Context)
         ->DeviceObject->DeviceExtension;


    extension->EscapeChar =
        *(PUCHAR)((PIRP)Context)->AssociatedIrp.SystemBuffer;

   return FALSE;

}


NTSTATUS
UsbCom_ProcessIOCTL(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    )
/*++

Routine Description:

    Dispatch table handler for IRP_MJ_DEVICE_CONTROL; 
    Handle DeviceIoControl() calls  from User mode


Arguments:

    DeviceObject - pointer to the FDO for this instance of the 82930 device.


Return Value:

    NT status code

--*/
{
    PIO_STACK_LOCATION irpStack;
    PDEVICE_EXTENSION deviceExtension;
    ULONG ioControlCode;
    NTSTATUS ntStatus = STATUS_SUCCESS ;
	LARGE_INTEGER Timeout = {(ULONG) -10000, -1};

    //
    // A temporary to hold the old IRQL so that it can be
    // restored once we complete/validate this request.
    //
    KIRQL OldIrql;

    //
    // Get a pointer to the current location in the Irp. This is where
    //     the function codes and parameters are located.
    //

    deviceExtension = DeviceObject->DeviceExtension;

    irpStack = IoGetCurrentIrpStackLocation (Irp);
 
    ioControlCode = irpStack->Parameters.DeviceIoControl.IoControlCode;

    DbgPrint("enter UsbCom_ProcessIOCTL() DO=%08x Irp=%08x IRP_MJ_DEVICE_CONTROL, ControlCode %s, -- %x\n",
        DeviceObject, Irp, UsbCom_StringForIoCtrl( ioControlCode ), ioControlCode );
   
    //
    // We expect to be open so all our pages are locked down.  This is, after
    // all, an IO operation, so the device should be open first.
    //

    if (deviceExtension->DeviceIsOpened != TRUE) {
       Irp->IoStatus.Status = STATUS_INVALID_DEVICE_REQUEST;
       IoCompleteRequest(Irp, IO_NO_INCREMENT);
       return STATUS_INVALID_DEVICE_REQUEST;
    }

    UsbCom_IncrementIoCount(DeviceObject);


    // Can't accept a new io request if:
    //  1) device is removed, 
    //  2) has never been started, 
    //  3) is stopped,
    //  4) has a remove request pending,
    //  5) has a stop device pending
    if ( !UsbCom_CanAcceptIoRequests( DeviceObject ) ) {
        ntStatus = STATUS_DELETE_PENDING;
        Irp->IoStatus.Status = ntStatus;
        Irp->IoStatus.Information = 0;

        IoCompleteRequest( Irp, IO_NO_INCREMENT );

		DbgPrint("Removed: %d, Started: %d, Stop: %d\n", 
			deviceExtension->DeviceRemoved,
			deviceExtension->DeviceStarted,
			deviceExtension->StopDeviceRequested);

        UsbCom_DecrementIoCount(DeviceObject);                          
        return ntStatus;
    }


    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;
    ntStatus = STATUS_SUCCESS;



    //
    // Handle Ioctls from User mode
    //

    switch (ioControlCode) {

		case IOCTL_SERIAL_SET_BAUD_RATE: {

            ULONG BaudRate;

			DbgPrint("USBSerial IOCTL: beginning set baud rate.\n");

            if (irpStack->Parameters.DeviceIoControl.InputBufferLength <
                sizeof(SERIAL_BAUD_RATE)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            } else {

                BaudRate = ((PSERIAL_BAUD_RATE)(Irp->AssociatedIrp.SystemBuffer))->BaudRate;

            }

			ntStatus = UsbCom_SetBaud(DeviceObject, Irp, BaudRate);
			deviceExtension->CurrentBaud = BaudRate;
			deviceExtension->WmiCommData.BaudRate = BaudRate;
			
			break;
		}
		case IOCTL_SERIAL_GET_BAUD_RATE : {

            PSERIAL_BAUD_RATE Br = (PSERIAL_BAUD_RATE)Irp->AssociatedIrp.SystemBuffer;
            if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
                sizeof(SERIAL_BAUD_RATE)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            KeAcquireSpinLock(
                &deviceExtension->ControlLock,
                &OldIrql
                );

            Br->BaudRate = deviceExtension->CurrentBaud;

            KeReleaseSpinLock(
                &deviceExtension->ControlLock,
                OldIrql
                );

            Irp->IoStatus.Information = sizeof(SERIAL_BAUD_RATE);

            break;

        }
        case IOCTL_SERIAL_GET_MODEM_CONTROL:  {

		//	ULONG BaudRate;
		//	BaudRate = ((PSERIAL_BAUD_RATE)(Irp->AssociatedIrp.SystemBuffer))->BaudRate;
		//	DbgPrint("[ss] GET_USB:  %x\n",BaudRate);

			break;
		}
        case IOCTL_SERIAL_SET_MODEM_CONTROL: {

			ULONG dwSetVal;
            ULONG BaudRate;

			DbgPrint("USBSerial IOCTL: beginning set baud rate.\n");

            if (irpStack->Parameters.DeviceIoControl.InputBufferLength <
                sizeof(SERIAL_BAUD_RATE)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            } else {

				dwSetVal = *(PULONG)Irp->AssociatedIrp.SystemBuffer;

               // BaudRate = ((PSERIAL_BAUD_RATE)(Irp->AssociatedIrp.SystemBuffer))->BaudRate;

            }

			//dwSetVal = BaudRate;

			//DbgPrint("\n[ss] SET_USB:  %s\n",dwSetVal);
			DbgPrint("\n[ss] SET_USB_CMD:  %x\n",dwSetVal);
			{
				UCHAR  ucUserRequest = 0x08;
				USHORT usUserValue   = 0x0000;
				ULONG  ulTemp1 = 0, ulTemp2=0;

	
#if 1
				ulTemp1 =  (0xff0000 &  dwSetVal) >> 16;
				ulTemp2 =  (0xffff &  dwSetVal);


				DbgPrint("\n[ss] ulTemp1 = %x, ulTemp2 = %x \n",ulTemp1, ulTemp2);

				ucUserRequest = (UCHAR) ulTemp1;
				usUserValue  = (USHORT) ulTemp2;
#else
				ucUserRequest =  (UCHAR ) (0xff0000 &  dwSetVal) >> 16;
				usUserValue =    (USHORT) (0xffff &  dwSetVal);
#endif

				UsbCom_SendVendor(DeviceObject, ucUserRequest, usUserValue);

//				DbgPrint("\n[ss] SET_USB: returned UsbCom_SendVendor\n");

			}

			break;
		}
		case IOCTL_SERIAL_GET_DTRRTS: {

            ULONG ModemControl = 0;
            if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
                sizeof(ULONG)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            Irp->IoStatus.Information = sizeof(ULONG);
            Irp->IoStatus.Status = STATUS_SUCCESS;

            ModemControl &= SERIAL_DTR_STATE | SERIAL_RTS_STATE;

            *(PULONG)Irp->AssociatedIrp.SystemBuffer = ModemControl;

            break;

        }
		case IOCTL_SERIAL_GET_COMMSTATUS: {

            SERIAL_IOCTL_SYNC S;

            if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
                sizeof(SERIAL_STATUS)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            Irp->IoStatus.Information = sizeof(SERIAL_STATUS);

            S.Extension = deviceExtension;
            S.Data =  Irp->AssociatedIrp.SystemBuffer;

            //
            // Acquire the cancel spin lock so nothing much
            // changes while were getting the state.
            //

            IoAcquireCancelSpinLock(&OldIrql);
/*
            KeSynchronizeExecution(
                Extension->Interrupt,
                SerialGetCommStatus,
                &S
                );
*/
            SerialGetCommStatus(&S);

			IoReleaseCancelSpinLock(OldIrql);

            break;

		}
        case IOCTL_SERIAL_SET_FIFO_CONTROL: {
			break;
		}
        case IOCTL_SERIAL_SET_LINE_CONTROL: {
//			ntStatus = UsbCom_SendVendor(DeviceObject, VendorDataBit, 0x03);//8 bits
			
			USHORT Value;

            //
            // Points to the line control record in the Irp.
            //
            PSERIAL_LINE_CONTROL Lc =
                ((PSERIAL_LINE_CONTROL)(Irp->AssociatedIrp.SystemBuffer));

            UCHAR LData;
            UCHAR LStop;
            UCHAR LParity;
            UCHAR Mask = 0xff;

            if (irpStack->Parameters.DeviceIoControl.InputBufferLength <
                sizeof(SERIAL_LINE_CONTROL)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            //
            // Make sure we are at power D0
            //
/*
            if (deviceExtension->PowerState != PowerDeviceD0) {
               ntStatus = SerialGotoPowerState(deviceExtension->Pdo, deviceExtension,
                                             PowerDeviceD0);
               if (!NT_SUCCESS(ntStatus)) {
                  break;
               }
            }
*/
            switch (Lc->WordLength) {
                case 5: {

                    LData = SERIAL_5_DATA;
                    Mask = 0x1f;
					Value = 0x00;
                    break;

                }
                case 6: {

                    LData = SERIAL_6_DATA;
                    Mask = 0x3f;
					Value = 0x01;
                    break;

                }
                case 7: {

                    LData = SERIAL_7_DATA;
                    Mask = 0x7f;
					Value = 0x02;
                    break;

                }
                case 8: {

                    LData = SERIAL_8_DATA;
					Value = 0x03;
                    break;

                }
                default: {

                    ntStatus = STATUS_INVALID_PARAMETER;
                    goto DoneWithIoctl;

                }

            }

			UsbCom_SendVendor(DeviceObject, VendorDataBit, Value);
            deviceExtension->WmiCommData.BitsPerByte = Lc->WordLength;

            switch (Lc->Parity) {

                case NO_PARITY: {
                    deviceExtension->WmiCommData.Parity = SERIAL_WMI_PARITY_NONE;
                    LParity = SERIAL_NONE_PARITY;
					Value = 0x00;
                    break;

                }
                case EVEN_PARITY: {
                    deviceExtension->WmiCommData.Parity = SERIAL_WMI_PARITY_EVEN;
                    LParity = SERIAL_EVEN_PARITY;
					Value = 0x01;
                    break;

                }
                case ODD_PARITY: {
                    deviceExtension->WmiCommData.Parity = SERIAL_WMI_PARITY_ODD;
                    LParity = SERIAL_ODD_PARITY;
					Value = 0x02;
                    break;

                }
                case SPACE_PARITY: {
                    deviceExtension->WmiCommData.Parity = SERIAL_WMI_PARITY_SPACE;
                    LParity = SERIAL_SPACE_PARITY;
					Value = 0x04;
                    break;

                }
                case MARK_PARITY: {
                    deviceExtension->WmiCommData.Parity = SERIAL_WMI_PARITY_MARK;
                    LParity = SERIAL_MARK_PARITY;
					Value = 0x03;
                    break;

                }
                default: {

                    ntStatus = STATUS_INVALID_PARAMETER;
                    goto DoneWithIoctl;
                    break;
                }

            }

			UsbCom_SendVendor(DeviceObject, VendorParity, Value);

            switch (Lc->StopBits) {

                case STOP_BIT_1: {
                    deviceExtension->WmiCommData.StopBits = SERIAL_WMI_STOP_1;
                    LStop = SERIAL_1_STOP;
					Value = 0x00;
                    break;
                }
                case STOP_BITS_1_5: {

                    if (LData != SERIAL_5_DATA) {

                        ntStatus = STATUS_INVALID_PARAMETER;
                        goto DoneWithIoctl;
                    }
                    deviceExtension->WmiCommData.StopBits = SERIAL_WMI_STOP_1_5;
                    LStop = SERIAL_1_5_STOP;
					Value = 0x01;
                    break;

                }
                case STOP_BITS_2: {

                    if (LData == SERIAL_5_DATA) {

                        ntStatus = STATUS_INVALID_PARAMETER;
                        goto DoneWithIoctl;
                    }
                    deviceExtension->WmiCommData.StopBits = SERIAL_WMI_STOP_2;
                    LStop = SERIAL_2_STOP;
					Value = 0x01;
                    break;

                }
                default: {

                    ntStatus = STATUS_INVALID_PARAMETER;
                    goto DoneWithIoctl;
                }

            }

			UsbCom_SendVendor(DeviceObject, VendorStopBit, Value);

            KeAcquireSpinLock(
                &deviceExtension->ControlLock,
                &OldIrql
                );

            deviceExtension->LineControl =
                (UCHAR)((deviceExtension->LineControl & SERIAL_LCR_BREAK) |
                        (LData | LParity | LStop));
            deviceExtension->ValidDataMask = Mask;
/*
            KeSynchronizeExecution(
                deviceExtension->Interrupt,
                SerialSetLineControl,
                deviceExtension
                );
*/
            KeReleaseSpinLock(
                &deviceExtension->ControlLock,
                OldIrql
                );

            break;
        }
        case IOCTL_SERIAL_GET_LINE_CONTROL: {

            PSERIAL_LINE_CONTROL Lc = (PSERIAL_LINE_CONTROL)Irp->AssociatedIrp.SystemBuffer;

            if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
                sizeof(SERIAL_LINE_CONTROL)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            KeAcquireSpinLock(
                &deviceExtension->ControlLock,
                &OldIrql
                );

            if ((deviceExtension->LineControl & SERIAL_DATA_MASK) == SERIAL_5_DATA) {
                Lc->WordLength = 5;
            } else if ((deviceExtension->LineControl & SERIAL_DATA_MASK)
                        == SERIAL_6_DATA) {
                Lc->WordLength = 6;
            } else if ((deviceExtension->LineControl & SERIAL_DATA_MASK)
                        == SERIAL_7_DATA) {
                Lc->WordLength = 7;
            } else if ((deviceExtension->LineControl & SERIAL_DATA_MASK)
                        == SERIAL_8_DATA) {
                Lc->WordLength = 8;
            }

            if ((deviceExtension->LineControl & SERIAL_PARITY_MASK)
                    == SERIAL_NONE_PARITY) {
                Lc->Parity = NO_PARITY;
            } else if ((deviceExtension->LineControl & SERIAL_PARITY_MASK)
                    == SERIAL_ODD_PARITY) {
                Lc->Parity = ODD_PARITY;
            } else if ((deviceExtension->LineControl & SERIAL_PARITY_MASK)
                    == SERIAL_EVEN_PARITY) {
                Lc->Parity = EVEN_PARITY;
            } else if ((deviceExtension->LineControl & SERIAL_PARITY_MASK)
                    == SERIAL_MARK_PARITY) {
                Lc->Parity = MARK_PARITY;
            } else if ((deviceExtension->LineControl & SERIAL_PARITY_MASK)
                    == SERIAL_SPACE_PARITY) {
                Lc->Parity = SPACE_PARITY;
            }

            if (deviceExtension->LineControl & SERIAL_2_STOP) {
                if (Lc->WordLength == 5) {
                    Lc->StopBits = STOP_BITS_1_5;
                } else {
                    Lc->StopBits = STOP_BITS_2;
                }
            } else {
                Lc->StopBits = STOP_BIT_1;
            }

            Irp->IoStatus.Information = sizeof(SERIAL_LINE_CONTROL);

            KeReleaseSpinLock(
                &deviceExtension->ControlLock,
                OldIrql
                );

            break;
        }
        case IOCTL_SERIAL_SET_TIMEOUTS: {

            PSERIAL_TIMEOUTS NewTimeouts =
                ((PSERIAL_TIMEOUTS)(Irp->AssociatedIrp.SystemBuffer));


            if (irpStack->Parameters.DeviceIoControl.InputBufferLength <
                sizeof(SERIAL_TIMEOUTS)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            if ((NewTimeouts->ReadIntervalTimeout == MAXULONG) &&
                (NewTimeouts->ReadTotalTimeoutMultiplier == MAXULONG) &&
                (NewTimeouts->ReadTotalTimeoutConstant == MAXULONG)) {

                ntStatus = STATUS_INVALID_PARAMETER;
                break;

            }

            KeAcquireSpinLock(
                &deviceExtension->ControlLock,
                &OldIrql
                );

            deviceExtension->Timeouts.ReadIntervalTimeout =
                NewTimeouts->ReadIntervalTimeout;

            deviceExtension->Timeouts.ReadTotalTimeoutMultiplier =
                NewTimeouts->ReadTotalTimeoutMultiplier;

            deviceExtension->Timeouts.ReadTotalTimeoutConstant =
                NewTimeouts->ReadTotalTimeoutConstant;

            deviceExtension->Timeouts.WriteTotalTimeoutMultiplier =
                NewTimeouts->WriteTotalTimeoutMultiplier;

            deviceExtension->Timeouts.WriteTotalTimeoutConstant =
                NewTimeouts->WriteTotalTimeoutConstant;

            KeReleaseSpinLock(
                &deviceExtension->ControlLock,
                OldIrql
                );

            break;
        }
        case IOCTL_SERIAL_GET_TIMEOUTS: {

            if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
                sizeof(SERIAL_TIMEOUTS)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            KeAcquireSpinLock(
                &deviceExtension->ControlLock,
                &OldIrql
                );

            *((PSERIAL_TIMEOUTS)Irp->AssociatedIrp.SystemBuffer) = deviceExtension->Timeouts;
            Irp->IoStatus.Information = sizeof(SERIAL_TIMEOUTS);

            KeReleaseSpinLock(
                &deviceExtension->ControlLock,
                OldIrql
                );

            break;
        }
        case IOCTL_SERIAL_SET_CHARS: {

            SERIAL_IOCTL_SYNC S;
            PSERIAL_CHARS NewChars =
                ((PSERIAL_CHARS)(Irp->AssociatedIrp.SystemBuffer));


            if (irpStack->Parameters.DeviceIoControl.InputBufferLength <
                sizeof(SERIAL_CHARS)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            //
            // The only thing that can be wrong with the chars
            // is that the xon and xoff characters are the
            // same.
            //
#if 0
            if (NewChars->XonChar == NewChars->XoffChar) {

                ntStatus = STATUS_INVALID_PARAMETER;
                break;

            }
#endif

            //
            // We acquire the control lock so that only
            // one request can GET or SET the characters
            // at a time.  The sets could be synchronized
            // by the interrupt spinlock, but that wouldn't
            // prevent multiple gets at the same time.
            //

            S.Extension = deviceExtension;
            S.Data = NewChars;

            KeAcquireSpinLock(
                &deviceExtension->ControlLock,
                &OldIrql
                );

            //
            // Under the protection of the lock, make sure that
            // the xon and xoff characters aren't the same as
            // the escape character.
            //

            if (deviceExtension->EscapeChar) {

                if ((deviceExtension->EscapeChar == NewChars->XonChar) ||
                    (deviceExtension->EscapeChar == NewChars->XoffChar)) {

                    ntStatus = STATUS_INVALID_PARAMETER;
                    KeReleaseSpinLock(
                        &deviceExtension->ControlLock,
                        OldIrql
                        );
                    break;

                }

            }

            deviceExtension->WmiCommData.XonCharacter = NewChars->XonChar;
            deviceExtension->WmiCommData.XoffCharacter = NewChars->XoffChar;
/*
            KeSynchronizeExecution(
                Extension->Interrupt,
                SerialSetChars,
                &S
                );
*/
			SerialSetChars(&S);

            KeReleaseSpinLock(
                &deviceExtension->ControlLock,
                OldIrql
                );

            break;

        }
        case IOCTL_SERIAL_GET_CHARS: {

            if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
                sizeof(SERIAL_CHARS)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            KeAcquireSpinLock(
                &deviceExtension->ControlLock,
                &OldIrql
                );

            *((PSERIAL_CHARS)Irp->AssociatedIrp.SystemBuffer) = deviceExtension->SpecialChars;
            Irp->IoStatus.Information = sizeof(SERIAL_CHARS);

            KeReleaseSpinLock(
                &deviceExtension->ControlLock,
                OldIrql
                );

            break;
        }
        case IOCTL_SERIAL_SET_DTR:
        case IOCTL_SERIAL_CLR_DTR: {
           //
           // Make sure we are at power D0
           //
/*
           if (Extension->PowerState != PowerDeviceD0) {
              ntStatus = SerialGotoPowerState(Extension->Pdo, Extension,
                                            PowerDeviceD0);
              if (!NT_SUCCESS(ntStatus)) {
                     break;
              }
           }
*/
            //
            // We acquire the lock so that we can check whether
            // automatic dtr flow control is enabled.  If it is
            // then we return an error since the app is not allowed
            // to touch this if it is automatic.
            //
/*
            KeAcquireSpinLock(
                &deviceExtension->ControlLock,
                &OldIrql
                );
*/
            if ((deviceExtension->HandFlow.ControlHandShake & SERIAL_DTR_MASK)
                == SERIAL_DTR_HANDSHAKE) {

                ntStatus = STATUS_INVALID_PARAMETER;

            } else {
/*
                KeSynchronizeExecution(
                    Extension->Interrupt,
                    ((IrpSp->Parameters.DeviceIoControl.IoControlCode ==
                     IOCTL_SERIAL_SET_DTR)?
                     (SerialSetDTR):(SerialClrDTR)),
                    Extension
                    );
*/
				if (irpStack->Parameters.DeviceIoControl.IoControlCode ==
                     IOCTL_SERIAL_SET_DTR)
					SerialSetDTR(deviceExtension);
				else
					SerialClrDTR(deviceExtension);
            }
/*
            KeReleaseSpinLock(
                &deviceExtension->ControlLock,
                OldIrql
                );
*/
            break;
        }
        case IOCTL_SERIAL_RESET_DEVICE: {

            break;
        }
        case IOCTL_SERIAL_SET_RTS:
        case IOCTL_SERIAL_CLR_RTS: {
           //
           // Make sure we are at power D0
           //
/*
           if (Extension->PowerState != PowerDeviceD0) {
              ntStatus = SerialGotoPowerState(Extension->Pdo, Extension,
                                            PowerDeviceD0);
              if (!NT_SUCCESS(ntStatus)) {
                 break;
              }
           }
*/
            //
            // We acquire the lock so that we can check whether
            // automatic rts flow control or transmit toggleing
            // is enabled.  If it is then we return an error since
            // the app is not allowed to touch this if it is automatic
            // or toggling.
            //
/* This is remarked away because later calling IoBuildDeviceIoControlRequest must be
called at passive level.
            KeAcquireSpinLock(
                &deviceExtension->ControlLock,
                &OldIrql
                );
*/
            if (((deviceExtension->HandFlow.FlowReplace & SERIAL_RTS_MASK)
                 == SERIAL_RTS_HANDSHAKE) ||
                ((deviceExtension->HandFlow.FlowReplace & SERIAL_RTS_MASK)
                 == SERIAL_TRANSMIT_TOGGLE)) {

                ntStatus = STATUS_INVALID_PARAMETER;

            } else {
/*
                KeSynchronizeExecution(
                    Extension->Interrupt,
                    ((IrpSp->Parameters.DeviceIoControl.IoControlCode ==
                     IOCTL_SERIAL_SET_RTS)?
                     (SerialSetRTS):(SerialClrRTS)),
                    Extension
                    );
*/
				if (irpStack->Parameters.DeviceIoControl.IoControlCode ==
					IOCTL_SERIAL_SET_RTS)
					SerialSetRTS(deviceExtension);
				else
					SerialClrRTS(deviceExtension);
            }
/*
            KeReleaseSpinLock(
                &deviceExtension->ControlLock,
                OldIrql
                );
*/
            break;

        }			
        case IOCTL_SERIAL_SET_XOFF: {
/*
            KeSynchronizeExecution(
                Extension->Interrupt,
                SerialPretendXoff,
                Extension
                );
*/
            SerialPretendXoff(deviceExtension);

            break;

        }
        case IOCTL_SERIAL_SET_XON: {
/*
            KeSynchronizeExecution(
                Extension->Interrupt,
                SerialPretendXon,
                Extension
                );
*/
			SerialPretendXon(deviceExtension);

            break;

        }
        case IOCTL_SERIAL_SET_BREAK_ON: {
           //
           // Make sure we are at power D0
           //
/*
           if (Extension->PowerState != PowerDeviceD0) {
              ntStatus = SerialGotoPowerState(Extension->Pdo, Extension,
                                            PowerDeviceD0);
              if (!NT_SUCCESS(ntStatus)) {
                 break;
              }
           }

            KeSynchronizeExecution(
                Extension->Interrupt,
                SerialTurnOnBreak,
                Extension
                );
*/
			SerialTurnOnBreak(deviceExtension);

            break;
        }
        case IOCTL_SERIAL_SET_BREAK_OFF: {
           //
           // Make sure we are at power D0
           //
/*
           if (Extension->PowerState != PowerDeviceD0) {
              ntStatus = SerialGotoPowerState(Extension->Pdo, Extension,
                                            PowerDeviceD0);
              if (!NT_SUCCESS(ntStatus)) {
                 break;
              }
           }

            KeSynchronizeExecution(
                Extension->Interrupt,
                SerialTurnOffBreak,
                Extension
                );
*/
			SerialTurnOffBreak(deviceExtension);

            break;
        }
        case IOCTL_SERIAL_SET_QUEUE_SIZE: {

            //
            // Type ahead buffer is fixed, so we just validate
            // the the users request is not bigger that our
            // own internal buffer size.
            //

            PSERIAL_QUEUE_SIZE Rs =
                ((PSERIAL_QUEUE_SIZE)(Irp->AssociatedIrp.SystemBuffer));

            if (irpStack->Parameters.DeviceIoControl.InputBufferLength <
                sizeof(SERIAL_QUEUE_SIZE)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            //
            // We have to allocate the memory for the new
            // buffer while we're still in the context of the
            // caller.  We don't even try to protect this
            // with a lock because the value could be stale
            // as soon as we release the lock - The only time
            // we will know for sure is when we actually try
            // to do the resize.
            //

            if (Rs->InSize <= deviceExtension->BufferSize) {

                ntStatus = STATUS_SUCCESS;
                break;

            }

            try {

                irpStack->Parameters.DeviceIoControl.Type3InputBuffer =
                    ExAllocatePoolWithQuota(
                        NonPagedPool,
                        Rs->InSize
                        );

            } except (EXCEPTION_EXECUTE_HANDLER) {

                irpStack->Parameters.DeviceIoControl.Type3InputBuffer = NULL;
                ntStatus = GetExceptionCode();

            }

            if (!irpStack->Parameters.DeviceIoControl.Type3InputBuffer) {

                break;

            }

            //
            // Well the data passed was big enough.  Do the request.
            //
            // There are two reason we place it in the read queue:
            //
            // 1) We want to serialize these resize requests so that
            //    they don't contend with each other.
            //
            // 2) We want to serialize these requests with reads since
            //    we don't want reads and resizes contending over the
            //    read buffer.
            //

            return SerialStartOrQueue(
                       deviceExtension,
                       Irp,
                       &deviceExtension->ReadQueue,
                       &deviceExtension->CurrentReadIrp,
                       SerialStartRead
                       );

            break;
		}
		case IOCTL_SERIAL_GET_WAIT_MASK: {

            if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
                sizeof(ULONG)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            //
            // Simple scalar read.  No reason to acquire a lock.
            //

            Irp->IoStatus.Information = sizeof(ULONG);

            *((ULONG *)Irp->AssociatedIrp.SystemBuffer) = deviceExtension->IsrWaitMask;

            break;

        }
		case IOCTL_SERIAL_SET_WAIT_MASK: {

            ULONG NewMask;

            DbgPrint("SERIAL: In Ioctl processing for set mask\n");
            if (irpStack->Parameters.DeviceIoControl.InputBufferLength <
                sizeof(ULONG)) {

	        DbgPrint("SERIAL: Invalid size fo the buffer %d\n",
				irpStack->Parameters.DeviceIoControl.InputBufferLength);
                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            } else {

                NewMask = *((ULONG *)Irp->AssociatedIrp.SystemBuffer);

            }

            //
            // Make sure that the mask only contains valid
            // waitable events.
            //

            if (NewMask & ~(SERIAL_EV_RXCHAR   |
                            SERIAL_EV_RXFLAG   |
                            SERIAL_EV_TXEMPTY  |
                            SERIAL_EV_CTS      |
                            SERIAL_EV_DSR      |
                            SERIAL_EV_RLSD     |
                            SERIAL_EV_BREAK    |
                            SERIAL_EV_ERR      |
                            SERIAL_EV_RING     |
                            SERIAL_EV_PERR     |
                            SERIAL_EV_RX80FULL |
                            SERIAL_EV_EVENT1   |
                            SERIAL_EV_EVENT2)) {

            DbgPrint("SERIAL: Unknown mask %x\n",NewMask);
                ntStatus = STATUS_INVALID_PARAMETER;
                break;

            }

            //
            // Either start this irp or put it on the
            // queue.
            //

            DbgPrint("SERIAL: Starting or queuing set mask irp %x\n",Irp);
            return SerialStartOrQueue(
                       deviceExtension,
                       Irp,
                       &deviceExtension->MaskQueue,
                       &deviceExtension->CurrentMaskIrp,
                       SerialStartMask
                       );

		}
        case IOCTL_SERIAL_WAIT_ON_MASK:	{

            SerialDump(
                SERDIAG3 | SERIRPPATH,
                ("SERIAL: In Ioctl processing for wait mask\n")
                );
            if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
                sizeof(ULONG)) {

                SerialDump(
                    SERDIAG3,
                    ("SERIAL: Invalid size for the buffer %d\n",
                     irpStack->Parameters.DeviceIoControl.OutputBufferLength)
                    );
                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            //
            // Either start this irp or put it on the
            // queue.
            //

            SerialDump(
                SERDIAG3 | SERIRPPATH,
                ("SERIAL: Starting or queuing wait mask irp %x\n",Irp)
                );
            return SerialStartOrQueue(
                       deviceExtension,
                       Irp,
                       &deviceExtension->MaskQueue,
                       &deviceExtension->CurrentMaskIrp,
                       SerialStartMask
                       );
			
		}
        case IOCTL_SERIAL_IMMEDIATE_CHAR: {

            KIRQL OldIrql;

            if (irpStack->Parameters.DeviceIoControl.InputBufferLength <
                sizeof(UCHAR)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            IoAcquireCancelSpinLock(&OldIrql);
            if (deviceExtension->CurrentImmediateIrp) {

                ntStatus = STATUS_INVALID_PARAMETER;
                IoReleaseCancelSpinLock(OldIrql);

            } else {

                //
                // We can queue the char.  We need to set
                // a cancel routine because flow control could
                // keep the char from transmitting.  Make sure
                // that the irp hasn't already been canceled.
                //

                if (Irp->Cancel) {

                    IoReleaseCancelSpinLock(OldIrql);
                    ntStatus = STATUS_CANCELLED;

                } else {

                    deviceExtension->CurrentImmediateIrp = Irp;
                    deviceExtension->TotalCharsQueued++;
                    IoReleaseCancelSpinLock(OldIrql);
 //                   SerialStartImmediate(deviceExtension);

                    return STATUS_PENDING;

                }

            }

            break;

        }
        case IOCTL_SERIAL_PURGE: {

            ULONG Mask;

            if (irpStack->Parameters.DeviceIoControl.InputBufferLength <
                sizeof(ULONG)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }
            //
            // Check to make sure that the mask only has
            // 0 or the other appropriate values.
            //

            Mask = *((ULONG *)(Irp->AssociatedIrp.SystemBuffer));

            if ((!Mask) || (Mask & (~(SERIAL_PURGE_TXABORT |
                                      SERIAL_PURGE_RXABORT |
                                      SERIAL_PURGE_TXCLEAR |
                                      SERIAL_PURGE_RXCLEAR
                                     )
                                   )
                           )) {

                ntStatus = STATUS_INVALID_PARAMETER;
                break;

            }

            //
            // Either start this irp or put it on the
            // queue.
            //

            return SerialStartOrQueue(
                       deviceExtension,
                       Irp,
                       &deviceExtension->PurgeQueue,
                       &deviceExtension->CurrentPurgeIrp,
                       SerialStartPurge
                       );

		}
        case IOCTL_SERIAL_GET_HANDFLOW: {

            if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
                sizeof(SERIAL_HANDFLOW)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            Irp->IoStatus.Information = sizeof(SERIAL_HANDFLOW);

            KeAcquireSpinLock(
                &deviceExtension->ControlLock,
                &OldIrql
                );

            *((PSERIAL_HANDFLOW)Irp->AssociatedIrp.SystemBuffer) =
                deviceExtension->HandFlow;

            KeReleaseSpinLock(
                &deviceExtension->ControlLock,
                OldIrql
                );

            break;

        }
        case IOCTL_SERIAL_SET_HANDFLOW: {

            SERIAL_IOCTL_SYNC S;
            PSERIAL_HANDFLOW HandFlow = Irp->AssociatedIrp.SystemBuffer;
			USHORT Value = 0;

            //
            // Make sure that the hand shake and control is the
            // right size.
            //

            if (irpStack->Parameters.DeviceIoControl.InputBufferLength <
                sizeof(SERIAL_HANDFLOW)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            //
            // Make sure that there are no invalid bits set in
            // the control and handshake.
            //

            if (HandFlow->ControlHandShake & SERIAL_CONTROL_INVALID) {

                ntStatus = STATUS_INVALID_PARAMETER;
                break;

            }

            if (HandFlow->FlowReplace & SERIAL_FLOW_INVALID) {

                ntStatus = STATUS_INVALID_PARAMETER;
                break;

            }

            //
            // Make sure that the app hasn't set an invlid DTR mode.
            //

            if ((HandFlow->ControlHandShake & SERIAL_DTR_MASK) ==
                SERIAL_DTR_MASK) {

                ntStatus = STATUS_INVALID_PARAMETER;
                break;

            }

            //
            // Make sure that haven't set totally invalid xon/xoff
            // limits.
            //

            if ((HandFlow->XonLimit < 0) ||
                ((ULONG)HandFlow->XonLimit > deviceExtension->BufferSize)) {

                ntStatus = STATUS_INVALID_PARAMETER;
                break;

            }

            if ((HandFlow->XoffLimit < 0) ||
                ((ULONG)HandFlow->XoffLimit > deviceExtension->BufferSize)) {

                ntStatus = STATUS_INVALID_PARAMETER;
                break;

            }

            S.Extension = deviceExtension;
            S.Data = HandFlow;

			DbgPrint("ControlHandShake = 0x%x\n", HandFlow->ControlHandShake);
			DbgPrint("FlowReplace = 0x%x\n", HandFlow->FlowReplace);
			DbgPrint("XonLimit = %ld\n", HandFlow->XonLimit);
			DbgPrint("XoffLimit = %ld\n", HandFlow->XoffLimit);

			if (HandFlow->ControlHandShake & SERIAL_DTR_HANDSHAKE)
				Value = 0x0A;

			if (HandFlow->FlowReplace & SERIAL_RTS_HANDSHAKE)
				Value |= 0x11;

			if (HandFlow->FlowReplace & (SERIAL_AUTO_TRANSMIT | SERIAL_AUTO_RECEIVE))
				Value |= 0x180;

			UsbCom_SendVendor(DeviceObject, VendorFlowCtrl, Value);
/*
            KeAcquireSpinLock(
                &deviceExtension->ControlLock,
                &OldIrql
                );

            //
            // Under the protection of the lock, make sure that
            // we aren't turning on error replacement when we
            // are doing line status/modem status insertion.
            //

            if (deviceExtension->EscapeChar) {

                if (HandFlow->FlowReplace & SERIAL_ERROR_CHAR) {

                    ntStatus = STATUS_INVALID_PARAMETER;
                    KeReleaseSpinLock(
                        &deviceExtension->ControlLock,
                        OldIrql
                        );
                    break;

                }

            }

            KeSynchronizeExecution(
                Extension->Interrupt,
                SerialSetHandFlow,
                &S
                );


//			SerialSetHandFlow(&S);



            KeReleaseSpinLock(
                &deviceExtension->ControlLock,
                OldIrql
                );
*/
            break;

        }
        case IOCTL_SERIAL_GET_MODEMSTATUS: {

            SERIAL_IOCTL_SYNC S;

            if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
                sizeof(ULONG)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            Irp->IoStatus.Information = sizeof(ULONG);

            S.Extension = deviceExtension;
            S.Data = Irp->AssociatedIrp.SystemBuffer;
/*
            KeAcquireSpinLock(
                &Extension->ControlLock,
                &OldIrql
                );

            KeSynchronizeExecution(
                Extension->Interrupt,
                SerialGetModemUpdate,
                &S
                );

            KeReleaseSpinLock(
                &Extension->ControlLock,
                OldIrql
                );
*/
			SerialGetModemUpdate(&S);

            break;

        }
		case IOCTL_SERIAL_GET_PROPERTIES: {

			if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
				sizeof(SERIAL_COMMPROP)) {

				ntStatus = STATUS_BUFFER_TOO_SMALL;
				break;

			}

			//
			// No synchronization is required since this information
			// is "static".
			//

			SerialGetProperties(
				deviceExtension,
				Irp->AssociatedIrp.SystemBuffer
				);

			Irp->IoStatus.Information = sizeof(SERIAL_COMMPROP);
			Irp->IoStatus.Status = STATUS_SUCCESS;

			break;
										  
		}
        case IOCTL_SERIAL_XOFF_COUNTER: {

            PSERIAL_XOFF_COUNTER Xc = Irp->AssociatedIrp.SystemBuffer;

            if (irpStack->Parameters.DeviceIoControl.InputBufferLength <
                sizeof(SERIAL_XOFF_COUNTER)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            if (Xc->Counter <= 0) {

                ntStatus = STATUS_INVALID_PARAMETER;
                break;

            }

            //
            // There is no output, so make that clear now
            //

            Irp->IoStatus.Information = 0;

            //
            // So far so good.  Put the irp onto the write queue.
            //

            return SerialStartOrQueue(
                       deviceExtension,
                       Irp,
                       &deviceExtension->WriteQueue,
                       &deviceExtension->CurrentWriteIrp,
                       SerialStartWrite
                       );

		}
        case IOCTL_SERIAL_LSRMST_INSERT: {

            PUCHAR escapeChar = Irp->AssociatedIrp.SystemBuffer;
            SERIAL_IOCTL_SYNC S;

            //
            // Make sure we get a byte.
            //

            if (irpStack->Parameters.DeviceIoControl.InputBufferLength <
                sizeof(UCHAR)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            KeAcquireSpinLock(
                &deviceExtension->ControlLock,
                &OldIrql
                );

            if (*escapeChar) {

                //
                // We've got some escape work to do.  We will make sure that
                // the character is not the same as the Xon or Xoff character,
                // or that we are already doing error replacement.
                //

                if ((*escapeChar == deviceExtension->SpecialChars.XoffChar) ||
                    (*escapeChar == deviceExtension->SpecialChars.XonChar) ||
                    (deviceExtension->HandFlow.FlowReplace & SERIAL_ERROR_CHAR)) {

                    ntStatus = STATUS_INVALID_PARAMETER;

                    KeReleaseSpinLock(
                        &deviceExtension->ControlLock,
                        OldIrql
                        );
                    break;

                }

            }

            S.Extension = deviceExtension;
            S.Data = Irp->AssociatedIrp.SystemBuffer;
/*
            KeSynchronizeExecution(
                Extension->Interrupt,
                SerialSetEscapeChar,
                Irp
                );
*/
			SerialSetEscapeChar(Irp);

            KeReleaseSpinLock(
                &deviceExtension->ControlLock,
                OldIrql
                );

            break;

		}
        case IOCTL_SERIAL_CONFIG_SIZE: {

            if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
                sizeof(ULONG)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }

            Irp->IoStatus.Information = sizeof(ULONG);
            Irp->IoStatus.Status = STATUS_SUCCESS;

            *(PULONG)Irp->AssociatedIrp.SystemBuffer = 0;

            break;
		}
        case IOCTL_SERIAL_GET_STATS: {

            if (irpStack->Parameters.DeviceIoControl.OutputBufferLength <
                sizeof(SERIALPERF_STATS)) {

                ntStatus = STATUS_BUFFER_TOO_SMALL;
                break;

            }
            Irp->IoStatus.Information = sizeof(SERIALPERF_STATS);
            Irp->IoStatus.Status = STATUS_SUCCESS;
/*
            KeSynchronizeExecution(
                Extension->Interrupt,
                SerialGetStats,
                Irp
                );
*/
            SerialGetStats(Irp);

            break;
        }
        case IOCTL_SERIAL_CLEAR_STATS: {
/*
            KeSynchronizeExecution(
                Extension->Interrupt,
                SerialClearStats,
                Extension
                );
*/
			SerialClearStats(deviceExtension);

            break;
        }
        default: {

            ntStatus = STATUS_INVALID_PARAMETER;
            break;
        }
	}

DoneWithIoctl:;

    Irp->IoStatus.Status = ntStatus;

    IoCompleteRequest (Irp,
                       IO_NO_INCREMENT
                       );

    UsbCom_DecrementIoCount(DeviceObject);                       

    return ntStatus;

}

VOID
SerialGetProperties(
    IN PDEVICE_EXTENSION Extension,
    IN PSERIAL_COMMPROP Properties
    )

/*++

Routine Description:

    This function returns the capabilities of this particular
    serial device.

Arguments:

    Extension - The serial device extension.

    Properties - The structure used to return the properties

Return Value:

    None.

--*/

{
	ULONG SupportedBauds = 0;
    RtlZeroMemory(
        Properties,
        sizeof(SERIAL_COMMPROP)
        );

    Properties->PacketLength = sizeof(SERIAL_COMMPROP);
    Properties->PacketVersion = 2;
    Properties->ServiceMask = SERIAL_SP_SERIALCOMM;
    Properties->MaxTxQueue = 0;
    Properties->MaxRxQueue = 0;

    Properties->MaxBaud = SERIAL_BAUD_USER;
    Properties->SettableBaud = Extension->SupportedBauds;

    Properties->ProvSubType = SERIAL_SP_RS232;
    Properties->ProvCapabilities = SERIAL_PCF_DTRDSR |
                                   SERIAL_PCF_RTSCTS |
                                   SERIAL_PCF_CD     |
                                   SERIAL_PCF_PARITY_CHECK |
                                   SERIAL_PCF_XONXOFF |
                                   SERIAL_PCF_SETXCHAR |
                                   SERIAL_PCF_TOTALTIMEOUTS |
                                   SERIAL_PCF_INTTIMEOUTS;
    Properties->SettableParams = SERIAL_SP_PARITY |
                                 SERIAL_SP_BAUD |
                                 SERIAL_SP_DATABITS |
                                 SERIAL_SP_STOPBITS |
                                 SERIAL_SP_HANDSHAKING |
                                 SERIAL_SP_PARITY_CHECK |
                                 SERIAL_SP_CARRIER_DETECT;


    Properties->SettableData = SERIAL_DATABITS_5 |
                               SERIAL_DATABITS_6 |
                               SERIAL_DATABITS_7 |
                               SERIAL_DATABITS_8;
    Properties->SettableStopParity = SERIAL_STOPBITS_10 |
                                     SERIAL_STOPBITS_15 |
                                     SERIAL_STOPBITS_20 |
                                     SERIAL_PARITY_NONE |
                                     SERIAL_PARITY_ODD  |
                                     SERIAL_PARITY_EVEN |
                                     SERIAL_PARITY_MARK |
                                     SERIAL_PARITY_SPACE;
    Properties->CurrentTxQueue = 0;
    Properties->CurrentRxQueue = Extension->BufferSize;

}


NTSTATUS
SerialInternalIoControl(IN PDEVICE_OBJECT PDevObj, IN PIRP PIrp)

/*++

Routine Description:

    This routine provides the initial processing for all of the
    internal Ioctrls for the serial device.

Arguments:

    PDevObj - Pointer to the device object for this device

    PIrp - Pointer to the IRP for the current request

Return Value:

    The function value is the final status of the call

--*/

{
    //
    // The status that gets returned to the caller and
    // set in the Irp.
    //
    NTSTATUS status;

    //
    // The current stack location.  This contains all of the
    // information we need to process this particular request.
    //
    PIO_STACK_LOCATION pIrpStack;

    //
    // Just what it says.  This is the serial specific device
    // extension of the device object create for the serial driver.
    //
    PDEVICE_EXTENSION pDevExt = PDevObj->DeviceExtension;

    //
    // A temporary to hold the old IRQL so that it can be
    // restored once we complete/validate this request.
    //
    KIRQL OldIrql;

    NTSTATUS prologueStatus;

    SYSTEM_POWER_STATE cap;

//    SERIAL_LOCKED_PAGED_CODE();
    SerialDump(SERIRPPATH, ("SERIAL: Dispatch InternalIoControl entry for: %x\n", PIrp));

/*
    if ((prologueStatus = SerialIRPPrologue(PIrp, pDevExt))
        != STATUS_SUCCESS) {
       SerialCompleteRequest(pDevExt, PIrp, IO_NO_INCREMENT);
       return prologueStatus;
    }

    SerialDump(SERIRPPATH, ("SERIAL: Dispatch InternalIoControl entry for: %x\n", PIrp));

    if (SerialCompleteIfError(PDevObj, PIrp) != STATUS_SUCCESS) {
        return STATUS_CANCELLED;
    }
*/

    UsbCom_IncrementIoCount(PDevObj);

    // Can't accept a new io request if:
    //  1) device is removed, 
    //  2) has never been started, 
    //  3) is stopped,
    //  4) has a remove request pending,
    //  5) has a stop device pending
    if ( !UsbCom_CanAcceptIoRequests( PDevObj ) ) {
        status = STATUS_DELETE_PENDING;
        PIrp->IoStatus.Status = status;
        PIrp->IoStatus.Information = 0;

        IoCompleteRequest( PIrp, IO_NO_INCREMENT );

		DbgPrint("Removed: %d, Started: %d, Stop: %d\n", 
			pDevExt->DeviceRemoved,
			pDevExt->DeviceStarted,
			pDevExt->StopDeviceRequested);

        UsbCom_DecrementIoCount(PDevObj);                          
        return status;
    }

    pIrpStack = IoGetCurrentIrpStackLocation(PIrp);
    PIrp->IoStatus.Information = 0L;
    status = STATUS_SUCCESS;

    switch (pIrpStack->Parameters.DeviceIoControl.IoControlCode) {

    //
    // Send a wait-wake IRP
    //

    case IOCTL_SERIAL_INTERNAL_DO_WAIT_WAKE:
       //
       // Make sure we can do wait-wake based on what the device reported
       //

       for (cap = PowerSystemSleeping1; cap < PowerSystemMaximum; cap++) {
          if ((pDevExt->DeviceStateMap[cap] >= PowerDeviceD0)
              && (pDevExt->DeviceStateMap[cap] <= pDevExt->DeviceWake)) {
             break;
          }
       }

       if (cap < PowerSystemMaximum) {
          pDevExt->SendWaitWake = TRUE;
          status = STATUS_SUCCESS;
       } else {
          status = STATUS_NOT_SUPPORTED;
       }
       break;

    case IOCTL_SERIAL_INTERNAL_CANCEL_WAIT_WAKE:
       pDevExt->SendWaitWake = FALSE;

       if (pDevExt->PendingWakeIrp != NULL) {
          IoCancelIrp(pDevExt->PendingWakeIrp);
       }

       status = STATUS_SUCCESS;
       break;


    //
    // Put the serial port in a "filter-driver" appropriate state
    //
    // WARNING: This code assumes it is being called by a trusted kernel
    // entity and no checking is done on the validity of the settings
    // passed to IOCTL_SERIAL_INTERNAL_RESTORE_SETTINGS
    //
    // If validity checking is desired, the regular ioctl's should be used
    //

    case IOCTL_SERIAL_INTERNAL_BASIC_SETTINGS:
    case IOCTL_SERIAL_INTERNAL_RESTORE_SETTINGS: {
       SERIAL_BASIC_SETTINGS basic;
       PSERIAL_BASIC_SETTINGS pBasic;
       SHORT AppropriateDivisor;
       SERIAL_IOCTL_SYNC S;

       if (pIrpStack->Parameters.DeviceIoControl.IoControlCode
           == IOCTL_SERIAL_INTERNAL_BASIC_SETTINGS) {


          //
          // Check the buffer size
          //

          if (pIrpStack->Parameters.DeviceIoControl.OutputBufferLength <
              sizeof(SERIAL_BASIC_SETTINGS)) {
             status = STATUS_BUFFER_TOO_SMALL;
             break;
          }

          //
          // Everything is 0 -- timeouts and flow control and fifos.  If
          // We add additional features, this zero memory method
          // may not work.
          //

          RtlZeroMemory(&basic, sizeof(SERIAL_BASIC_SETTINGS));

          basic.TxFifo = 1;
          basic.RxFifo = SERIAL_1_BYTE_HIGH_WATER;

          PIrp->IoStatus.Information = sizeof(SERIAL_BASIC_SETTINGS);
          pBasic = (PSERIAL_BASIC_SETTINGS)PIrp->AssociatedIrp.SystemBuffer;

          //
          // Save off the old settings
          //

          RtlCopyMemory(&pBasic->Timeouts, &pDevExt->Timeouts,
                        sizeof(SERIAL_TIMEOUTS));

          RtlCopyMemory(&pBasic->HandFlow, &pDevExt->HandFlow,
                        sizeof(SERIAL_HANDFLOW));

          pBasic->RxFifo = pDevExt->RxFifoTrigger;
          pBasic->TxFifo = pDevExt->TxFifoAmount;

          //
          // Point to our new settings
          //

          pBasic = &basic;
       } else { // restoring settings
          if (pIrpStack->Parameters.DeviceIoControl.InputBufferLength
              < sizeof(SERIAL_BASIC_SETTINGS)) {
             status = STATUS_BUFFER_TOO_SMALL;
             break;
          }

          pBasic = (PSERIAL_BASIC_SETTINGS)PIrp->AssociatedIrp.SystemBuffer;
       }

       KeAcquireSpinLock(&pDevExt->ControlLock, &OldIrql);

       //
       // Set the timeouts
       //

       RtlCopyMemory(&pDevExt->Timeouts, &pBasic->Timeouts,
                     sizeof(SERIAL_TIMEOUTS));

       //
       // Set flowcontrol
       //

       S.Extension = pDevExt;
       S.Data = &pBasic->HandFlow;
//       KeSynchronizeExecution(pDevExt->Interrupt, SerialSetHandFlow, &S);
//		SerialSetHandFlow(&S); henry
/*
       if (pDevExt->FifoPresent) {
          pDevExt->TxFifoAmount = pBasic->TxFifo;
          pDevExt->RxFifoTrigger = (UCHAR)pBasic->RxFifo;

          WRITE_FIFO_CONTROL(pDevExt->Controller, (UCHAR)0);
          READ_RECEIVE_BUFFER(pDevExt->Controller);
          WRITE_FIFO_CONTROL(pDevExt->Controller,
                             (UCHAR)(SERIAL_FCR_ENABLE | pDevExt->RxFifoTrigger
                                     | SERIAL_FCR_RCVR_RESET
                                     | SERIAL_FCR_TXMT_RESET));
       } else {
          pDevExt->TxFifoAmount = pDevExt->RxFifoTrigger = 0;
          WRITE_FIFO_CONTROL(pDevExt->Controller, (UCHAR)0);
       }
*/

       KeReleaseSpinLock(&pDevExt->ControlLock, OldIrql);


       break;
    }

    default:
       status = STATUS_INVALID_PARAMETER;
       break;

    }

    PIrp->IoStatus.Status = status;

    //SerialDump(SERIRPPATH, ("SERIAL: Complete Irp: %x\n", PIrp));
    SerialCompleteRequest(pDevExt, PIrp, 0);

    return status;
}


NTSTATUS
UsbCom_SetBaud(
	IN PDEVICE_OBJECT DeviceObject,
	IN PIRP Irp,
	IN ULONG baudrate
	)
{
	NTSTATUS Status;
	USHORT valueBaud;
	UCHAR i,index_matched;


	ULONG baudArray[14] = { 2400, 4800, 9600, 19200, 38400, 57600, 115200, 230400,
								110, 300, 1200, 460800, 921600 };
//#ifdef SS_USE_SINGLE_TI
//	USHORT valueBaudArray[14] = { 0xA0, 0xD0, 0x68, 0x34, 0x1A, 0x11, 0x09, 0x04,
//			                    0x68, 0x68, 0x42, 0x68, 0x68 };
//#endif

	USHORT valueBaudArray[14] = { 0x30, 0x18, 0x0C, 0x06, 0x03, 0x02, 0x01, 0x68,
			                    0x68, 0x1A, 0x60, 0x68, 0x68 };

	DbgPrint("enter UsbCom_SetBaud() DO=%08x Irp=%08x BaudRate=%u\n", DeviceObject, Irp, baudrate);

	index_matched = 255;

	for (i=0; i<14; i++)
	{
		if (baudArray[i] == baudrate)
			index_matched = i;
	}

	if (index_matched == 255) {
/*
		Irp->IoStatus.Status = STATUS_INVALID_PARAMETER; 
        Irp->IoStatus.Information = 0;

		IoCompleteRequest( Irp,
						   IO_NO_INCREMENT);

		UsbCom_DecrementIoCount(DeviceObject);
*/
		return STATUS_INVALID_PARAMETER;
	}

	valueBaud = valueBaudArray[index_matched];

	Status = UsbCom_SendVendor(DeviceObject, VendorBaudRate, valueBaud);
	
	DbgPrint("exit UsbCom_SetBaud() Status=%08x\n", Status );
	return Status;
}


NTSTATUS
UsbCom_SendVendor(
    IN  PDEVICE_OBJECT DeviceObject,
	IN	UCHAR Request,
	IN	USHORT Value
    )
{
    PDEVICE_EXTENSION deviceExtension;
    NTSTATUS ntStatus;
    PURB urb;
    ULONG siz;
    UCHAR ChannelNumber;


    deviceExtension = DeviceObject->DeviceExtension;
    ChannelNumber = (UCHAR)deviceExtension->ChannelNumber;

	Request = ( ((ChannelNumber << 5) & 0xe0) | ( Request & 0x1f ) );

    urb = ExAllocatePool(NonPagedPool,
                         sizeof(struct _URB_CONTROL_VENDOR_OR_CLASS_REQUEST));

    if (! urb) {
        DbgPrint("UsbCom_SendVendor()  DO=%08x ExAllocatePool() URB_CONTROL_VENDOR_OR_CLASS_REQUEST : FAIL\n", DeviceObject );
        ntStatus = STATUS_INSUFFICIENT_RESOURCES;
        goto UsbCom_SendVendorDone;
	}


	UsbBuildVendorRequest(urb,
                            URB_FUNCTION_VENDOR_DEVICE,
                            (USHORT) sizeof (struct _URB_CONTROL_VENDOR_OR_CLASS_REQUEST),
                            0,		// out direction
                            0,		// reserved bits in request type
                            Request,		// request
                            Value,	// value
                            0,		// index
                            NULL,
							NULL,
							0,
                            NULL);

    DbgPrint("UsbCom_SendVendor() DO=%08x Urb=%08x [Channel=%u Request=%02x Value=%04x]\n", 
		DeviceObject, urb, ChannelNumber, Request, Value);

	ntStatus = UsbCom_CallUSBD(DeviceObject, urb);

    ExFreePool(urb);

UsbCom_SendVendorDone:
 //   DbgPrint("exit UsbCom_SendVendor DO=%08x Status=%x\n", DeviceObject, ntStatus);
    return ntStatus;
}

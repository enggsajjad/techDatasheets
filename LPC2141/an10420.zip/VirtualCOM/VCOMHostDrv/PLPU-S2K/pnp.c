/*++


Module Name:

    Pnp.c

Abstract:

    Plug and Play module

Environment:

    kernel mode only

Notes:

  Copyright (c) 1997-2000 Maverick Corporation.  All Rights Reserved.


Revision History:

    04/26/00: created

--*/


#include "wdm.h"
#include "stdarg.h"
#include "stdio.h"

#include "usbdi.h"
#include "usbdlib.h"
#include "usbcom.h"

ULONG GlobalPdaCount = 0;

VOID 
ASICInitRoutine(
     IN  PDEVICE_OBJECT DeviceObject
    )    
{
    PURB Urb;
    PIRP Irp;
    CHAR StackSize;
    PDEVICE_OBJECT stackDeviceObject;
    PDEVICE_EXTENSION DeviceExtension;
    PIO_STACK_LOCATION NextStack;
    ULONG UrbSize;
    ULONG i;
    NTSTATUS ntStatus = STATUS_SUCCESS;
    NTSTATUS waitStatus;

    #define INIT_ARRAY_SIZE 3

    USHORT  AsicInitData[INIT_ARRAY_SIZE][3] = 
    { {0xF4,0x0000,0x0000 },
      {0xFA,0x0011,0x0060 },
      {0xFA,0x0008,0x0081 }
    };


    DeviceExtension = DeviceObject->DeviceExtension;
    stackDeviceObject = DeviceExtension->TopOfStackDeviceObject;

    // Allocate IRP for our I/O request
    StackSize = (CCHAR)(DeviceExtension->TopOfStackDeviceObject->StackSize + 1);
    Irp = IoAllocateIrp(StackSize, FALSE);

    if (!Irp) {
        DbgPrint("Failure due to memory error\n");
        // Can't init ASIC
        return;
    }
	
    // Allocate URB.  It will be reused for the data transfer, so insure
    // it is large enough for both control and bulk transfers
    UrbSize = sizeof (struct _URB_CONTROL_VENDOR_OR_CLASS_REQUEST);


    Urb = ExAllocatePool(NonPagedPool, UrbSize);

    if (!Urb)
    {
      DbgPrint ("Failure due to memory error\n");
      IoFreeIrp(Irp);
      return;
    }

    for(i= 0; i < INIT_ARRAY_SIZE; i++)
	  {
	    KEVENT initASICEvent;

            KeInitializeEvent(&initASICEvent, NotificationEvent, FALSE);

	    // Build URB for the ADSC command used to send the CDB to our USB drive
	    UsbBuildVendorRequest(
				  Urb,
				  URB_FUNCTION_VENDOR_DEVICE,
				  (USHORT) sizeof (struct _URB_CONTROL_VENDOR_OR_CLASS_REQUEST),
				  0,
				  0,
				  (UCHAR) AsicInitData[i][0],        //ADSC,
				  AsicInitData[i][1],        //ADSC,
				  AsicInitData[i][2],        //ADSC,
				  NULL,
				  NULL,
				  0,
				  NULL
				  );

	    NextStack = IoGetNextIrpStackLocation(Irp);
    
	    ASSERT(NextStack != NULL);
	    ASSERT(DeviceObject->StackSize>1);

    // Initialize our Irp
	    NextStack->MajorFunction = IRP_MJ_INTERNAL_DEVICE_CONTROL;
	    NextStack->Parameters.Others.Argument1 = Urb;
	    NextStack->Parameters.DeviceIoControl.IoControlCode = IOCTL_INTERNAL_USB_SUBMIT_URB;

	    // Register our Irp completion handler
	    IoSetCompletionRoutine (
				   Irp,
				   UsbCom_IrpCompletionRoutine,
				   &initASICEvent, 
				   TRUE,    // invoke on success
				   TRUE,    // invoke on error
				   TRUE     // invoke on cancellation of the Irp
				   );

	    UsbCom_IncrementIoCount(DeviceObject);

	    // Pass Irp to the USB driver stack
	    ntStatus = IoCallDriver(stackDeviceObject, Irp);
	    
            if (ntStatus == STATUS_PENDING) {

	      // wait for irp to complete
	      waitStatus = KeWaitForSingleObject(
						 &initASICEvent,
						 Suspended,
						 KernelMode,
						 FALSE,
						 NULL
						 );
	      
            }

	    UsbCom_DecrementIoCount(DeviceObject);
	    
	  }
    
    IoFreeIrp(Irp);
    ExFreePool(Urb);



}


NTSTATUS
UsbCom_ProcessPnPIrp(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP           Irp
    )
/*++

Routine Description:

    Dispatch table routine for IRP_MJ_PNP.
    Process the Plug and Play IRPs sent to this device.

Arguments:

    DeviceObject - pointer to our FDO (Functional Device Object)

    Irp          - pointer to an I/O Request Packet

Return Value:

    NT status code

--*/
{

    PIO_STACK_LOCATION irpStack;
    PDEVICE_EXTENSION deviceExtension;
    NTSTATUS ntStatus = STATUS_SUCCESS;
    NTSTATUS waitStatus;
    PDEVICE_OBJECT stackDeviceObject;
    KEVENT startDeviceEvent;


    //
    // Get a pointer to the current location in the Irp. This is where
    //     the function codes and parameters are located.
    //
    irpStack = IoGetCurrentIrpStackLocation (Irp);

    //
    // Get a pointer to the device extension
    //

    deviceExtension = DeviceObject->DeviceExtension;
    stackDeviceObject = deviceExtension->TopOfStackDeviceObject;

    DbgPrint("enter UsbCom_ProcessPnPIrp() IRP_MJ_PNP, minor %s, -- %x\n",
        UsbCom_StringForPnpMnFunc( irpStack->MinorFunction ), irpStack->MinorFunction );

	// inc the FDO device extension's pending IO count for this Irp
    UsbCom_IncrementIoCount(DeviceObject);

    ASSERT( IRP_MJ_PNP == irpStack->MajorFunction );

    switch (irpStack->MinorFunction) {
    case IRP_MN_START_DEVICE:

        // The PnP Manager sends this IRP after it has assigned resources,
        // if any, to the device. The device may have been recently enumerated
        // and is being started for the first time, or the device may be
        // restarting after being stopped for resource reconfiguration.

        // Initialize an event we can wait on for the PDO to be done with this irp
        KeInitializeEvent(&startDeviceEvent, NotificationEvent, FALSE);
        IoCopyCurrentIrpStackLocationToNext(Irp);

        // Set a completion routine so it can signal our event when
        //  the PDO is done with the Irp
        IoSetCompletionRoutine(Irp,
                               UsbCom_IrpCompletionRoutine,
                               &startDeviceEvent,  // pass the event to the completion routine as the Context
                               TRUE,    // invoke on success
                               TRUE,    // invoke on error
                               TRUE);   // invoke on cancellation


        // let the PDO process the IRP
        ntStatus = IoCallDriver(stackDeviceObject,
                                Irp);

        // if PDO is not done yet, wait for the event to be set in our completion routine
        if (ntStatus == STATUS_PENDING) {
             // wait for irp to complete

            waitStatus = KeWaitForSingleObject(
                &startDeviceEvent,
                Suspended,
                KernelMode,
                FALSE,
                NULL);

            ntStatus = Irp->IoStatus.Status;
        }

        if (NT_SUCCESS(ntStatus)) {

            // Now we're ready to do our own startup processing.
            // USB client drivers such as us set up URBs (USB Request Packets) to send requests
            // to the host controller driver (HCD). The URB structure defines a format for all
            // possible commands that can be sent to a USB device.
            // Here, we request the device descriptor and store it,
            // and configure the device.
            ntStatus = UsbCom_StartDevice(DeviceObject);
            Irp->IoStatus.Status = ntStatus;
        }

        IoCompleteRequest (Irp,
                           IO_NO_INCREMENT
                           );
#ifdef  USE_SMARTNIC
	    // Initialize
	    ASICInitRoutine(DeviceObject);
	    // Give the device another  second to settle.
	    KeStallExecutionProcessor(1000);
#endif		

        UsbCom_DecrementIoCount(DeviceObject);
        return ntStatus;  // end, case IRP_MN_START_DEVICE
   

    case IRP_MN_QUERY_STOP_DEVICE:

        // The IRP_MN_QUERY_STOP_DEVICE/IRP_MN_STOP_DEVICE sequence only occurs
        // during "polite" shutdowns, such as the user explicitily requesting the
        // service be stopped in, or requesting unplug from the Pnp tray icon.
        // This sequence is NOT received during "impolite" shutdowns,
        // such as someone suddenly yanking the USB cord or otherwise
        // unexpectedly disabling/resetting the device.

        // If a driver sets STATUS_SUCCESS for this IRP,
        // the driver must not start any operations on the device that
        // would prevent that driver from successfully completing an IRP_MN_STOP_DEVICE
        // for the device.
        // For mass storage devices such as disk drives, while the device is in the
        // stop-pending state,the driver holds IRPs that require access to the device,
        // but for most USB devices, there is no 'persistent storage', so we will just
        // refuse any more IO until restarted or the stop is cancelled

        // If a driver in the device stack determines that the device cannot be
        // stopped for resource reconfiguration, the driver is not required to pass
        // the IRP down the device stack. If a query-stop IRP fails,
        // the PnP Manager sends an IRP_MN_CANCEL_STOP_DEVICE to the device stack,
        // notifying the drivers for the device that the query has been cancelled
        // and that the device will not be stopped.


        // It is possible to receive this irp when the device has not been started
        //  ( as on a boot device )
        if (!deviceExtension->DeviceStarted) { // if get when never started, just pass on
            DbgPrint("UsbCom_ProcessPnPIrp() IRP_MN_QUERY_STOP_DEVICE when device not started\n");
            IoSkipCurrentIrpStackLocation (Irp);
            ntStatus = IoCallDriver (deviceExtension->TopOfStackDeviceObject, Irp);
            UsbCom_DecrementIoCount(DeviceObject);

            return ntStatus;
        }

        // Cancel any pending io requests; we may not have gotten a query first!
//        UsbCom_CancelPendingIo( DeviceObject );

        // If any pipes are still open, call USBD with URB_FUNCTION_ABORT_PIPE
        // This call will also close the pipes; if any user close calls get through,
        // they will be noops
        UsbCom_AbortPipes( DeviceObject );

        deviceExtension->StopDeviceRequested = TRUE;

        // Wait for any io request pending in our driver to
        // complete before returning success.
                // This  event is set when deviceExtension->PendingIoCount goes to 1
        waitStatus = KeWaitForSingleObject(
                    &deviceExtension->NoPendingIoEvent,
                    Suspended,
                    KernelMode,
                    FALSE,
                    NULL);

        Irp->IoStatus.Status = STATUS_SUCCESS;
        

        break; // end, case IRP_MN_QUERY_STOP_DEVICE

    case IRP_MN_CANCEL_STOP_DEVICE:

                // The PnP Manager uses this IRP to inform the drivers for a device
                // that the device will not be stopped for resource reconfiguration.
                // This should only be received after a successful IRP_MN_QUERY_STOP_DEVICE.


        // It is possible to receive this irp when the device has not been started
        if (!deviceExtension->DeviceStarted) { // if get when never started, just pass on
            DbgPrint("UsbCom_ProcessPnPIrp() IRP_MN_CANCEL_STOP_DEVICE when device not started\n");
            IoSkipCurrentIrpStackLocation (Irp);
            ntStatus = IoCallDriver (deviceExtension->TopOfStackDeviceObject, Irp);
            UsbCom_DecrementIoCount(DeviceObject);
            return ntStatus;
        }

                // Reset this flag so new IOCTL and IO Irp processing will be re-enabled
        deviceExtension->StopDeviceRequested = FALSE;
        Irp->IoStatus.Status = STATUS_SUCCESS;
        break; // end, case IRP_MN_CANCEL_STOP_DEVICE

	case IRP_MN_QUERY_CAPABILITIES: {

		PDEVICE_CAPABILITIES pdc;
		KEVENT event;
        //
        // Send this down to the PDO first
        //

        KeInitializeEvent (&event, NotificationEvent, FALSE);
        IoCopyCurrentIrpStackLocationToNext (Irp);

        IoSetCompletionRoutine (Irp,
                                UsbCom_IrpCompletionRoutine,
                                &event,
                                TRUE,
                                TRUE,
                                TRUE);

        ntStatus = IoCallDriver (stackDeviceObject, Irp);

        if (STATUS_PENDING == ntStatus) {
            // wait for it...

            ntStatus = KeWaitForSingleObject (&event,
                                            Executive,
                                            KernelMode,
                                            FALSE, // Not allertable
                                            NULL); // No timeout structure

            ASSERT (STATUS_SUCCESS == ntStatus);

            ntStatus = Irp->IoStatus.Status;
        }
        if (NT_SUCCESS(ntStatus)) {

            //irpStack = IoGetCurrentIrpStackLocation(Irp);
			pdc = irpStack->Parameters.DeviceCapabilities.Capabilities;

			// Allow surprise removals...
			DbgPrint("[ss] Allow surprise removals -- \n");
			pdc->SurpriseRemovalOK = TRUE;

        }

        UsbCom_DecrementIoCount(DeviceObject);

		DbgPrint("Allow surprise removals\n");	

        return ntStatus;    
	}

    case IRP_MN_STOP_DEVICE:

        // The PnP Manager sends this IRP to stop a device so it can reconfigure
        // its hardware resources. The PnP Manager only sends this IRP if a prior
        // IRP_MN_QUERY_STOP_DEVICE completed successfully.


        // Cancel any pending io requests.  (there shouldn't be any)
        //UsbCom_CancelPendingIo( DeviceObject );
        
		//
		// If any pipes are still open, call USBD with URB_FUNCTION_ABORT_PIPE
        // This call will also close the pipes; if any user close calls get through,
        // they will be noops
        UsbCom_AbortPipes( DeviceObject );
		
		
		//
        // Send the select configuration urb with a NULL pointer for the configuration
        // handle, this closes the configuration and puts the device in the 'unconfigured'
        // state.
        //
        ntStatus = UsbCom_StopDevice(DeviceObject);
        Irp->IoStatus.Status = ntStatus;

		break; // end, case IRP_MN_STOP_DEVICE

    case IRP_MN_QUERY_REMOVE_DEVICE:

        //  In response to this IRP, drivers indicate whether the device can be
        //  removed without disrupting the system.
        //  If a driver determines it is safe to remove the device,
        //  the driver completes any outstanding I/O requests, arranges to hold any subsequent
        //  read/write requests, and sets Irp->IoStatus.Status to STATUS_SUCCESS. Function
        //  and filter drivers then pass the IRP to the next-lower driver in the device stack.
        //  The underlying bus driver calls IoCompleteRequest.

        //  If a driver sets STATUS_SUCCESS for this IRP, the driver must not start any
        //  operations on the device that would prevent that driver from successfully completing
        //  an IRP_MN_REMOVE_DEVICE for the device. If a driver in the device stack determines
        //  that the device cannot be removed, the driver is not required to pass the
        //  query-remove IRP down the device stack. If a query-remove IRP fails, the PnP Manager
        //  sends an IRP_MN_CANCEL_REMOVE_DEVICE to the device stack, notifying the drivers for
        //  the device that the query has been cancelled and that the device will not be removed.

        // It is possible to receive this irp when the device has not been started
        if (!deviceExtension->DeviceStarted) { // if get when never started, just pass on
            DbgPrint("UsbCom_ProcessPnPIrp() IRP_MN_QUERY_STOP_DEVICE when device not started\n");
            IoSkipCurrentIrpStackLocation (Irp);
            ntStatus = IoCallDriver (deviceExtension->TopOfStackDeviceObject, Irp);
            UsbCom_DecrementIoCount(DeviceObject);

            return ntStatus;
        }

                // Once RemoveDeviceRequested is set no new IOCTL or read/write irps will be passed
                // down the stack to lower drivers; all will be quickly failed
       deviceExtension->RemoveDeviceRequested = TRUE;

        // Wait for any io request pending in our driver to
        // complete before returning success.
                // This  event is set when deviceExtension->PendingIoCount goes to 1
        waitStatus = KeWaitForSingleObject(
                    &deviceExtension->NoPendingIoEvent,
                    Suspended,
                    KernelMode,
                    FALSE,
                    NULL);


        Irp->IoStatus.Status = STATUS_SUCCESS;
        break; // end, case IRP_MN_QUERY_REMOVE_DEVICE

    case IRP_MN_CANCEL_REMOVE_DEVICE:

                // The PnP Manager uses this IRP to inform the drivers
                // for a device that the device will not be removed.
                // It is sent only after a successful IRP_MN_QUERY_REMOVE_DEVICE.

        if (!deviceExtension->DeviceStarted) { // if get when never started, just pass on
            DbgPrint("UsbCom_ProcessPnPIrp() IRP_MN_CANCEL_REMOVE_DEVICE when device not started\n");
            IoSkipCurrentIrpStackLocation (Irp);
            ntStatus = IoCallDriver (deviceExtension->TopOfStackDeviceObject, Irp);
            UsbCom_DecrementIoCount(DeviceObject);
            return ntStatus;
        }

                // Reset this flag so new IOCTL and IO Irp processing will be re-enabled
        deviceExtension->RemoveDeviceRequested = FALSE;
        Irp->IoStatus.Status = STATUS_SUCCESS;

        break; // end, case IRP_MN_CANCEL_REMOVE_DEVICE
#if 1
    case IRP_MN_SURPRISE_REMOVAL: {
	
        DbgPrint("UsbCom_ProcessPnPIrp() IRP_MN_SURPRISE_REMOVAL FDO=%08x\n", DeviceObject );
		
	
		IoSetDeviceInterfaceState ( &deviceExtension->DeviceNameLink, FALSE);

        // For a surprise-style device removal ( i.e. sudden cord yank ),
        // the physical device has already been removed so the PnP Manager sends
        // the remove IRP without a prior query-remove. A device can be in any state
        // when it receives a remove IRP as a result of a surprise-style removal.

        // match the inc at the begining of the dispatch routine
        UsbCom_DecrementIoCount(DeviceObject);

        //
        // Once DeviceRemoved is set no new IOCTL or read/write irps will be passed
        // down the stack to lower drivers; all will be quickly failed
        //
        deviceExtension->DeviceRemoved = TRUE;

        // Cancel any pending io requests; we may not have gotten a query first!
        //UsbCom_CancelPendingIo( DeviceObject );

        // If any pipes are still open, call USBD with URB_FUNCTION_ABORT_PIPE
        // This call will also close the pipes; if any user close calls get through,
        // they will be noops
        //UsbCom_AbortPipes( DeviceObject );

        //
        // Mark this handled
        //
        Irp->IoStatus.Status = STATUS_SUCCESS;

        // We don't explicitly wait for the below driver to complete, but just make
        // the call and go on, finishing cleanup
        IoCopyCurrentIrpStackLocationToNext(Irp);

        ntStatus = IoCallDriver(stackDeviceObject,
                                Irp);
        return ntStatus;
	}
	break;
#else

    case IRP_MN_SURPRISE_REMOVAL:
        DbgPrint("UsbCom_ProcessPnPIrp() IRP_MN_SURPRISE_REMOVAL\n");

		GlobalPdaCount = 0;
		Irp->IoStatus.Status = STATUS_SUCCESS;
		Irp->IoStatus.Information = 0;

		IoSkipCurrentIrpStackLocation(Irp);
		Status = IoCallDriver(stackDeviceObject, Irp);
		break;
#endif
		
    case IRP_MN_REMOVE_DEVICE:
        DbgPrint("UsbCom_ProcessPnPIrp() IRP_MN_REMOVE_DEVICE FDO=%08x\n", DeviceObject );

        // The PnP Manager uses this IRP to direct drivers to remove a device.
        // For a "polite" device removal, the PnP Manager sends an
        // IRP_MN_QUERY_REMOVE_DEVICE prior to the remove IRP. In this case,
        // the device is in the remove-pending state when the remove IRP arrives.
        // For a surprise-style device removal ( i.e. sudden cord yank ),
        // the physical device has already been removed and the PnP Manager may not
        //  have sent IRP_MN_SURPRISE_REMOVAL. A device can be in any state
        // when it receives a remove IRP as a result of a surprise-style removal.

        // match the inc at the begining of the dispatch routine
        UsbCom_DecrementIoCount(DeviceObject);

        //
        // Once DeviceRemoved is set no new IOCTL or read/write irps will be passed
        // down the stack to lower drivers; all will be quickly failed
        //
        deviceExtension->DeviceRemoved = TRUE;

        // Cancel any pending io requests; we may not have gotten a query first!
        UsbCom_CancelPendingIo( DeviceObject );

        // If any pipes are still open, call USBD with URB_FUNCTION_ABORT_PIPE
        // This call will also close the pipes; if any user close calls get through,
        // they will be noops
        UsbCom_AbortPipes( DeviceObject );
		
        // We don't explicitly wait for the below driver to complete, but just make
        // the call and go on, finishing cleanup
        IoCopyCurrentIrpStackLocationToNext(Irp);

        ntStatus = IoCallDriver(stackDeviceObject,
                                Irp);
        //
        // The final decrement to device extension PendingIoCount == 0
                // will set deviceExtension->RemoveEvent, enabling device removal.
                // If there is no pending IO at this point, the below decrement will be it.
        //
        UsbCom_DecrementIoCount(DeviceObject);

        // wait for any io request pending in our driver to
        // complete for finishing the remove

        KeWaitForSingleObject(
                    &deviceExtension->RemoveEvent,
                    Suspended,
                    KernelMode,
                    FALSE,
                    NULL);

        //
        // Delete the link and FDO we created
        //
        UsbCom_RemoveDevice(DeviceObject);


        DbgPrint("UsbCom_ProcessPnPIrp() Detaching from %08X\n",
                         deviceExtension->TopOfStackDeviceObject);

		//
		// We're cleaning up here.  One reason we're cleaning up
		// is that we couldn't allocate space for the directory
		// name or the symbolic link.
		//
		if (deviceExtension->SymbolicLinkName.Buffer &&
			deviceExtension->CreatedSymbolicLink) {
        
			IoDeleteSymbolicLink (&deviceExtension->SymbolicLinkName);

		}

		//
		// We're cleaning up here.  One reason we're cleaning up
		// is that we couldn't allocate space for the NtNameOfPort.
		//

		if ((deviceExtension->DeviceName.Buffer != NULL)
				&& deviceExtension->CreatedSerialCommEntry) {

			ntStatus = RtlDeleteRegistryValue(RTL_REGISTRY_DEVICEMAP, SERIAL_DEVICE_MAP,
										 deviceExtension->DeviceName.Buffer);

			if (!NT_SUCCESS(ntStatus)) {
				DbgPrint("Couldn't delete value entry \n");
			}
		}

        IoDetachDevice(deviceExtension->TopOfStackDeviceObject);

        DbgPrint("UsbCom_ProcessPnPIrp() Deleting %08X\n",
                         DeviceObject);

		if (deviceExtension->DeviceName.Buffer != NULL) {
			ExFreePool(deviceExtension->DeviceName.Buffer);
		}

		if (deviceExtension->SymbolicLinkName.Buffer != NULL) {
			ExFreePool(deviceExtension->SymbolicLinkName.Buffer);
		}
        
		IoDeleteDevice (DeviceObject);

        return ntStatus; // end, case IRP_MN_REMOVE_DEVICE


    default:

        //
        // In this case we must not touch the status. As ntstatus is
        // STATUS_SUCCESS, we will skip the failure case and pass down the IRP
        // untouched.
        //
        DbgPrint("UsbCom_ProcessPnPIrp() Minor PnP IOCTL not handled\n");
    } /* case MinorFunction  */


    if (!NT_SUCCESS(ntStatus)) {

        // if anything went wrong, return failure  without passing Irp down
        Irp->IoStatus.Status = ntStatus;
        IoCompleteRequest (Irp,
                                           IO_NO_INCREMENT
                                           );

        UsbCom_DecrementIoCount(DeviceObject);

        DbgPrint("UsbCom_ProcessPnPIrp() Exit UsbCom_ProcessPnPIrp FAILURE %x\n", ntStatus);
        return ntStatus;
    }

    IoCopyCurrentIrpStackLocationToNext(Irp);

    //
    // All PNP_POWER messages get passed to the TopOfStackDeviceObject
    // we were given in PnPAddDevice
    //

    DbgPrint("UsbCom_ProcessPnPIrp() Passing PnP Irp down, status = %x\n", ntStatus);

    ntStatus = IoCallDriver(stackDeviceObject,
                            Irp);

    UsbCom_DecrementIoCount(DeviceObject);

    DbgPrint("UsbCom_ProcessPnPIrp() Exit UsbCom_ProcessPnPIrp %x\n", ntStatus);

    return ntStatus;
}


NTSTATUS
UsbCom_PnPAddDevice(
    IN PDRIVER_OBJECT DriverObject,
    IN PDEVICE_OBJECT PhysicalDeviceObject
    )
/*++

Routine Description:

    This routine is called to create and initialize our Functional Device Object (FDO).
    For monolithic drivers, this is done in DriverEntry(), but Plug and Play devices
    wait for a PnP event

Arguments:

    DriverObject - pointer to the driver object for this instance of UsbCom

    PhysicalDeviceObject - pointer to a device object created by the bus

Return Value:

    STATUS_SUCCESS if successful,
    STATUS_UNSUCCESSFUL otherwise

--*/
{
    NTSTATUS                ntStatus = STATUS_SUCCESS;
    PDEVICE_OBJECT          deviceObject = NULL;
    PDEVICE_EXTENSION       deviceExtension;
    PURB Urb;
    PIRP Irp;
    CHAR StackSize;
    ULONG UrbSize;
    //USBD_VERSION_INFORMATION versionInformation;
    ULONG i;



    DbgPrint("enter UsbCom_PnPAddDevice()\n");

	GlobalPdaCount = 0;
    
	if(GlobalPdaCount) {
		DbgPrint("Can not support one more PDA!!\n");
		return STATUS_NOT_SUPPORTED;
	}

	GlobalPdaCount = 1;
    //
    // create our funtional device object (FDO)
    //

    ntStatus =
        UsbCom_CreateDeviceObject(DriverObject, PhysicalDeviceObject, &deviceObject);

    if (NT_SUCCESS(ntStatus)) {
        deviceExtension = deviceObject->DeviceExtension;
		deviceExtension->DeviceObject = deviceObject;
        //
        // we support direct io for read/write
        //
        deviceObject->Flags |= DO_BUFFERED_IO;


        //Set this flag causes the driver to not receive a IRP_MN_STOP_DEVICE
        //during suspend and also not get an IRP_MN_START_DEVICE during resume.
        //This is neccesary because during the start device call,
        // the GetDescriptors() call  will be failed by the USB stack.
        deviceObject->Flags |= DO_POWER_PAGABLE;

        // initialize our device extension
        //
        // remember the Physical device Object
        //
        deviceExtension->PhysicalDeviceObject=PhysicalDeviceObject;

        //
        // Attach to the PDO
        //

        deviceExtension->TopOfStackDeviceObject =
            IoAttachDeviceToDeviceStack(deviceObject, PhysicalDeviceObject);

        // Get a copy of the physical device's capabilities into a
        // DEVICE_CAPABILITIES struct in our device extension;
        // We are most interested in learning which system power states
        // are to be mapped to which device power states for handling
        // IRP_MJ_SET_POWER Irps.
        UsbCom_QueryCapabilities(deviceExtension->TopOfStackDeviceObject,
                                 &deviceExtension->DeviceCapabilities);


                // We want to determine what level to auto-powerdown to; This is the lowest
                //  sleeping level that is LESS than D3;
                // If all are set to D3, auto powerdown/powerup will be disabled.

        deviceExtension->PowerDownLevel = PowerDeviceUnspecified; // init to disabled
        for (i=PowerSystemSleeping1; i<= PowerSystemSleeping3; i++) {

                        if ( deviceExtension->DeviceCapabilities.DeviceState[i] < PowerDeviceD3 )
                                deviceExtension->PowerDownLevel = deviceExtension->DeviceCapabilities.DeviceState[i];
        }

        // We keep a pending IO count ( extension->PendingIoCount )  in the device extension.
        // The first increment of this count is done on adding the device.
        // Subsequently, the count is incremented for each new IRP received and
        // decremented when each IRP is completed or passed on.

        // Transition to 'one' therefore indicates no IO is pending and signals
        // deviceExtension->NoPendingIoEvent. This is needed for processing
        // IRP_MN_QUERY_REMOVE_DEVICE

        // Transition to 'zero' signals an event ( deviceExtension->RemoveEvent )
        // to enable device removal. This is used in processing for IRP_MN_REMOVE_DEVICE
        //
        UsbCom_IncrementIoCount(deviceObject);


		// Allocate IRP for our I/O request
		Irp = NULL;
		StackSize = (CCHAR)(deviceExtension->TopOfStackDeviceObject->StackSize + 1);
		Irp = IoAllocateIrp(StackSize, FALSE);

		if (!Irp) {
			DbgPrint("Failure due to memory error\n");

			// Can't allocate IRP - complete request with error and return
			ntStatus = STATUS_INSUFFICIENT_RESOURCES;

			goto ErrorProcess;
		}
		
		// Allocate URB.  It will be reused for the data transfer, so insure
		// it is large enough for both control and bulk transfers
		UrbSize = max(sizeof (struct _URB_CONTROL_VENDOR_OR_CLASS_REQUEST),
					  sizeof (struct _URB_BULK_OR_INTERRUPT_TRANSFER) );

		Urb = NULL;
		Urb = ExAllocatePool(NonPagedPool, UrbSize);

		if (!Urb) {
			DbgPrint("Failure due to memory error\n");
			ntStatus = STATUS_INSUFFICIENT_RESOURCES;
			
			goto ErrorProcess;
		}
		
		// Store all the transfer request info in our device extension
		deviceExtension->ReadingUrb = Urb;
		deviceExtension->ReadingIrp = Irp;
		deviceExtension->readpending = FALSE;


		// Allocate IRP for our I/O request
		Irp = NULL;
		StackSize = (CCHAR)(deviceExtension->TopOfStackDeviceObject->StackSize + 1);
		Irp = IoAllocateIrp(StackSize, FALSE);

		if (!Irp) {
			DbgPrint("Failure due to memory error -- Allocate Irp for WRITE_REQUEST\n");

			// Can't allocate IRP - complete request with error and return
			ntStatus = STATUS_INSUFFICIENT_RESOURCES;

			goto ErrorProcess;
		}
		
		// Allocate URB.  It will be reused for the data transfer, so insure
		// it is large enough for both control and bulk transfers
		UrbSize = max(sizeof (struct _URB_CONTROL_VENDOR_OR_CLASS_REQUEST),
					  sizeof (struct _URB_BULK_OR_INTERRUPT_TRANSFER) );

		Urb = NULL;
		Urb = ExAllocatePool(NonPagedPool, UrbSize);

		if (!Urb) {
			DbgPrint("Failure due to memory error -- Allocate Urb for WRITE_REQUEST\n");
			ntStatus = STATUS_INSUFFICIENT_RESOURCES;
			
			goto ErrorProcess;
		}
		
		// Store all the transfer request info in our device extension
		deviceExtension->WritingUrb = Urb;
		deviceExtension->WritingIrp = Irp;
		deviceExtension->writepending = FALSE;


		// Henry-------------------------------------------------------------------//
		// Allocate IRP for our I/O request
		Irp = NULL;
		StackSize = (CCHAR)(deviceExtension->TopOfStackDeviceObject->StackSize + 1);
		Irp = IoAllocateIrp(StackSize, FALSE);

		if (!Irp) {
			DbgPrint("Failure due to memory error -- Allocate Irp for WRITE_REQUEST\n");

			// Can't allocate IRP - complete request with error and return
			ntStatus = STATUS_INSUFFICIENT_RESOURCES;

			goto ErrorProcess;
		}
		
		// Allocate URB.  It will be reused for the data transfer, so insure
		// it is large enough for both control and bulk transfers
		UrbSize = sizeof (struct _URB_BULK_OR_INTERRUPT_TRANSFER);

		Urb = NULL;
		Urb = ExAllocatePool(NonPagedPool, UrbSize);

		if (!Urb) {
			DbgPrint("Failure due to memory error -- Allocate Urb for WRITE_REQUEST\n");
			ntStatus = STATUS_INSUFFICIENT_RESOURCES;
			
			goto ErrorProcess;
		}
		
		// Store all the transfer request info in our device extension
		deviceExtension->PollingUrb = Urb;
		deviceExtension->PollingIrp = Irp;
		deviceExtension->pollpending = FALSE;
    } else {
		goto ErrorCreate;
    }

    //USBD_GetUSBDIVersion(&versionInformation);

ErrorProcess:

    if( NT_SUCCESS( ntStatus ) )
    {
        NTSTATUS actStat;
        // try to power down device until IO actually requested
        actStat = UsbCom_SelfSuspendOrActivate( deviceObject, TRUE );

        deviceObject->Flags &= ~DO_DEVICE_INITIALIZING;
    }
	else {

		// Error allocating memory.
		if(deviceExtension->ReadingUrb)
			ExFreePool(deviceExtension->ReadingUrb);
		
		if(deviceExtension->ReadingIrp)
			IoFreeIrp(deviceExtension->ReadingIrp);

		if(deviceExtension->WritingUrb)
			ExFreePool(deviceExtension->ReadingUrb);
		
		if(deviceExtension->WritingIrp)
			IoFreeIrp(deviceExtension->ReadingIrp);

		if(deviceExtension->PollingUrb)
			ExFreePool(deviceExtension->PollingUrb);
		
		if(deviceExtension->PollingIrp)
			IoFreeIrp(deviceExtension->PollingIrp);

	}

ErrorCreate :

    DbgPrint("exit UsbCom_PnPAddDevice() (%x)\n", ntStatus);

    return ntStatus;
}


NTSTATUS
UsbCom_StartDevice(
    IN  PDEVICE_OBJECT DeviceObject
    )
/*++

Routine Description:

    Called from UsbCom_ProcessPnPIrp(), the dispatch routine for IRP_MJ_PNP.
    Initializes a given instance of the device on the USB.
    USB client drivers such as us set up URBs (USB Request Packets) to send requests
    to the host controller driver (HCD). The URB structure defines a format for all
    possible commands that can be sent to a USB device.
    Here, we request the device descriptor and store it, and configure the device.


Arguments:

    DeviceObject - pointer to the FDO (Functional Device Object)

Return Value:

    NT status code

--*/
{
    PDEVICE_EXTENSION deviceExtension;
    NTSTATUS ntStatus;
    PUSB_DEVICE_DESCRIPTOR deviceDescriptor = NULL;
    PURB urb;
    ULONG siz;

    DbgPrint("enter UsbCom_StartDevice\n");

    deviceExtension = DeviceObject->DeviceExtension;

    urb = ExAllocatePool(NonPagedPool,
                         sizeof(struct _URB_CONTROL_DESCRIPTOR_REQUEST));

    if (urb) {

		DbgPrint("UsbCom_StartDevice() SUCCESS ExAllocatePool() for URB_CONTROL_DESCRIPTOR_REQUEST");
        siz = sizeof(USB_DEVICE_DESCRIPTOR);

        deviceDescriptor = ExAllocatePool(NonPagedPool,
                                          siz);

        if (deviceDescriptor) {

        DbgPrint("UsbCom_StartDevice() SUCESS ExAllocatePool() for deviceDescriptor\n");

            UsbBuildGetDescriptorRequest(urb,
                                         (USHORT) sizeof (struct _URB_CONTROL_DESCRIPTOR_REQUEST),
                                         USB_DEVICE_DESCRIPTOR_TYPE,
                                         0,
                                         0,
                                         deviceDescriptor,
                                         NULL,
                                         siz,
                                         NULL);


            ntStatus = UsbCom_CallUSBD(DeviceObject, urb);

            if (NT_SUCCESS(ntStatus)) {
                DbgPrint("Device Descriptor = %x, len 0x%x\n",
                                deviceDescriptor,
                                urb->UrbControlDescriptorRequest.TransferBufferLength);

                DbgPrint("I82930 Device Descriptor:\n");
                DbgPrint("-------------------------\n");
                DbgPrint("bLength %d\n", deviceDescriptor->bLength);
                DbgPrint("bDescriptorType 0x%x\n", deviceDescriptor->bDescriptorType);
                DbgPrint("bcdUSB 0x%x\n", deviceDescriptor->bcdUSB);
                DbgPrint("bDeviceClass 0x%x\n", deviceDescriptor->bDeviceClass);
                DbgPrint("bDeviceSubClass 0x%x\n", deviceDescriptor->bDeviceSubClass);
                DbgPrint("bDeviceProtocol 0x%x\n", deviceDescriptor->bDeviceProtocol);
                DbgPrint("bMaxPacketSize0 0x%x\n", deviceDescriptor->bMaxPacketSize0);
                DbgPrint("idVendor 0x%x\n", deviceDescriptor->idVendor);
                DbgPrint("idProduct 0x%x\n", deviceDescriptor->idProduct);
                DbgPrint("bcdDevice 0x%x\n", deviceDescriptor->bcdDevice);
                DbgPrint("iManufacturer 0x%x\n", deviceDescriptor->iManufacturer);
                DbgPrint("iProduct 0x%x\n", deviceDescriptor->iProduct);
                DbgPrint("iSerialNumber 0x%x\n", deviceDescriptor->iSerialNumber);
                DbgPrint("bNumConfigurations 0x%x\n", deviceDescriptor->bNumConfigurations);
            }
        } else {
                        // if we got here we failed to allocate deviceDescriptor
            ntStatus = STATUS_INSUFFICIENT_RESOURCES;
        }

        if (NT_SUCCESS(ntStatus)) {
            deviceExtension->UsbDeviceDescriptor = deviceDescriptor;
        } else if (deviceDescriptor) {
            ExFreePool(deviceDescriptor);
        }

        ExFreePool(urb);

    } else {
                // if we got here we failed to allocate the urb
        ntStatus = STATUS_INSUFFICIENT_RESOURCES;
    }

    if (NT_SUCCESS(ntStatus)) {
        ntStatus = UsbCom_ConfigureDevice(DeviceObject);
    }


    if (NT_SUCCESS(ntStatus)) {
        deviceExtension->DeviceStarted = TRUE;
    }


   //
   // Set up the default device control fields.
   // Note that if the values are changed after
   // the file is open, they do NOT revert back
   // to the old value at file close.
   //

   deviceExtension->SpecialChars.XonChar      = SERIAL_DEF_XON;
   deviceExtension->SpecialChars.XoffChar     = SERIAL_DEF_XOFF;
   deviceExtension->HandFlow.ControlHandShake = SERIAL_DTR_CONTROL;
   deviceExtension->HandFlow.FlowReplace      = SERIAL_RTS_CONTROL;


   //
   // Default Line control protocol. 7E1
   //
   // Seven data bits.
   // Even parity.
   // 1 Stop bits.
   //

   deviceExtension->LineControl = SERIAL_7_DATA |
                               SERIAL_EVEN_PARITY |
                               SERIAL_NONE_PARITY;

   deviceExtension->ValidDataMask = 0x7f;
   deviceExtension->CurrentBaud   = 1200;


   //
   // We set up the default xon/xoff limits.
   //
   // This may be a bogus value.  It looks like the BufferSize
   // is not set up until the device is actually opened.
   //

   deviceExtension->HandFlow.XoffLimit    = deviceExtension->BufferSize >> 3;
   deviceExtension->HandFlow.XonLimit     = deviceExtension->BufferSize >> 1;

   deviceExtension->BufferSizePt8 = ((3*(deviceExtension->BufferSize>>2))+
                                  (deviceExtension->BufferSize>>4));

   SerialDump(
             SERDIAG1,
             ("SERIAL: The default interrupt read buffer size is: %d\n"
              "------  The XoffLimit is                         : %d\n"
              "------  The XonLimit is                          : %d\n"
              "------  The pt 8 size is                         : %d\n",
              deviceExtension->BufferSize,
              deviceExtension->HandFlow.XoffLimit,
              deviceExtension->HandFlow.XonLimit,
              deviceExtension->BufferSizePt8)
             );

   //
   // Go through all the "named" baud rates to find out which ones
   // can be supported with this port.
   //

   deviceExtension->SupportedBauds = SERIAL_BAUD_USER;

		deviceExtension->SupportedBauds =	SERIAL_BAUD_110 |
											SERIAL_BAUD_300 |
											SERIAL_BAUD_1200 |
											SERIAL_BAUD_2400 |
											SERIAL_BAUD_4800 |
											SERIAL_BAUD_9600 |
											SERIAL_BAUD_19200 |
											SERIAL_BAUD_38400 |
											SERIAL_BAUD_57600 |
											SERIAL_BAUD_115200;

   //
   // Mark this device as not being opened by anyone.  We keep a
   // variable around so that spurious interrupts are easily
   // dismissed by the ISR.
   //

   deviceExtension->DeviceIsOpened = FALSE;

   //
   // Store values into the extension for interval timing.
   //

   //
   // If the interval timer is less than a second then come
   // in with a short "polling" loop.
   //
   // For large (> then 2 seconds) use a 1 second poller.
   //

   deviceExtension->ShortIntervalAmount.QuadPart  = -1;
   deviceExtension->LongIntervalAmount.QuadPart   = -10000000;
   deviceExtension->CutOverAmount.QuadPart        = 200000000;


	StartInterruptUrb(deviceExtension);	// henry
	StartReadUrb(deviceExtension);	// henry

	deviceExtension->HoldingEmpty = TRUE;	//henry

//done:

    DbgPrint("exit UsbCom_StartDevice (%x)\n", ntStatus);

    return ntStatus;
}


NTSTATUS
UsbCom_RemoveDevice(
    IN  PDEVICE_OBJECT DeviceObject
    )
/*++

Routine Description:

        Called from UsbCom_ProcessPnPIrp() to
    clean up our device instance's allocated buffers; free symbolic links

Arguments:

    DeviceObject - pointer to the FDO

Return Value:

    NT status code from free symbolic link operation

--*/
{
    PDEVICE_EXTENSION deviceExtension;
    NTSTATUS ntStatus = STATUS_SUCCESS;
    UNICODE_STRING deviceLinkUnicodeString;

    DbgPrint("enter UsbCom_RemoveDevice\n");

    deviceExtension = DeviceObject->DeviceExtension;

    RtlInitUnicodeString (&deviceLinkUnicodeString,
                          deviceExtension->DeviceLinkNameBuffer);

    // remove the GUID-based symbolic link
    ntStatus = IoSetDeviceInterfaceState(&deviceLinkUnicodeString, FALSE);
    ASSERT( NT_SUCCESS( ntStatus ) );

	if(deviceExtension->ReadingUrb)
		ExFreePool(deviceExtension->ReadingUrb);
	
	if(deviceExtension->ReadingIrp)
		IoFreeIrp(deviceExtension->ReadingIrp);

	if(deviceExtension->WritingUrb)
		ExFreePool(deviceExtension->WritingUrb);
	
	if(deviceExtension->WritingIrp)
		IoFreeIrp(deviceExtension->WritingIrp);

	if(deviceExtension->PollingUrb)
		ExFreePool(deviceExtension->PollingUrb);
	
	if(deviceExtension->PollingIrp)
		IoFreeIrp(deviceExtension->PollingIrp);

	if (deviceExtension->WorkItem != NULL) {
		IoFreeWorkItem(deviceExtension->WorkItem);
	}

    //
    // Free device descriptor structure
    //

    if (deviceExtension->UsbDeviceDescriptor) {
        ExFreePool(deviceExtension->UsbDeviceDescriptor);
        deviceExtension->UsbDeviceDescriptor = NULL;
    }

    //
    // Free pipe info structs
    //
    if( deviceExtension->PipeInfo ) {

        ExFreePool( deviceExtension->PipeInfo );
        deviceExtension->PipeInfo = NULL;
    }


    //
    // Free up the UsbInterface structure
    //
    if (deviceExtension->UsbInterface) {
        ExFreePool(deviceExtension->UsbInterface);
        deviceExtension->UsbInterface = NULL;
    }

        // free up the USB config discriptor
    if (deviceExtension->UsbConfigurationDescriptor) {
        ExFreePool(deviceExtension->UsbConfigurationDescriptor);
        deviceExtension->UsbConfigurationDescriptor = NULL;
    }


    // free the pending irp list
    if ( deviceExtension->PendingIoIrps ) {
        ExFreePool(deviceExtension->PendingIoIrps );
        deviceExtension->PendingIoIrps = NULL;
    }

    DbgPrint("exit UsbCom_RemoveDevice() \n");

    DbgPrint("exit UsbCom_RemoveDevice() status = 0x%x\n", ntStatus );

    return ntStatus;
}




NTSTATUS
UsbCom_StopDevice(
    IN  PDEVICE_OBJECT DeviceObject
    )
/*++

Routine Description:

    Stops a given instance of a 82930 device on the USB.
    We basically just tell USB this device is now 'unconfigured'

Arguments:

    DeviceObject - pointer to the device object for this instance of a 82930

Return Value:

    NT status code

--*/
{
    PDEVICE_EXTENSION deviceExtension;
    NTSTATUS ntStatus = STATUS_SUCCESS;
    PURB urb;
    ULONG siz;

    DbgPrint("enter UsbCom_StopDevice\n");

    deviceExtension = DeviceObject->DeviceExtension;

    //
    // Send the select configuration urb with a NULL pointer for the configuration
    // handle. This closes the configuration and puts the device in the 'unconfigured'
    // state.
    //

    siz = sizeof(struct _URB_SELECT_CONFIGURATION);

    urb = ExAllocatePool(NonPagedPool,
                         siz);

    if (urb) {
        UsbBuildSelectConfigurationRequest(urb,
                                          (USHORT) siz,
                                          NULL);

        ntStatus = UsbCom_CallUSBD(DeviceObject, urb);
		DbgPrint("Close the configuration, status -- %d", ntStatus);
        ExFreePool(urb);
    } else {
        ntStatus = STATUS_INSUFFICIENT_RESOURCES;
    }


    if (NT_SUCCESS(ntStatus)) {
        deviceExtension->DeviceStarted = FALSE;
    }

    deviceExtension->StopDeviceRequested = FALSE;

    DbgPrint("exit UsbCom_StopDevice() (%x)\n", ntStatus);

    return ntStatus;
}



NTSTATUS
UsbCom_IrpCompletionRoutine(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp,
    IN PVOID Context
    )
/*++

Routine Description:

    Used as a  general purpose completion routine so it can signal an event,
    passed as the Context, when the next lower driver is done with the input Irp.
        This routine is used by both PnP and Power Management logic.

    Even though this routine does nothing but set an event, it must be defined and
    prototyped as a completetion routine for use as such


Arguments:

    DeviceObject - Pointer to the device object for the class device.

    Irp - Irp completed.

    Context - Driver defined context, in this case a pointer to an event.

Return Value:

    The function value is the final status from the operation.

--*/
{
    PKEVENT event = Context;

    // Set the input event
    KeSetEvent(event,
               1,       // Priority increment  for waiting thread.
               FALSE);  // Flag this call is not immediately followed by wait.

    // This routine must return STATUS_MORE_PROCESSING_REQUIRED because we have not yet called
    // IoFreeIrp() on this IRP.
    return STATUS_MORE_PROCESSING_REQUIRED;

}



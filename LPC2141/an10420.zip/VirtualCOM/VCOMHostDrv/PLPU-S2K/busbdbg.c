/*++

Copyright (c) 1997-1998  Microsoft Corporation

Module Name:

    BusbDbg.c 

Abstract:

    Debug output logic .
	This entire module is a noop in the free build

Environment:

    kernel mode only

Notes:

  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
  PURPOSE.

  Copyright (c) 1997-1998 Microsoft Corporation.  All Rights Reserved.


Revision History:

    1/27/98: created

--*/


#if DBG


#include "wdm.h"
#include "stdarg.h"
#include "stdio.h"

#include "usbdi.h"
#include "usbdlib.h"
#include "usbcom.h"


IOCTLDESCBLOCK IoctlDescBlock[] =
{
	
{   IOCTL_SERIAL_SET_BAUD_RATE,     "IOCTL_SERIAL_SET_BAUD_RATE"           	}, 
{   IOCTL_SERIAL_SET_QUEUE_SIZE,    "IOCTL_SERIAL_SET_QUEUE_SIZE"          	}, 
{   IOCTL_SERIAL_SET_LINE_CONTROL,  "IOCTL_SERIAL_SET_LINE_CONTROL"        	}, 
{   IOCTL_SERIAL_SET_BREAK_ON,      "IOCTL_SERIAL_SET_BREAK_ON"            	}, 
{   IOCTL_SERIAL_SET_BREAK_OFF,     "IOCTL_SERIAL_SET_BREAK_OFF"           	}, 
{   IOCTL_SERIAL_IMMEDIATE_CHAR,    "IOCTL_SERIAL_IMMEDIATE_CHAR"          	}, 
{   IOCTL_SERIAL_SET_TIMEOUTS,      "IOCTL_SERIAL_SET_TIMEOUTS"            	}, 
{   IOCTL_SERIAL_GET_TIMEOUTS,      "IOCTL_SERIAL_GET_TIMEOUTS"            	}, 
{   IOCTL_SERIAL_SET_DTR,           "IOCTL_SERIAL_SET_DTR"                 	}, 
{   IOCTL_SERIAL_CLR_DTR,           "IOCTL_SERIAL_CLR_DTR"                 	}, 
{   IOCTL_SERIAL_RESET_DEVICE,      "IOCTL_SERIAL_RESET_DEVICE"            	}, 
{   IOCTL_SERIAL_SET_RTS,           "IOCTL_SERIAL_SET_RTS"                 	}, 
{   IOCTL_SERIAL_CLR_RTS,           "IOCTL_SERIAL_CLR_RTS"                 	}, 
{   IOCTL_SERIAL_SET_XOFF,          "IOCTL_SERIAL_SET_XOFF"                	}, 
{   IOCTL_SERIAL_SET_XON,           "IOCTL_SERIAL_SET_XON"                 	}, 
{   IOCTL_SERIAL_GET_WAIT_MASK,     "IOCTL_SERIAL_GET_WAIT_MASK"           	}, 
{   IOCTL_SERIAL_SET_WAIT_MASK,     "IOCTL_SERIAL_SET_WAIT_MASK"            }, 
{   IOCTL_SERIAL_WAIT_ON_MASK,      "IOCTL_SERIAL_WAIT_ON_MASK"            	}, 
{   IOCTL_SERIAL_PURGE,             "IOCTL_SERIAL_PURGE"                   	}, 
{   IOCTL_SERIAL_GET_BAUD_RATE,     "IOCTL_SERIAL_GET_BAUD_RATE"           	}, 
{   IOCTL_SERIAL_GET_LINE_CONTROL,  "IOCTL_SERIAL_GET_LINE_CONTROL"        	}, 
{   IOCTL_SERIAL_GET_CHARS,         "IOCTL_SERIAL_GET_CHARS"               	}, 
{   IOCTL_SERIAL_SET_CHARS,         "IOCTL_SERIAL_SET_CHARS"               	}, 
{   IOCTL_SERIAL_GET_HANDFLOW,      "IOCTL_SERIAL_GET_HANDFLOW"            	}, 
{   IOCTL_SERIAL_SET_HANDFLOW,      "IOCTL_SERIAL_SET_HANDFLOW"            	}, 
{   IOCTL_SERIAL_GET_MODEMSTATUS,   "IOCTL_SERIAL_GET_MODEMSTATUS"         	}, 
{   IOCTL_SERIAL_GET_COMMSTATUS,    "IOCTL_SERIAL_GET_COMMSTATUS"          	}, 
{   IOCTL_SERIAL_XOFF_COUNTER,      "IOCTL_SERIAL_XOFF_COUNTER"            	}, 
{   IOCTL_SERIAL_GET_PROPERTIES,    "IOCTL_SERIAL_GET_PROPERTIES"          	}, 
{   IOCTL_SERIAL_GET_DTRRTS,        "IOCTL_SERIAL_GET_DTRRTS"               }, 
{   IOCTL_SERIAL_CONFIG_SIZE,       "IOCTL_SERIAL_CONFIG_SIZE"              }, 
{   IOCTL_SERIAL_GET_STATS,         "IOCTL_SERIAL_GET_STATS"                }, 
{   IOCTL_SERIAL_CLEAR_STATS,       "IOCTL_SERIAL_CLEAR_STATS"              }, 
{   IOCTL_SERIAL_GET_MODEM_CONTROL, "IOCTL_SERIAL_GET_MODEM_CONTROL"        }, 
{   IOCTL_SERIAL_SET_MODEM_CONTROL, "IOCTL_SERIAL_SET_MODEM_CONTROL"        }, 
{   IOCTL_SERIAL_SET_FIFO_CONTROL,  "IOCTL_SERIAL_SET_FIFO_CONTROL"         }, 
{   IOCTL_SERIAL_LSRMST_INSERT,     "IOCTL_SERIAL_LSRMST_INSERT"            }, 
{   0,                              "Code Unknown"                          }, 

};






// begin, data/code  used only in DBG build

//  may be overridden  in registry in DBG buils only
// higher == more verbose, default is 1, 0 turns off all
int gDebugLevel = DBGLVL_DEFAULT ; 

// count outstanding allocations via ExAllocatePool
int gExAllocCount =0;

UsbCom_DBGDATA gDbgBuf = { 0, 0, 0, 0 }; 

// ptr to global debug data struct; txt buffer is only allocated in DBG builds
PUsbCom_DBGDATA gpDbg = &gDbgBuf; 




BOOLEAN
UsbCom_GetRegistryDword(
    IN      PWCHAR    RegPath,
    IN      PWCHAR    ValueName,
    IN OUT  PULONG    Value
    )

/*++

Routine Description:

	Obtain a Dword value from the registry


Arguments:

    RegPath  -- supplies absolute registry path
    ValueName    - Supplies the Value Name.
    Value      - receives the REG_DWORD value.

Return Value:

    TRUE if successfull, FALSE on fail.

--*/

{
    UNICODE_STRING path;
    RTL_QUERY_REGISTRY_TABLE paramTable[2];  //zero'd second table terminates parms
    ULONG lDef = *Value;                     // default
    NTSTATUS status;
    BOOLEAN fres;
	WCHAR wbuf[ MAXIMUM_FILENAME_LENGTH ];

    UsbCom_KdPrint( DBGLVL_HIGH,("Enter UsbCom_GetRegistryDword() RegPath = %ws\n   ValueName =%ws\n", RegPath, ValueName));
    path.Length = 0;
    path.MaximumLength = MAXIMUM_FILENAME_LENGTH * sizeof( WCHAR );  // MAXIMUM_FILENAME_LENGTH defined in wdm.h
    path.Buffer = wbuf;


    RtlZeroMemory(path.Buffer, path.MaximumLength);
    RtlMoveMemory(path.Buffer, RegPath, wcslen( RegPath) * sizeof( WCHAR ));

    UsbCom_KdPrint( DBGLVL_HIGH,("UsbCom_GetRegistryDword() path= %ws\n", path.Buffer ));

    RtlZeroMemory(paramTable, sizeof(paramTable));

    paramTable[0].Flags = RTL_QUERY_REGISTRY_DIRECT;

    paramTable[0].Name = ValueName;

    paramTable[0].EntryContext = Value;
    paramTable[0].DefaultType = REG_DWORD;
    paramTable[0].DefaultData = &lDef;
    paramTable[0].DefaultLength = sizeof(ULONG);


    status = RtlQueryRegistryValues( RTL_REGISTRY_ABSOLUTE | RTL_REGISTRY_OPTIONAL,
                                    path.Buffer, paramTable, NULL, NULL);

    if (NT_SUCCESS(status)) {
        UsbCom_KdPrint( DBGLVL_MEDIUM,("Exit UsbCom_GetRegistryDWord() SUCCESS, value = decimal %d 0x%x\n", *Value, *Value));
        fres = TRUE;

    } else {

        UsbCom_KdPrintCond( DBGLVL_MEDIUM, (status == STATUS_INVALID_PARAMETER) ,("UsbCom_GetRegistryDWord() STATUS_INVALID_PARAMETER\n"));
 
		UsbCom_KdPrintCond( DBGLVL_MEDIUM, (status == STATUS_OBJECT_NAME_NOT_FOUND) ,("UsbCom_GetRegistryDWord() STATUS_OBJECT_NAME_NOT_FOUND\n"));

        fres = FALSE;

    }

    return fres;
}

PVOID 
    UsbCom_ExAllocatePool(
        IN POOL_TYPE PoolType,
        IN ULONG NumberOfBytes
        )
{
	gExAllocCount++;
    UsbCom_KdPrint( DBGLVL_HIGH,("UsbCom_ExAllocatePool() gExAllocCount = dec %d\n", gExAllocCount ));
	return ExAllocatePool(  PoolType, NumberOfBytes );

}


VOID 
    UsbCom_ExFreePool(
        IN PVOID p
        )
{
	gExAllocCount--;
    UsbCom_KdPrint( DBGLVL_HIGH,("UsbCom_ExFreePool() gExAllocCount = dec %d\n", gExAllocCount ));
	ExFreePool(  p );

}

char * UsbCom_StringForIoCtrl( int IoCtrlCode ) 
{
  
  int i = 0;
  int size = sizeof(IoctlDescBlock)/sizeof(IOCTLDESCBLOCK);
  for(i = 0; i < size -1 ; i++)
	{
	  if(IoCtrlCode == IoctlDescBlock[i].ioctlCode)
		return 	IoctlDescBlock[i].ioctlCodeString;
	}
  return IoctlDescBlock[size].ioctlCodeString;
}


#endif // end , if DBG



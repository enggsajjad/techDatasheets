/*----------------------------------------------------------------------------
 *      U S B  -  K e r n e l
 *----------------------------------------------------------------------------
 *      Name:    DEMO.h
 *      Purpose: USB Virtual COM demo definiton file for Philips LPC214x
 *      Version: V1.04
 *----------------------------------------------------------------------------
 *      This software is supplied "AS IS" without any warranties, express, 
 *      implied or statutory, including but not limited to the implied 
 *      warranties of fitness for purpose, satisfactory quality and 
 *      noninfringement. Keil extends you a royalty-free right to reproduce and
 *      distribute executable files created using this software for use on 
 *      Philips LPC2xxx microcontroller devices only. Nothing else gives you the 
 *      right to use this software. 
 *
 *      Copyright (c) 2005 Keil Software.
 *		Modified by Philips Semiconductor
 *---------------------------------------------------------------------------*/
/* Push Button Definitions */
#define S2     0x00004000  /* P0.14 */
#ifndef MCB2140
  #define S3     0x00010000  /* P0.16 */
  #define S4     0x00400000  /* P0.22 */
#endif

/* LED Definitions */
#define LED1   0x00010000  /* P1.16 */
#define LED2   0x00020000  /* P1.17 */
#define LED3   0x00040000  /* P1.18 */
#define LED4   0x00080000  /* P1.19 */
#define LED5   0x00100000  /* P1.20 */
#define LED6   0x00200000  /* P1.21 */
#define LED7   0x00400000  /* P1.22 */
#define LED8   0x00800000  /* P1.23 */



/*----------------------------------------------------------------------------
 *      U S B  -  K e r n e l
 *----------------------------------------------------------------------------
 *      Name:    DEMO.C
 *      Purpose: Main C entry file for Philips LPC214x
 *      Version: V1.04
 *----------------------------------------------------------------------------
 *      This software is supplied "AS IS" without any warranties, express, 
 *      implied or statutory, including but not limited to the implied 
 *      warranties of fitness for purpose, satisfactory quality and 
 *      noninfringement. Keil extends you a royalty-free right to reproduce and
 *      distribute executable files created using this software for use on 
 *      Philips LPC2xxx microcontroller devices only. Nothing else gives you the 
 *      right to use this software. 
 *
 *      Copyright (c) 2005 Keil Software.
 *		Modified by Philips Semiconductor
 *---------------------------------------------------------------------------*/
#include <LPC214x.h>                        /* LPC214x definitions */

#include "type.h"
#include "usb.h"
#include "usbcfg.h"
#include "usbhw.h"
#include "usbcore.h"
#include "vcomuser.h"
#include "demo.h"

extern BYTE ReportStatus0, ReportStatus1;
extern BYTE Data2Host0, Data2Host1;

BYTE Modem0Status, Modem1Status;

/* Main Program */
int main (void) {

  BYTE i = 0;

  IODIR1 = LED1 | LED2 | LED3 |             /* LED1, LED5..8 are Outputs */
           LED4 | LED5 | LED6 |
		   LED7 | LED8;
  
  init_serial();
  USB_Init();                               /* USB Initialization */
  USB_Connect(TRUE);                        /* USB Connect */

  while (1)                                /* Loop forever */
  {
#if USB_VCOM
	if ( Data2Host0 || Data2Host1 ) {
		DeviceData2Host( 0 );
		DeviceData2Host( 1 );
	}
#if 0
	/* EP3 is used to report UART0 status, and EP9
	is used to report UART1 status respectively */
	if ( ReportStatus0 ) {
		ReportStatus0 = 0;
		/* For Interrupt IN on EP3 */
		USB_WriteEP( 3 | 0x80, &Modem0Status, sizeof(Modem0Status) );
	}
	if ( ReportStatus1 ) {
		ReportStatus1 = 0;
		/* For Interrupt IN on EP9 */
		USB_WriteEP( 9 | 0x80, &Modem1Status, sizeof(Modem1Status) );
	}
#endif
#endif
  }											   
}

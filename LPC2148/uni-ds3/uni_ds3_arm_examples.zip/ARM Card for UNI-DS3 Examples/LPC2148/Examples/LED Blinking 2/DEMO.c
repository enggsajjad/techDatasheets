/*
 * Project name:
     DEMO (Simple LED demonstration)
 * Copyright:
     (c) mikroElektronika, 2007.
 * Description:

 * Test configuration:
     MCU:             LPC2148
     Dev.Board:       UNI-DS3 with LPC2148 ARM Card
     Oscillator:      12.0 MHz (cclk = 60.0 MHz, Fcco = 240.0 MHz)
     Ext. Modules:    LCD 2x16 characters
     SW:              KEIL uVision3 v3.50
 * MCU CARD NOTES:
     - Place jumpers J1 to J7 in left position to disable JTAG.
     - Remove jumper J10 (or place in neutral position)
     - Remove jumpers J8 & J9 (or place in neutral position)
 * BOARD NOTES:
     - Place 100Kohm pull-up resistor networks RN1 to R9
     - Turn on PORTA to PORTF LED diodes located on SW1 DIP switch.
*/


#include <LPC214X.H>

#include "Utility.h"



int main (void)
{
	PINSEL0 = 0;
	PINSEL1 = 0;
	PINSEL2 &= 0x0000000C;


	IODIR0 = 0xFFFFFFFF;					// P0.0 - P0.31 defined as Outputs
	IODIR1 = 0xFFFFFFFF;					// P1.0 - P1.31 defined as Outputs

	while (1)
	{
		IOSET0 = 0xFFFFFFFF;
		IOSET1 = 0xFFFFFFFF;
		delay_Nx10cyc(1499999);			// Delay 250ms

		IOCLR0 = 0xFFFFFFFF;
		IOCLR1 = 0xFFFFFFFF;
		delay_Nx10cyc(1499999);			// Delay 250ms
	}
}

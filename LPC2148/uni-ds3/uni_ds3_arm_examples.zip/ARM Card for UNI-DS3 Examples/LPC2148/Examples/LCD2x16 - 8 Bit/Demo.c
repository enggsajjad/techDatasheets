/*
 * Project name:
     DEMO (Simple demonstration of the 8-bit mode LCD Library functions)
 * Copyright:
     (c) mikroElektronika, 2007.
 * Description:
     This is a simple demonstration of LCD library functions. LCD is first
     initialized (8-bit data interface), then some text is written
     at the first row.
 * Test configuration:
     MCU:             LPC2148
     Dev.Board:       UNI-DS3 with LPC2148 ARM Card
     Oscillator:      12.0 MHz (cclk = 60.0 MHz, Fcco = 240.0 MHz)
     Ext. Modules:    LCD 2x16 characters
     SW:              KEIL uVision3 v3.50
 * MCU CARD NOTES:
     - Place jumpers J1 to J7 in left position to disable JTAG.
     - Remove jumper J10 (or place in neutral position)
     - Remove jumpers J8 & J9 (or place in neutral position)
 * BOARD NOTES:
     - Place 100Kohm pull-up resistor networks RN1 to R9
     - Place LCD in 8-bit mode position (GLCD position).
     - Move jumper J16 in up position for LCD Contrast control.
     - Adjust GLCD contrast with P2.
*/


#include <LPC214X.H>

#include "LCD8.h"
#include "Utility.h"


const unsigned char LCD_Message[16] = {"mikroElektronika"};

int main (void)
{
	PINSEL0 = 0;
	PINSEL1 = 0;
	PINSEL2 &= 0x0000000C;

	LCD8_init (&IOPIN0/*CTRL Port*/, &IOPIN1/*DATA Port*/, 19/*RS*/, 20/*RW*/, 21/*E*/, 16/*D0*/);

	LCD8_sendstr (0,0, LCD_Message);
	LCD8_sendstr (0,1, "Hello !!!");

	while (1);
}

/*
 * Project name:
     DEMO (Demonstration of the GLCD library routines)
 * Copyright
     (c) mikroElektronika, 2007.
 * Description:
      This is a simple demonstration of the GLCD library routines:
     - Init and Clear (pattern fill)
     - Image display
 * Test configuration:
     MCU:             LPC2148
     Dev.Board:       UNI-DS3 with LPC2148 ARM Card
     Oscillator:      12.0 MHz (cclk = 60.0 MHz, Fcco = 240.0 MHz)
     Ext. Modules:    GLCD 128x64 dots
     SW:              KEIL uVision3 v3.50
 * MCU CARD NOTES:
     - Place jumpers J1 to J7 in left position to disable JTAG.
     - Remove jumper J10 (or place in neutral position)
     - Remove jumpers J8 & J9 (or place in neutral position)
 * BOARD NOTES:
     - Place 100Kohm pull-up resistor networks RN1 to R9
     - Place GLCD in position.
     - Move jumper J16 in down position for GLCD Contrast control.
     - Adjust GLCD contrast with P1.
*/


#include <LPC214X.H>

#include "Glcd.h"
#include "bmp_maska.h"
#include "Utility.h"


unsigned char
	ii;

char
	*someText;




int main (void)
{
	PINSEL0 = 0;
	PINSEL1 = 0;
	PINSEL2 &= 0x0000000C;


	Glcd_Init(&IOPIN0,	// Control lines Port
						&IOPIN1,	// Data Lines Port
						17,				// CS1#
						18,				// CS2#
						19,				// RS
						20,				// R/W#
						22,				// RST
						21,				// EN
						16);			// D0 data line position


	while (1)
	{
		Glcd_Fill(0x00);

		Glcd_Image( maska_bmp );
		delay_Nx10cyc (11999999);				// Delay 2s

		Glcd_Fill(0x00);

		Glcd_Line(120,1, 5,60, 1);
		Glcd_Line(12,42, 5,60, 1);
		delay_Nx10cyc (5999999);				// Delay 1s

		Glcd_Rectangle(12,20, 93,57, 1);
		delay_Nx10cyc (5999999);				// Delay 1s

		Glcd_Line(120,12, 12,60, 1);
		delay_Nx10cyc (5999999);				// Delay 1s

		Glcd_H_Line(5,15, 6, 1);
		Glcd_Line(0,12, 120,60, 1);
		Glcd_V_Line(7,63, 127, 1);
		delay_Nx10cyc (5999999);				// Delay 1s

		for (ii = 1; ii <= 10; ii++)
			Glcd_Circle(63,32, 3*ii, 1);
		delay_Nx10cyc (5999999);				// Delay 1s

		Glcd_Box(12,20, 70,57, 2);
		delay_Nx10cyc (5999999);				// Delay 1s

		someText = "BIG:ONE";
		Glcd_Write_Text(someText, 5,3, 2);
		delay_Nx10cyc (5999999);				// Delay 1s

		someText = "SMALL:NOT:SMALLER";
		Glcd_Write_Text(someText, 20,5, 1);
		delay_Nx10cyc (5999999);				// Delay 1s
	}
}

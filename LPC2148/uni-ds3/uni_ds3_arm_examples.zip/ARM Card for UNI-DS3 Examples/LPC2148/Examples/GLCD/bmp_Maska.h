#ifndef __BMP_MASKA_H_
#define __BMP_MASKA_H_

extern const char maska_bmp[];

#endif

/*
 * Project name:
     DEMO (Simple usage of USART module library functions)
 * Copyright:
     (c) mikroElektronika, 2007.
 * Description:
     This code demonstrates how to use usart library routines.
 * Test configuration:
     MCU:             LPC2148
     Dev.Board:       UNI-DS3 with LPC2148 ARM Card
     Oscillator:      12.0 MHz (cclk = 60.0 MHz, Fcco = 240.0 MHz)
     Ext. Modules:    LCD 2x16 characters
     SW:              KEIL uVision3 v3.50
 * MCU CARD NOTES:
     - Place jumpers J1 to J7 in left position to disable JTAG.
     - Remove jumper J10 (or place in neutral position)
     - Remove jumpers J8 & J9 (or place in neutral position)
 * BOARD NOTES:
     - Place 100Kohm pull-up resistor networks RN1 to R9
     - Turn on TX232A located on SW3 DIP switch
     - Connect RS232 connector with PC.
     - Adjust COM port and speed from terminal.
*/


#include <LPC214X.H>

#include "Serial.h"
#include "Utility.h"


const unsigned char
	Message[18] = {"mikroElektronika\n"};

unsigned long
	dly,
	Brojac;

unsigned char
	HEXnum[9];



int main (void)
{
	PINSEL0 = 0;
	PINSEL1 = 0;
	PINSEL2 &= 0x0000000C;
	delay_Nx10cyc(599999);				// Delay 0,1s

	UART0_init(9600/*bps*/, 15000/*kHz*/, length_8_bit, stop_bit_1, parity_disable, parity_odd);

	UART0_sendstring ("Hello from,\n");
	UART0_sendstring (Message);

	Brojac = 0;
	while (1)
	{
		delay_Nx10cyc(2999999);				// Delay 500ms

		int2str (HEXnum, Brojac++);

		UART0_sendstring (HEXnum);
		UART0_sendstring ("\n");
	};
}

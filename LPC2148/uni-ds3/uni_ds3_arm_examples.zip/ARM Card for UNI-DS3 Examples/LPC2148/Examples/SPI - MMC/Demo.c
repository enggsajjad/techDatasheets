/*
 * Project name:
     DEMO (MMC Library Example)
 * Copyright:
     (c) mikroElektronika, 2007.
 * Description:
     MMC library test. This programme is designed to work in conjunction with
     the "MMC Card Terminal" Tool. Upon flashing, insert a MMC/SD card into the
     module, start the MMC Terminal, then reset the MCU, when you should receive
     the "Init-OK" message. Then, you can experiment with MMC read and write
     functions, and observe the results through the terminal Receive Panel window.
 * Test configuration:
     MCU:             LPC2148
     Dev.Board:       UNI-DS3 with LPC2148 ARM Card
     Oscillator:      12.0 MHz (cclk = 60.0 MHz, Fcco = 240.0 MHz)
     Ext. Modules:    LCD 2x16 characters
     SW:              KEIL uVision3 v3.50
 * MCU CARD NOTES:
     - Place jumpers J1 to J7 in left position to disable JTAG.
     - Remove jumper J10 (or place in neutral position)
     - Remove jumpers J8 & J9 (or place in neutral position)
 * BOARD NOTES:
     - Place 100Kohm pull-up resistor networks RN1 to R9
     - Place jumper J1 in pull-up position (located near PORTA IDC10 connector)
       (P0.7 must be at high level)
     - Turn on RX232A & TX232A located on SW3 DIP switch
     - Turn on MOSI, MISO & SCK located on SW4 DIP switch
     - Place jumpers J17,J18,J19 located near MMC socket
     - This is NOT an example for working with FILES on a MMC/SD memory module!
     - This example should work both for MMC and SD media types!
     - Connect RS232 connector with PC.
     - Adjust COM port and speed from terminal.
*/


#include <LPC214X.H>

#include "Mmc_Lib.h"
#include "Serial.h"
#include "Utility.h"



// universal variables
unsigned long
	i;

// Variables for MMC routines
unsigned char
	WRdata[512],
	RDdata[512],
	CIDdata[16],
	CSDdata[16];



int main (void)
{
	PINSEL0 = 0;
	PINSEL1 = 0;
	PINSEL2 &= 0x0000000C;
	delay_Nx10cyc(599999);			// Delay 0,1s

	UART0_init(38400/*bps*/, 15000/*kHz*/, length_8_bit, stop_bit_1, parity_disable, parity_odd);

	UART0_sendstring ("ARM Started.\n");

	//----------------------------------------------------------------------
	// Beffore all, we must initialise a MMC card
	//----------------------------------------------------------------------
	UART0_sendstring ("Init ");
	i = Mmc_Init(&IOPIN1, 25);
	if (i != 1)
	{
		// Error...
		UART0_sendstring ("Error.\n");
		while (1);
	}
	UART0_sendstring ("Ok.\n");

	//----------------------------------------------------------------------
	// Fill MMC buffer
	//----------------------------------------------------------------------
	for(i=0; i<=511; i++)
		WRdata[i] = 'E';

	//----------------------------------------------------------------------
	// Write sector
	//----------------------------------------------------------------------
	UART0_sendstring ("Write ");
	i = Mmc_Write_Sector(520+0, WRdata);
	if (i != 0)
	{
		// Error...
		UART0_sendstring ("Error.\n");
		while (1);
	}
	UART0_sendstring ("Ok.\n");

	//----------------------------------------------------------------------
	// Read same sector
	//----------------------------------------------------------------------
	UART0_sendstring ("Read ");
	i = Mmc_Read_Sector(520+0, RDdata);
	if (i != 0)
	{
		// Error...
		UART0_sendstring ("Error.\n");
		while (1);
	}
	UART0_sendstring ("Ok.\n");

	//----------------------------------------------------------------------
	// Compare data...
	//----------------------------------------------------------------------
	UART0_sendstring ("Compare ");
	for(i=0; i<=511; i++)
		if (WRdata[i] != RDdata[i])
		{
			// Error...
			UART0_sendstring ("Error.\n");
			while (1);
		}
	UART0_sendstring ("Success.\n");

	//----------------------------------------------------------------------
	// Read CID
	//----------------------------------------------------------------------
	if (Mmc_Read_Cid(CIDdata) == 0)
	{
		UART0_sendstring("=== MMC CID Data ===============================\n");
		for (i=0; i<=15; i++)
		{
			UART0_WriteNum(0, CIDdata[15-i]);
			if (i != 15)
				UART0_sendchar('-');
		}
		UART0_sendstring("\n");
		UART0_sendstring("================================================\n");
	}
	else
	{
		UART0_sendstring("=== MMC CID Data ===============================\n");
		UART0_sendstring("Error.\n");
		UART0_sendstring("================================================\n");
	}

	//----------------------------------------------------------------------
	// Read CSD
	//----------------------------------------------------------------------
	if (Mmc_Read_Csd(CSDdata) == 0)
	{
		UART0_sendstring("=== MMC CSD Data ===============================\n");
		for (i=0; i<=15; i++)
		{
			UART0_WriteNum(0, CSDdata[15-i]);
			if (i != 15)
				UART0_sendchar('-');
		}
		UART0_sendstring("\n");
		UART0_sendstring("================================================\n");
	}
	else
	{
		UART0_sendstring("=== MMC CSD Data ===============================\n");
		UART0_sendstring("Error.\n");
		UART0_sendstring("================================================\n");
	}


	while (1);
}

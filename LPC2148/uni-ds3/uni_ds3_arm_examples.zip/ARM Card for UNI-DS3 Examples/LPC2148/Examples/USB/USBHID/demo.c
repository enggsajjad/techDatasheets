/*----------------------------------------------------------------------------
 *      Name:    DEMO.C
 *      Purpose: USB HID Demo
 *      Version: V1.10
 *----------------------------------------------------------------------------
 *      This software is supplied "AS IS" without any warranties, express,
 *      implied or statutory, including but not limited to the implied
 *      warranties of fitness for purpose, satisfactory quality and
 *      noninfringement. Keil extends you a royalty-free right to reproduce
 *      and distribute executable files created using this software for use
 *      on Philips LPC2xxx microcontroller devices only. Nothing else gives
 *      you the right to use this software.
 *
 *      Copyright (c) 2005-2006 Keil Software.
 *---------------------------------------------------------------------------*/

/*
 * MCU CARD NOTES:
     - Place jumpers J1 to J7 in left position to disable JTAG.
     - Place jumper J10 in left position (VBUS)
     - Place jumper J8 & J9 in left position (P0.31 function as UP_LED)
 * BOARD NOTES:
     - Place 100Kohm pull-up resistor networks RN1 to R9
     - Turn on PORTE located on SW1 DIP switch (Output LEDs indication on PORTE)
     - Place jumper J10 in left position (connect buttons to VCC)
     - Place jumper J2 in pull-down position (Inputs - Button indication on PORTB)
*/




#include <LPC214X.H>

#include "type.h"
#include "usb.h"
#include "usbcfg.h"
#include "usbhw.h"
#include "usbcore.h"

#include "demo.h"


unsigned char
	InReport,			/* HID Input Report */
	OutReport;		/* HID Out Report */


//  Get HID Input Report -> InReport
void GetInReport (void)
{
	// Read PORT0[15..8]
	InReport = (IOPIN0 & 0x0000FF00) >> 8;
}

//  Set HID Output Report <- OutReport
void SetOutReport (void)
{
	// Write PORT1[23..16]
  IOPIN1 = ((IOPIN1 & ~0x00FF0000) | (OutReport << 16));
}



int main (void)
{
	PINSEL0 = 0;
	PINSEL1 = 0;
	PINSEL2 &= 0x0000000C;


  IODIR1 = 0x00FF0000;		// PORT1[23..16] LED's defined as Outputs

  USB_Init();							// USB Initialization
  USB_Connect(TRUE);			// USB Connect

  while (1);							// Loop forever
}

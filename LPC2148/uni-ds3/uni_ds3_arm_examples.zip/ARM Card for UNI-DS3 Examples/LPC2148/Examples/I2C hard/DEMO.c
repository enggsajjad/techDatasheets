/*
 * Project name:
     DEMO (Hardware I2C and PCF8583 Real time Clock Test)
 * Copyright:
     (c) mikroElektronika, 2007.
 * Description:
     This project is simple demonstration how to read date and time from PCF8583
     RTC (real-time clock). The code can be used with any MCU that has I2C
     interface at pins P0.2 & P0.3. Date and time are printed at LCD.
 * Test configuration:
     MCU:             LPC2148
     Dev.Board:       UNI-DS3 with LPC2148 ARM Card
     Oscillator:      12.0 MHz (cclk = 60.0 MHz, Fcco = 240.0 MHz)
     Ext. Modules:    LCD 2x16 characters
     SW:              KEIL uVision3 v3.50
 * MCU CARD NOTES:
     - Place jumpers J1 to J7 in left position to disable JTAG.
     - Remove jumper J10 (or place in neutral position)
     - Remove jumpers J8 & J9 (or place in neutral position)
 * BOARD NOTES:
     - Place 100Kohm pull-up resistor networks RN1 to R9
     - Place jumper J1 in pull-up position (located near PORTA IDC10 connector)
     - Turn on SDA & SCL located on SW4 DIP switch
     - Turn off PORTA LED diodes located on SW1 DIP switch !!!
     - Place LCD in 4-bit mode position.
     - Adjust LCD contrast with P2.
*/


#include <LPC214X.H>

#include "I2Chw.h"
#include "LCD4.h"
#include "Utility.h"


unsigned char 
	sec,
	mnt,
	hr,
	day,
	mn,
	year;

char
	*txt,
	data[32];



//--------------------- Reads time and date information from RTC (PCF8583)
void Read_Time(char *sec, char *mnt, char *hr, char *day, char *mn)
{
	data[0] = 0x02;
	I2C_Send (0xA0, data, 1);

	I2C_Read (0xA0, data, 5);
	*sec = data[0];
	*mnt = data[1];
	*hr  = data[2];
	*day = data[3];
	*mn  = data[4];
}//~

//--------------------- Write time and date information to RTC (PCF8583)
void Write_Time(char sec, char mnt, char hr, char day, char mn)
{
	data[0] = 0x00;			// start from word at address 0 (configuration word)
	data[1] = 0x80;			// write $80 to config. (pause counter...)
	data[2] = 0x00;			// write 0 to cents word
	data[3] = sec;			// write to seconds word
	data[4] = mnt;			// write to minutes word
	data[5] = hr;				// write to hours word
	data[6] = day;			// write to year/date word
	data[7] = mn;				// write to weekday/month
	I2C_Send (0xA0, data, 8);

	data[0] = 0x00;			// start from word at address 0
	data[1] = 0x00;			// write 0 to config word (enable counting)
	I2C_Send (0xA0, data, 2);
}//~





int main (void)
{

	PINSEL0 = 0;
	PINSEL1 = 0;
	PINSEL2 &= 0x0000000C;
	delay_Nx10cyc(499999);							// Delay 0,1s


	LCD4_init (&IOPIN1, 20/*D4*/, 16/*RS*/, 17/*E*/);
	I2C_Init ();

	// prepare and output static text on LCD
	txt = "Date:";
	LCD4_sendstr (0,0, txt);
	LCD4_sendstr (7,7, ':');
	LCD4_sendstr (10,0, ':');
	txt = "Time:";
	LCD4_sendstr (0,1, txt);
	LCD4_sendstr (7,1, ':');
	LCD4_sendstr (10,1, ':');
	txt = "20";
	LCD4_sendstr (11,0, txt);

	// Setup Date to 30.08.2006, and Time to 11:30:00
	Write_Time(0x00, 0x30, 0x11, 0xB0, 0x08);

	while (1)
	{
		// read time from RTC(PCF8583)
		Read_Time(&sec,&mnt,&hr,&day,&mn);

		// display Date and Time
		hex2str (data, sec, 2);						// seconds
		LCD4_sendstr (11,1, data);
		hex2str (data, mnt, 2);						// minutes
		LCD4_sendstr (8,1, data);
		hex2str (data, (hr & 0x3F), 2);		// hours
		LCD4_sendstr (5,1, data);
		hex2str (data, 4+(day >> 6), 2);	// year
		LCD4_sendstr (13,0, data);
		hex2str (data, (mn & 0x1F), 2);		// month
		LCD4_sendstr (8,0, data);
		hex2str (data, (day & 0x3F), 2);	// day
		LCD4_sendstr (5,0, data);

		// Delay 500ms
		delay_Nx10cyc (2999999);
	}
}

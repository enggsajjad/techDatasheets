/*
 * Project name:
     DEMO (Driving on-board MCP3204 Analog-to-Digital converter)
 * Copyright:
     (c) mikroElektronika, 2007.
 * Description:
     This is a sample program which demonstrates the use of the Microchip's
     MCP3204 12-bit A/D converter with ARM mcu's. This device accepts analog
     input and transforms it to the number from 0..4095, ranging from 0..Vref.
     The reference voltage on the ADC is selectable between 4.096V and 5.0V.
 * Test configuration:
     MCU:             LPC2148
     Dev.Board:       UNI-DS3 with LPC2148 ARM Card
     Oscillator:      12.0 MHz (cclk = 60.0 MHz, Fcco = 240.0 MHz)
     Ext. Modules:    LCD 2x16 characters
     SW:              KEIL uVision3 v3.50
 * MCU CARD NOTES:
     - Place jumpers J1 to J7 in left position to disable JTAG.
     - Remove jumper J10 (or place in neutral position)
     - Remove jumpers J8 & J9 (or place in neutral position)
 * BOARD NOTES:
     - Place 100Kohm pull-up resistor networks RN1 to R9
     - Turn on MOSI, MISO & SCK located on SW4 DIP switch
     - Turn on ADC-CS located on SW3 DIP switch
     - Adjust ADC voltage reference with J15 jumper (5V or 4.096V)
     - Place LCD in 4-bit mode position.
     - Adjust LCD contrast with P2.
*/


#include <LPC214X.H>

#include "SPIsw.h"
#include "LCD4.h"
#include "Utility.h"



const unsigned char
	LCD_Message[16] = {"mikroElektronika"};

unsigned char
	num[16],
	len;

unsigned long
	TXdata,
	RXdata;




int main (void)
{

	PINSEL0 = 0;
	PINSEL1 = 0;
	PINSEL2 &= 0x0000000C;


	LCD4_init (&IOPIN1, 20/*D4*/, 16/*RS*/, 17/*E*/);
	SPI_init (&IOPIN0, 25/*CS*/, 5/*MISO*/, 6/*MOSI*/, 4/*SCK*/, 0/*CPOL*/, 0/*CPHA*/);

	LCD4_sendstr (0,0, LCD_Message);

	while (1)
	{
		// Setup Configuration for MCP3204
		TXdata = 0x00030000;		// START=1, SGL/DIFF=1, D2=0, D1=0, D0=0
		RXdata = 0;

		SPI_enable ();
		RXdata |= SPI_char (TXdata >> 16);
		RXdata <<= 8;
		RXdata |= SPI_char (TXdata >> 8);
		RXdata <<= 8;
		RXdata |= SPI_char (TXdata);
		SPI_disable ();

		len = int2str (num, (RXdata & 0x00000FFF));
		while (len < 8)
			num[len++] = ' ';
		num[len] = 0;
		LCD4_sendstr (0,1, num);

		// Delay 100ms
		delay_Nx10cyc (599999);
	}
}

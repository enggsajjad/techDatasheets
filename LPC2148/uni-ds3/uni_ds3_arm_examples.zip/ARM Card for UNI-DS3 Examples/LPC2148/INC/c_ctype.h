#ifndef __C_CTYPE_H
#define __C_CTYPE_H


unsigned char islower(char character);
unsigned char isupper(char character);
unsigned char isalpha(char character);
unsigned char iscntrl(char character);
unsigned char isdigit(char character);
unsigned char isalnum(char character);
unsigned char isspace(char character);
unsigned char ispunct(char character);
unsigned char isgraph(char character);
unsigned char isxdigit(char character);
unsigned char tolower(char character);
unsigned char toupper(char character);


#endif

/*
 * Project name:
     Pcf_Read (Demonstration on Working with the RTC Module and Software I2C
               routines)
 * Copyright:
     (c) MikroElektronika, 2005.
 * Description:
      This project is simple demonstration how to read date and time from
      PCF8583 RTC (real-time clock). The code can be used with any MCU that has
      the Soft I2C library implemented.
      Date and time are read from the RTC every 1secs and printed at LCD.
 * Test configuration:
     MCU:             P18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    RTC, LCD
     SW:              mikroC v5.0
 * NOTES:
     - Be sure to switch the LEDs on board OFF (for PORTD at least)!
     - For proper I2C communication, PORTC must be in the pull-up mode!
     - In order to use the example, address pin A0 of PCF8583 must be set to 0V.
       (on mikroElektronika's module this is done by default)
 */

unsigned char sec, mnt, hr, day, mn, year;
char *txt, tnum[4];

char *R_Trim(char *str1){

  while (*str1 == ' ')
    str1++;
  return str1;
}//~

void Zero_Fill(char *value) {                             // fill text repesentation
  if (value[1] == 0) {                                    //      with leading zero
    value[1] = value[0];
    value[0] = 48;
    value[2] = 0;
  }
}//~

//--------------------- Reads time and date information from RTC (PCF8583)
void Read_Time(char *sec, char *mnt, char *hr, char *day, char *mn, char *year) {
  Soft_I2C_Start();
  Soft_I2C_Write(0xA0);
  Soft_I2C_Write(2);
  Soft_I2C_Start();
  Soft_I2C_Write(0xA1);
  *sec = Soft_I2C_Read(1);
  *mnt = Soft_I2C_Read(1);
  *hr = Soft_I2C_Read(1);
  *day = Soft_I2C_Read(1);
  *mn = Soft_I2C_Read(0);
  I2C_Stop();
}//~

//-------------------- Formats date and time
void Transform_Time(char  *sec, char *mnt, char *hr, char *day, char *mn, char *year) {
  *sec  =  ((*sec & 0xF0) >> 4)*10 + (*sec & 0x0F);
  *mnt  =  ((*mnt & 0xF0) >> 4)*10 + (*mnt & 0x0F);
  *hr   =  ((*hr & 0xF0) >> 4)*10 + (*hr & 0x0F);
  *year =  (*day & 0xC0) >> 6;
  *day  =  ((*day & 0x30) >> 4)*10 + (*day & 0x0F);
  *mn   =  ((*mn & 0x10) >> 4)*10 + (*mn & 0x0F);
}//~

//-------------------- Output values to LCD
void Display_Time(char sec, char mnt, char hr, char day, char mn, char year) {
  char *tc;
  
   ByteToStr(day, tnum);                                  // day
   tc = R_Trim(tnum);
   Zero_Fill(tc);
   LCD8_Out(1,6, tc);
   ByteToStr(mn, tnum);                                   // month
   tc = R_Trim(tnum);
   Zero_Fill(tc);
   LCD8_Out(1,9, tc);
   Lcd8_Chr(1,15,52+year);                                // year
   ByteToStr(hr,tnum);                                    // hour
   tc = R_Trim(tnum);
   Zero_Fill(tc);
   LCD8_Out(2,6,tc);
   ByteToStr(mnt,tnum);                                   // minute
   tc = R_Trim(tnum);
   Zero_Fill(tc);
   LCD8_Out(2,9,tc);
   ByteToStr(sec,tnum);                                   // seconds
   tc = R_Trim(tnum);
   Zero_Fill(tc);
   LCD8_Out(2,12,tc);
}//~

//------------------ Performs project-wide init
void Init_Main() {

  CMCON |= 0x07;                                          // turn off comparators
  ADCON1 |= 0x0F;                                         // turn off analog inputs
  MEMCON.EBDIS = 1;                                       // disable external memory bus

  Lcd8_Config(&PORTF, &PORTD, 2,4,3,7,6,5,4,3,2,1,0);

  Soft_I2c_Config(&PORTC, 4,3);
  txt = "Date:";                                          // prepare and output static text on LCD
  LCD8_Out(1,1,txt);
  Lcd8_Chr(1,8,':');
  Lcd8_Chr(1,11,':');
  txt = "Time:";
  LCD8_Out(2,1,txt);
  Lcd8_Chr(2,8,':');
  Lcd8_Chr(2,11,':');
  txt = "200";
  LCD8_Out(1,12,txt);
  Lcd8_Cmd(LCD_CURSOR_OFF);                               // cursor off
}//~

//----------------- Main procedure
void main() {
  Init_Main();                                            // perform initialization
  while (1) {
    Read_Time(&sec,&mnt,&hr,&day,&mn,&year);              // read time from RTC(PCF8583)
    Transform_Time(&sec,&mnt,&hr,&day,&mn,&year);         // format date and time
    Display_Time(sec, mnt, hr, day, mn, year);            // prepare and display on LCD
    Delay_ms(1000);                                       // wait 1s
  }
}

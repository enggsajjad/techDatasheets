/*
 * Project name:
     Pcf_Write (Demonstration on Working with the RTC Module and Software I2C
               routines)
 * Copyright:
     (c) MikroElektronika, 2005.
 * Description:
     This project is simple demonstration how to
     set date and time on PCF8583 RTC (real-time clock).
     The code can be used with any MCU that has MSSP module at portc.

     The example sets the following:
     TIME: 11:30:00
     DATE: 08/24/2004
 * Test configuration:
     MCU:             P18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    RTC
     SW:              mikroC v6.0 or higher
 * NOTES:
     - Be sure to switch the LEDs on board OFF (for PORTD at least)!
     - For proper I2C communication, PORTC must be in the pull-up mode!
     - In order to use the example, address pin A0 of PCF8583 must be set to 0V.
       (on mikroElektronika's module this is done by default)
 */

void main() {

  CMCON |= 0x07;                   // turn off comparators
  ADCON1 |= 0x0F;                  // turn off analog inputs
  MEMCON.EBDIS = 1;                // disable external memory bus

   Soft_I2C_Config(&PORTB, 4,3);   // initialize full master mode
   Soft_I2C_Start();               // issue start signal
   Soft_I2C_Write(0xA0);           // address PCF8583
   Soft_I2C_Write(0);              // start from word at address 0 (configuration word)
   Soft_I2C_Write(0x80);           // write $80 to config. (pause counter...)
   Soft_I2C_Write(0);              // write 0 to cents word
   Soft_I2C_Write(0);              // write 0 to seconds word
   Soft_I2C_Write(0x30);           // write $30 to minutes word
   Soft_I2C_Write(0x11);           // write $11 to hours word
   Soft_I2C_Write(0x30);           // write $30 to year/date word
   Soft_I2C_Write(0x08);           // write $08 to weekday/month
   Soft_I2C_Stop();                // issue stop signal

   Soft_I2C_Start();               // issue start signal
   Soft_I2C_Write(0xA0);           // address PCF8530
   Soft_I2C_Write(0);              // start from word at address 0
   Soft_I2C_Write(0);              // write 0 to config word (enable counting)
   Soft_I2C_Stop();                // issue stop signal

}//~!



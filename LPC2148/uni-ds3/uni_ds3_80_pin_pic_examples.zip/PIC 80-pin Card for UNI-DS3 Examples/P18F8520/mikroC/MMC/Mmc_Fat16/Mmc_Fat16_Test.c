/*
 * Project name:
     Mmc_Fat16_Test (Demonstration on usage of Mmc_Fat16 library)
 * Copyright:
     (c) MikroElektronika, 2005
 * Description:
     This project consists of several blocks that demonstrat various aspects of
     usage of the Mmc_Fat16 library. These are:
     - Creation of new file and writing down to it;
     - Opening existing file and re-writing it (writing from start-of-file);
     - Opening existing file and appending data to it (writing from end-of-file);
     - Opening a file and reading data from it (sending it to USART terminal);
     - Creating and modifying several files at once;
 * Test configuration:
     MCU:             P18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    -
     SW:              mikroC v6.0
 * NOTES:
     - Please make sure that MMC card is properly formatted (to FAT16 or just FAT)
       before testing it on this example!
     - This example expects MMC card to be inserted before reset, otherwise,
       the FAT_ERROR message is displayed!!!
 */

char
 FAT_ERROR[20] = "FAT16 not found",
 file_contents[50] = "XX MMC/SD FAT16 library by Anton Rieckert\n";

char
 filename[14] = "MIKRO00xTXT";                            // File names
unsigned short
 tmp, caracter, loop, loop2;
unsigned long
 i, size;


//I-I-I--------- Writes string to USART
void I_Write_Str(char *ostr) {
  unsigned short i;

  i = 0;
  while (ostr[i]) {
    USART_Write1(ostr[i++]);
  }
  USART_Write1(0x0A);
}//~

//M-M-M--------- Creates new file and writes some data to it
void M_Create_New_File() {
  filename[7] = 'A';
  Mmc_Fat_Assign(&filename, 1);                           // Will not find file and then create file
  Mmc_Fat_Rewrite();                                      // To clear file and start with new data
  for(loop = 1; loop <= 99; loop++) {                     //  We want 5 files on the MMC card
    usart_write1('.');
    file_contents[0] = loop / 10 + 48;
    file_contents[1] = loop % 10 + 48;
    Mmc_Fat_Write(file_contents, 42);                     // write data to the assigned file
  }
}//~

//M-M-M--------- Creates many new files and writes data to them
void M_Create_Multiple_Files() {
  for(loop2 = 'B'; loop2 <= 'Z'; loop2++) {
    Usart_Write1(loop2);                                       // signal the progress
    filename[7] = loop2;                                  // set filename
    Mmc_Fat_Assign(&filename, 1);                         // find existing file or create a new one
    Mmc_Fat_Rewrite();                                    // To clear file and start with new data
    for(loop = 1; loop <= 44; loop++) {
      file_contents[0] = loop / 10 + 48;
      file_contents[1] = loop % 10 + 48;
      Mmc_Fat_Write(file_contents, 42);                   // write data to the assigned file
    }
  }
}//~

//M-M-M--------- Opens an existing file and rewrites it
void M_Open_File_Rewrite() {
  filename[7] = 'C';
  Mmc_Fat_Assign(&filename, 0);
  Mmc_Fat_Rewrite();
  for(loop = 1; loop <= 55; loop++) {
    file_contents[0] = loop / 10 + 64;
    file_contents[1] = loop % 10 + 64;
    Mmc_Fat_Write(file_contents, 42);                     // write data to the assigned file
  }
}//~

//M-M-M--------- Opens an existing file and appends data to it
//               (and alters the date/time stamp)
void M_Open_File_Append() {
     filename[7] = 'B';
     Mmc_Fat_Assign(&filename, 0);
     Mmc_Fat_Set_File_Date(2005,6,21,10,35,0);
     Mmc_Fat_Append();                                    // Prepare file for append
     Mmc_Fat_Write(" for mikroElektronika 2005\n", 27);   // Write data to assigned file
}//~

//M-M-M--------- Opens an existing file, reads data from it and puts it to USART
void M_Open_File_Read() {
  filename[7] = 'B';
  Mmc_Fat_Assign(&filename, 0);
  Mmc_Fat_Reset(&size);                                   // To read file, procedure returns size of file
  for (i = 1; i <= size; i++) {
    Mmc_Fat_Read(&caracter);
    Usart_Write1(caracter);                               // Write data to USART
  }
}//~

//M-M-M--------- Deletes a file. If file doesn't exist, it will first be created
//               and then deleted.
void M_Delete_File() {
  filename[7] = 'F';
  Mmc_Fat_Assign(filename, 0);
  Mmc_Fat_Delete();
}//~

//M-M-M--------- Tests whether file exists, and if so sends its creation date
//               and file size via USART
void M_Test_File_Exist() {
  unsigned long fsize;
  unsigned int year;
  unsigned short month, day, hour, minute;
  unsigned char outstr[12];

  filename[7] = 'B';                                      //uncomment this line to search for file that DOES exists
//  filename[7] = 'F';                                    //uncomment this line to search for file that DOES NOT exist
  if (Mmc_Fat_Assign(filename, 0)) {
    //--- file has been found - get its date
    Mmc_Fat_Get_File_Date(&year, &month, &day, &hour, &minute);
    WordToStr(year, outstr);
    I_Write_Str(outstr);
    ByteToStr(month, outstr);
    I_Write_Str(outstr);
    WordToStr(day, outstr);
    I_Write_Str(outstr);
    WordToStr(hour, outstr);
    I_Write_Str(outstr);
    WordToStr(minute, outstr);
    I_Write_Str(outstr);
    //--- get file size
    fsize = Mmc_Fat_Get_File_Size();
    LongToStr((signed long)fsize, outstr);
    I_Write_Str(outstr);
  }
  else {
    //--- file was not found - signal it
    Usart_Write1('N');
    Delay_ms(1000);
    Usart_Write1('N');
  }
}//~


//-------------- Main. Uncomment the function(s) to test the desired operation(s)
void main() {
     //--- prepare PORTB for signalling

     CMCON |= 0x07;                                       // turn off comparators
     ADCON1 |= 0x0F;                                      // turn off analog inputs
     MEMCON.EBDIS = 1;                                    // disable external memory bus

     PORTB = 0;
     TRISB = 0;
     //--- set up USART for the file read
     Usart_Init1(19200);
     //--- init the FAT library (for the BigPIC3)
     Spi_Init_Advanced(MASTER_OSC_DIV16, DATA_SAMPLE_MIDDLE, CLK_IDLE_LOW, LOW_2_HIGH);
     if (!Mmc_Fat_Init(&PORTJ,6)) {
         //--- Test start
         PORTB = 0xF0;
         //--- Test routines. Uncomment them one-by-one to test certain features
         M_Create_New_File();
         M_Create_Multiple_Files();
         M_Open_File_Rewrite();
         M_Open_File_Append();
         M_Open_File_Read();
         M_Delete_File();
         M_Test_File_Exist();
     }
     else {
       I_Write_Str(FAT_ERROR);
     }
     //--- Test termination
     PORTB = 0x0F;
}//~!

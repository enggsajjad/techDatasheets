/*
 * Project name:
     MMC_Test (MMC Library Example)
 * Copyright:
     (c) MikroElektronika, 2005.
 * Description:
     MMC library test. This programme is designed to work in conjunction with
     the "MMC Card Terminal" Tool. Upon flashing, insert a MMC card into the
     module, start the MMC Terminal, then reset the MCU, when you should receive
     the "Init-OK" message. Then, you can experiment with MMC read and write
     functions, and observe the results through the terminal Receive Panel window.
 * Test configuration:
     MCU:             P18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    -
     SW:              mikroC v6.2.0.0
 * NOTES:
     - Be sure to turn ON the switches for RS232A and MMC on SW3 and SW4
       to connect UART and SPI and CS lines to RS232A output and MMC card slot,
       respectively!
 */


// if defined, we have a debug messages on PC terminal
#define RS232_debug 1

// universal variables
unsigned int px, k;                            // universal for loops and other stuff

// Variables for MMC routines
unsigned char data[512];                       // Buffer for MMC sector reading/writing
unsigned char data_for_registers[16];          // buffer for CID and CSD registers

unsigned char MMC_SPI(unsigned char out);
unsigned char MMC_Send_Command(unsigned char partial_cmm, unsigned long address, unsigned char CRC);
unsigned char MMC_Init(unsigned short * port, unsigned short pin);
unsigned char MMC_Read_Sector(unsigned long sector, char *data);
unsigned char MMC_Write_Sector(unsigned long sector, char *data);
unsigned char MMC_Read_CID(char * data_for_registers);
unsigned char MMC_Read_CSD(char * data_for_registers);




// RS232 communication variables
unsigned char received_character;
unsigned long sector_address;
unsigned char first_byte, second_byte, third_byte, fourth_byte;
unsigned char serial_buffer[2];
unsigned char serial_pointer;

// ----------------  MMC Library --------------------------------------------


// Display byte in hex
void printhex(unsigned char i) {
  unsigned char hi,lo;
  hi = i & 0xF0;                               // High nibble
  hi = hi >> 4;
  hi = hi + '0';
  if (hi>'9') hi = hi + 7;
  lo = (i & 0x0F) + '0';                       // Low nibble
  if (lo>'9') lo=lo+7;
  Usart_Write1(hi);
  Usart_Write1(lo);

}


void main()
{
  unsigned int i;

  CMCON |= 0x07;                               // turn off comparators
  ADCON1 |= 0x0F;                              // turn off analog inputs
  MEMCON.EBDIS = 1;                            // disable external memory bus

  PORTC = 0;

//  MMC_Init_Port();

  TRISC = 0b11010011;

  #ifdef RS232_debug
    Usart_Init1(9600);
  #endif

  Delay_ms(50); 

//  MMC_Config();

  #ifdef RS232_debug
    Usart_Write1('P'); // if PIC present report
    Usart_Write1('I');
    Usart_Write1('C');
    Usart_Write1('-');
    Usart_Write1('S');
    Usart_Write1('t');
    Usart_Write1('a');
    Usart_Write1('r');
    Usart_Write1('t');
    Usart_Write1('e');
    Usart_Write1('d');
    Usart_Write1(13);
    Usart_Write1(10);
  #endif

  // Beffore all, we must initialise a MMC card
  Spi_Init_Advanced(MASTER_OSC_DIV16, DATA_SAMPLE_MIDDLE, CLK_IDLE_LOW, LOW_2_HIGH);
  i = MMC_Init(&PORTJ,6);

  #ifdef RS232_debug
    if(i == 0)
    {
      Usart_Write1('M');                       // if init ok
      Usart_Write1('M');
      Usart_Write1('C');
      Usart_Write1('I');
      Usart_Write1('n');
      Usart_Write1('i');
      Usart_Write1('t');
      Usart_Write1('-');
      Usart_Write1('O');
      Usart_Write1('K');
      Usart_Write1(13);
      Usart_Write1(10);
    }
    if(i)
    {
      Usart_Write1('M');                       // if init error
      Usart_Write1('M');
      Usart_Write1('C');
      Usart_Write1('I');
      Usart_Write1('n');
      Usart_Write1('i');
      Usart_Write1('t');
      Usart_Write1('-');
      Usart_Write1('E');
      Usart_Write1('r');
      Usart_Write1('r');
      Usart_Write1(13);
      Usart_Write1(10);
    }
  #endif

  for(i=0; i<=511; i++) data[i] = 'M';         // Fill 4 buffer with some characters
  i = MMC_Write_Sector(55, data);

  #ifdef RS232_debug
    if(i == 0)
    {
      Usart_Write1('U');
      Usart_Write1('p');
      Usart_Write1('i');
      Usart_Write1('s');
      Usart_Write1('-');
      Usart_Write1('O');
      Usart_Write1('K');
    }
    else  // if error
    {
      Usart_Write1('U');
      Usart_Write1('p');
      Usart_Write1('i');
      Usart_Write1('s');
      Usart_Write1('-');
      Usart_Write1('E');
      Usart_Write1('r');
      Usart_Write1('r');
    }
    USART_Write1(13);
    USART_Write1(10);
  #endif

  // Reading of CID and CSD register on MMC card.....
  #ifdef RS232_debug
    i = MMC_Read_CID(data_for_registers);
    if(i == 0)
    {
      for(k=0; k<=15; k++)
      {
        printhex(data_for_registers[k]);
        if(k!=15) USART_Write1('-');
      }
      USART_Write1(13);
    }
    else
    {
      Usart_Write1('C');
      Usart_Write1('I');
      Usart_Write1('D');
      Usart_Write1('-');
      Usart_Write1('E');
      Usart_Write1('r');
      Usart_Write1('r');
    }
    i == MMC_Read_CSD(data_for_registers);
    if(i == 0)
    {
      for(k=0; k<=15; k++)
      {
        printhex(data_for_registers[k]);
        if(k!=15) USART_Write1('-');
      }
      USART_Write1(13);
      USART_Write1(10);
    }
    else
    {
      Usart_Write1('C');
      Usart_Write1('S');
      Usart_Write1('D');
      Usart_Write1('-');
      Usart_Write1('E');
      Usart_Write1('r');
      Usart_Write1('r');
    }
  #endif

  // Variables initialisation
  serial_pointer = 0;

  // MAIN loop
  while(1)                                                      // endless loop
  {
    if (USART_Data_Ready1())
    {
      serial_buffer[serial_pointer] = USART_Read1();            // Get the received character
      serial_pointer++;
      if(serial_pointer>1)
      {
        serial_pointer = 0;
        // prikupljamo cetiri bajta za genersianje long adrese!
        if(serial_buffer[0] == 'S') first_byte  = serial_buffer[1];
        if(serial_buffer[0] == 's') second_byte = serial_buffer[1];
        if(serial_buffer[0] == 'E') third_byte  = serial_buffer[1];
        if(serial_buffer[0] == 'e') fourth_byte = serial_buffer[1];
        if(serial_buffer[0] == 'R')                             // read command
        {
          if(serial_buffer[1] == 'r')
          {
            sector_address = ((long)first_byte << 24) + ((long)second_byte << 16) +
                             ((long)third_byte << 8)  + ((long)fourth_byte);
            i = MMC_Read_Sector(sector_address,data);
            //USART_Write(0x30 + i);
            if(i == 0)
            {
              for(k=0; k<512; k++)
              { //USART_Write(data[k]);                         //send 512 bytes from MMC to usart
                printhex(data[k]);
                USART_Write1(' ');
                if(((k+1) % 16)==0)
                {
                  USART_Write1(' ');
                  //printhex(k);
                  for(px=(k-15); px<=k; px++)
                  {
                    if((data[px]>33) && (data[px]<126))
                    {
                      USART_Write1(data[px]);
                    }
                    else
                    {
                      USART_Write1('.');
                    }
                  }
                  USART_Write1(13);
                }
              }
              USART_Write1(13);
              USART_Write1(10);
            }
            else
            {
              USART_Write1('R');                                // if error print Rd-Err
              USART_Write1('d');
              USART_Write1('-');
              USART_Write1('E');
              USART_Write1('r');
              USART_Write1('r');
              USART_Write1(13);
              USART_Write1(10);
            }
          }
        }
        if(serial_buffer[0] == 'W')                             // write command
        {
          if(serial_buffer[1] == 'w')
          {
            // generate 32-bitnu address of the sector out of 4 received bytes
            sector_address = ((long)first_byte << 24) + ((long)second_byte << 16) +
                             ((long)third_byte << 8)  + ((long)fourth_byte);
            for(k=0; k<512; k++) data[k] = received_character;  // fill RAM buffer with received characters
            i = MMC_Write_Sector(sector_address, data);         // write buffer to MMC
            if(i != 0)
            {
              // if there was an error
              USART_Write1('W');                                // print Wr-Err
              USART_Write1('r');
              USART_Write1('-');
              USART_Write1('E');
              USART_Write1('r');
              USART_Write1('r');
              USART_Write1(13);
              USART_Write1(10);
            }
            else
            {
              USART_Write1('W');                                // else, print Wr-OK
              USART_Write1('r');
              USART_Write1('-');
              USART_Write1('O');
              USART_Write1('K');
              USART_Write1(13);
              USART_Write1(10);
            }
          }
        }
        if(serial_buffer[0] == 'C')
        {
          received_character = serial_buffer[1];
        }
      }
    }
  }
}

/*
 * Project name:
     Spi_Lcd_Test (Simple demonstration of the Spi LCD Library functions)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This is a simple demonstration of Spi LCD library functions. LCD is first
     initialized (4-bit data interface, default pin settings for mE lcd modules),
     then some text is written.
 * Test configuration:
     MCU:             PIC18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HSPLL, 10.0000 MHz
     Ext. Modules:    mE Serial Lcd Adapter, LCD 2x16 (LCD 4x20)
     SW:              mikroC v6.2.1.0
 * NOTES:
     None.
*/

char *text = "mikroElektronika";

void main() {
  Spi_Init();                   // initialize spi
  Spi_Lcd_Init();               // initialize lcd over spi interface
  Spi_Lcd_Cmd(LCD_CLEAR);       // Clear display
  Spi_Lcd_Cmd(LCD_CURSOR_OFF);  // Turn cursor off
  Spi_Lcd_Out(1,6, "mikroE");   // Print text to LCD, 1st row, 7th column
  Spi_Lcd_Chr_CP('!');          // append !
  Spi_Lcd_Out(2,0, text);       // Print text to LCD, 2nd row, 3rd column
  Spi_Lcd_Out(3,1,"mikroE");    // for lcd with more than two raws
  Spi_Lcd_Out(4,15,"mikroE");   // for lcd with more than two raws
}//~!


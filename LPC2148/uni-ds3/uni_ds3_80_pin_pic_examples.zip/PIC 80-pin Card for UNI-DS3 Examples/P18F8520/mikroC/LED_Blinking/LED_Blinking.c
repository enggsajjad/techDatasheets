/*
 * Project name:
     LED_Blinking (Simple 'Hello World' project)
 * Copyright
     (c) Mikroelektronika, 2005
 * Description:
     This is a simple 'Hello World' project. It turns on/off diodes connected to
     PORTB
 * Test configuration:
     MCU:             P18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    -
     SW:              mikroC v6.0
 * NOTES:
     None.
*/

void main() {

  CMCON |= 0x07;         // turn off comparators
  ADCON1 |= 0x0F;        // turn off analog inputs
  MEMCON.EBDIS = 1;      // disable external memory bus

  TRISB = 0;             // PORTB is output
  
  do {
    PORTB = 0xFF;        // Turn ON diodes on PORTB
    Delay_ms(1000);      // 1 second delay
    PORTB = 0;           // Turn OFF diodes on PORTB
    Delay_ms(1000);      // 1 second delay
  } while(1);            // endless loop
}//~!

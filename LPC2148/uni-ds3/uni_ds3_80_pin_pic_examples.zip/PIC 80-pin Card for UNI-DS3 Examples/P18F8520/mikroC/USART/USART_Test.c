/*
 * Project name:
    USART_test
 * Copyright:
     (c) mikroElektronika, 2005 - 2006
 * Revision History:
     20050312:
       - initial release.
 * Description:
    This code demonstrates how to use usart library routines.
    Upon receiving data via rs232, PIC MCU immediately sends it back to the sender.
 * Test configuration:
     MCU:             PIC18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.000 MHz
     Ext. Modules:    None
    SW:              mikroC v6.0.0.0. or higher
 * NOTES:
     None
*/

unsigned short i;

char rxd[4];

void main() {

   TRISH = 0;                              // PORTH is LCD output
   CMCON |= 0x07;                          // turn off comparators
   ADCON1 |= 0x0F;                         // turn off analog inputs
   MEMCON.EBDIS = 1;                       // disable external memory bus


   Usart_Init2(9600);                      // initialize USART module
   Lcd_Init(&PORTH);                       // Initialize  LCD Display
   Lcd_Cmd(Lcd_CURSOR_OFF);
   Lcd_Out(1, 1, "Rxd= ");
   
   while (1) {
      if (USART_Data_Ready2()) {    // if data is received

        i = USART_Read2();          // read the received data
        ByteToStr(i,rxd);
        Lcd_Out_Cp(rxd);              // display received data
        USART_Write2(i);                   // send data via USART
      }
   }

}





/*
 * Project name:
     Soft_Uart_Test (Simple usage of soft_uart library functions)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This code demonstrates how to use usart library routines. Upon receiving
     data via RS232, PIC MCU immediately sends it back to the sender.
 * Test configuration:
     MCU:             P18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v5.0
 * NOTES:
     None.
*/

unsigned short data = 0;
unsigned short ro = 0;
unsigned short *recOK;

void main() {

  CMCON |= 0x07;                           // turn off comparators
  ADCON1 |= 0x0F;                          // turn off analog inputs
  MEMCON.EBDIS = 1;                        // disable external memory bus

  recOK = &ro;
  Soft_Uart_Init(PORTC, 7, 6, 19200, 0);   // initialize Soft UART
  ro = !ro;                                //  (8 bit, 9600 baud rate, no parity bit...

  while (1) {
    do {
      data = Soft_Uart_Read(recOK);        // receive data
    } while (*recOK);
    Soft_UART_Write(data);                 // send data via UART
   }
}//~!


/*
 * Project Name:
     T6369Cdemo (GLCD Library demo for Toshiba's T6369 Controller)
 * Target Platform:
     PIC
 * Copyright:
     (c) mikroElektronika, 2006.
 * Revision History:
     20060512:
       - Initial release. Credits to Bruno Gavand.
 * Description:
     this code in intended to work with GLCD's based on
     TOSHIBA T6963C controller.
     This parts may need a -15V power supply on Vee for LCD drive,
     a simple DC/DC converter can be made with a 2N2905, 220 �H self, diode & 47 �F cap,
     transistor base is driven with PWM thrue a current limiting resistor.
     This parts have a 8 Kb built-in display RAM, this allows 2 graphics panels
     and one text panel.
 * Test configuration:
     MCU:             PIC18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HSPLL, 10.000MHz
     Ext. Modules:    mE T6369C 240x128 Parallel Adapter, T6369C diplay 240x128 pixels
     SW:              mikroC v6.0.0.0.
 * NOTES:
     None.
 */


#include        "T6963C.h"

/*
 * bitmap pictures stored in ROM
 */
extern  const   char mc[] ;
extern  const   char einstein[] ;

void main(void)
        {
        unsigned char   panel ;         // current panel
        unsigned int    i ;             // general purpose register
        unsigned char   curs ;          // cursor visibility
        unsigned int    cposx, cposy ;  // cursor x-y position

        CMCON |= 0x07;                  // turn off comparators
        ADCON1 |= 0x0F;                 // turn off analog inputs
        MEMCON.EBDIS = 1;               // disable external memory bus
        PSPCON.PSPMODE = 0;

        PORTB = 0 ;
        TRISB = 0xFF ;
        TRISC = 0 ;                     // port C is output only
        PORTC = 0b00000000 ;            // chip enable, reverse on, 8x8 font

        /*
         * init display for 240 pixel width and 128 pixel height
         * 8 bits character width
         * data bus on PORTD
         * control bus on PORTF
         * bit 2 is !WR
         * bit 1 is !RD
         * bit 0 is C!D
         * bit 4 is RST
         */

        //T6963C_Init_240x128();
        T6963C_init(240, 128, 8, &PORTD, &PORTF, 2, 1, 0, 4) ;
        
        /*
         * enable both graphics and text display at the same time
         */
        T6963C_graphics(1) ;
        T6963C_text(1) ;

        panel = 0 ;
        i = 0 ;
        curs = 0 ;
        cposx = cposy = 0 ;

        /*
         * text messages
         */
        T6963C_write_text(" GLCD LIBRARY DEMO, WELCOME !", 0, 0, T6963C_ROM_MODE_XOR) ;
        T6963C_write_text(" EINSTEIN WOULD HAVE LIKED mC", 0, 15, T6963C_ROM_MODE_XOR) ;
        
        /*
         * cursor
         */
        T6963C_cursor_height(8) ;       // 8 pixel height
        T6963C_set_cursor(0, 0) ;       // move cursor to top left
        T6963C_cursor(0) ;              // cursor off

        /*
         * draw rectangles
         */
        T6963C_rectangle(0, 0, 239, 127, T6963C_WHITE) ;
        T6963C_rectangle(20, 20, 219, 107, T6963C_WHITE) ;
        T6963C_rectangle(40, 40, 199, 87, T6963C_WHITE) ;
        T6963C_rectangle(60, 60, 179, 67, T6963C_WHITE) ;

        /*
         * draw a cross
         */
        T6963C_line(0, 0, 239, 127, T6963C_WHITE) ;
        T6963C_line(0, 127, 239, 0, T6963C_WHITE) ;

        /*
         * draw solid boxes
         */
        T6963C_box(0, 0, 239, 8, T6963C_WHITE) ;
        T6963C_box(0, 119, 239, 127, T6963C_WHITE) ;

        /*
         * draw circles
         */
        T6963C_circle(120, 64, 10, T6963C_WHITE) ;
        T6963C_circle(120, 64, 30, T6963C_WHITE) ;
        T6963C_circle(120, 64, 50, T6963C_WHITE) ;
        T6963C_circle(120, 64, 70, T6963C_WHITE) ;
        T6963C_circle(120, 64, 90, T6963C_WHITE) ;
        T6963C_circle(120, 64, 110, T6963C_WHITE) ;
        T6963C_circle(120, 64, 130, T6963C_WHITE) ;

        T6963C_sprite(76, 4, einstein, 88, 119) ;                       // draw a sprite
        
        T6963C_setGrPanel(1) ;          // select other graphic panel

        T6963C_image(mc) ;              // fill the graphic screen with a picture

        for(;;)
                {

                /*
                 * if RB1 is pressed, toggle the display between graphic panel 0 and graphic 1
                 */
                if(PORTB & 0b00000010)
                        {
                        panel++ ;
                        panel &= 1 ;
                        T6963C_displayGrPanel(panel) ;
                        Delay_ms(300) ;
                        }
                        
                /*
                 * if RB2 is pressed, display only graphic panel
                 */
                else if(PORTB & 0b00000100)
                        {
                        T6963C_graphics(1) ;
                        T6963C_text(0) ;
                        Delay_ms(300) ;
                        }
                        
                /*
                 * if RB3 is pressed, display only text panel
                 */
                else if(PORTB & 0b00001000)
                        {
                        T6963C_graphics(0) ;
                        T6963C_text(1) ;
                        Delay_ms(300) ;
                        }

                /*
                 * if RB4 is pressed, display text and graphic panels
                 */
                else if(PORTB & 0b00010000)
                        {
                        T6963C_graphics(1) ;
                        T6963C_text(1) ;
                        Delay_ms(300) ;
                        }

                /*
                 * if RB5 is pressed, change cursor
                 */
                else if(PORTB & 0b00100000)
                        {
                        curs++ ;
                        if(curs == 3) curs = 0 ;
                        switch(curs)
                                {
                                case 0:
                                        // no cursor
                                        T6963C_cursor(0) ;
                                        break ;
                                case 1:
                                        // blinking cursor
                                        T6963C_cursor(1) ;
                                        T6963C_cursor_blink(1) ;
                                        break ;
                                case 2:
                                        // non blinking cursor
                                        T6963C_cursor(1) ;
                                        T6963C_cursor_blink(0) ;
                                        break ;
                                }
                        Delay_ms(300) ;
                        }

                /*
                 * move cursor, even if not visible
                 */
                cposx++ ;
                if(cposx == T6963C_txtCols)
                        {
                        cposx = 0 ;
                        cposy++ ;
                        if(cposy == T6963C_grHeight / T6963C_CHARACTER_HEIGHT)
                                {
                                cposy = 0 ;
                                }
                        }
                T6963C_set_cursor(cposx, cposy) ;
                
                Delay_ms(100) ;
                }
        }


void main() {
  unsigned char *ccc, *ddd;

  CMCON |= 0x07;                           // turn off comparators
  ADCON1 |= 0x0F;                          // turn off analog inputs
  MEMCON.EBDIS = 1;                        // disable external memory bus

  Lcd8_Config(&PORTF, &PORTD, 2,4,3,7,6,5,4,3,2,1,0);
  Lcd8_Cmd(LCD_CLEAR);
  Lcd8_Cmd(LCD_CURSOR_OFF);

  Lcd8_Out(1, 1, "MikroElektronika");
  
}
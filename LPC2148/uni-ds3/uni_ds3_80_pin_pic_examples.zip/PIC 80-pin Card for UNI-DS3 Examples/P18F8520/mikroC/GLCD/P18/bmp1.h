
extern const unsigned short
 mikro_test_bmp[1024],
 maska_bmp[1024],
 tito_bmp[1024],
 mikro_logo_1_bmp[1024],
 mikro_logo_2_bmp[1024],
 mikro_logo_3_bmp[1024],
 mikro_logo_4_bmp[1024],
 mikro_logo_5_bmp[1024],
 mikro_logo_6_bmp[1024],
 mikro_logo_7_bmp[1024],
 mikro_logo_8_bmp[1024];


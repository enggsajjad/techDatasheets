void ByteToStr(unsigned char num, unsigned char *str);
void IntToStr(signed int num, unsigned char *str);
void WordToStr(unsigned int num, unsigned char *str);

unsigned char Bcd2Dec(unsigned char numBcd);
unsigned int Bcd2Dec16(unsigned int numBcd16);

unsigned char Dec2Bcd(unsigned char numDec);
unsigned int Dec2Bcd16(unsigned int numDec16);


/*
 * Project name:
     GLCD_Test_02 (GLCD animation example)
 * Copyright:
     (c) mikroElektronika, 2005.
 * Description:
     GLCD 128x64 animation example, using the Glcd_Image() function.
 * Test configuration:
     MCU:             P18F8520
     Dev.Board:       BIGPIC3,BIGPIC4
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    GLCD
     SW:              mikroC v6.0
*/

#include "bmp1.h"

void delay2S(){
  delay_ms(2000);                  
}

void main() {
  unsigned short ii;
  unsigned int jj;
  char *someText;


  CMCON |= 0x07;                              // turn off comparators
  ADCON1 |= 0x0F;                             // turn off analog inputs
  MEMCON.EBDIS = 1;                           // disable external memory bus

  Glcd_Init(&PORTJ, 0,1,2,3,5,4, &PORTH);
   Glcd_Fill(0x00);

  lMainLoop:
  Glcd_Image( mikro_logo_1_bmp );
  Glcd_Image( mikro_logo_2_bmp );
  Glcd_Image( mikro_logo_3_bmp );
  Glcd_Image( mikro_logo_4_bmp );
  Glcd_Image( mikro_logo_5_bmp );
  Glcd_Image( mikro_logo_6_bmp );
  Glcd_Image( mikro_logo_7_bmp );
  Glcd_Image( mikro_logo_8_bmp );
  delay2S();
  
  Glcd_Image( mikro_logo_7_bmp );  
  Glcd_Image( mikro_logo_6_bmp );
  Glcd_Image( mikro_logo_5_bmp );
  Glcd_Image( mikro_logo_4_bmp );
  Glcd_Image( mikro_logo_3_bmp );
  Glcd_Image( mikro_logo_2_bmp );
  Glcd_Image( mikro_logo_1_bmp );
  
  goto lMainLoop;

}//~!

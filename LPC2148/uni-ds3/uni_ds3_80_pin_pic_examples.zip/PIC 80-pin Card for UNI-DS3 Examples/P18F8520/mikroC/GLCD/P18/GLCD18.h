//-------------- GLCD_16.c Header file

void Strobe();
void Glcd_Set_Page(unsigned short page);
void Glcd_Set_Side(unsigned short x_pos);
void Glcd_Set_X(unsigned short x_pos);
unsigned short Glcd_Read_Data();
void Glcd_Write_Data(unsigned short data);
void Glcd_Fill(unsigned short pattern);
void Glcd_Init(unsigned char *ctrl_port,
               char cs1, char cs2, char rs, char rw, char rst, char en,
               unsigned char *data_port);
void Glcd_Write_Char(unsigned short chr,
                     unsigned short x_pos,
                     unsigned short page_num,
                     unsigned short color);
void Glcd_Write_Text(char *text, unsigned short x_pos,
                     unsigned short page_num, unsigned short color);
void Glcd_Dot(unsigned short x_pos, unsigned short y_pos, unsigned short color);
void Glcd_Line(int x_start, int y_start,
               int x_end, int y_end,
               unsigned short color);
void Glcd_H_Line(unsigned short x_start, unsigned short x_end,
                 unsigned short y_pos, unsigned short color);
void Glcd_V_Line(unsigned short y_start, unsigned short y_end,
                 unsigned short x_pos, unsigned short color);
void Glcd_Circle(int x_center, int y_center, int radius,
                 unsigned short color);
void Glcd_Image(const unsigned short * image);     //?

void Glcd_Rectangle(unsigned short x_upper_left,unsigned short y_upper_left,
                    unsigned short x_bottom_right,unsigned short y_bottom_right,
                    unsigned short color);
void Glcd_Box(unsigned short x_upper_left, unsigned short y_upper_left,
              unsigned short x_bottom_right, unsigned short y_bottom_right,
              unsigned short color);

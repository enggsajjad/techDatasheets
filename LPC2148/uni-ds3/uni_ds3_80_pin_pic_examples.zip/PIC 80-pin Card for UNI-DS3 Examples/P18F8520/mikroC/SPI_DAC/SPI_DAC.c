 /*
 * Project name:
     DAC01 (Driving external Digital-to-Analog converter from mikroC)
 * Copyright:
     (c) MikroElektronika, 2005.
 * Description:
      This is a sample program which demonstrates the use of the Microchip's
      MCP4921 12-bit D/A converter with PIC mcu's. This device accepts digital
      input (number from 0..4095) and transforms it to the output voltage,
      ranging from 0..Vref. The reference voltage on the
      mikroElektronika's DAC module is 5V. On reset the DAC is being set to the
      mid-range (~2.5V).
 * Test configuration:
     MCU:             PIC16F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.000 MHz
     Ext. Modules:    -
     SW:              mikroC v6.2.1.0
 * NOTES:
     - In this example, the entire DAC's resolution range (12bit -> 4096
       increments) is covered, meaning you'll need to hold a button for about
       7 minutes to get from mid-range to the end-of-range.
 */
#include <built_in.h>
 
const CHIP_SELECT = 4;
const LD          = 5;

unsigned int   value;

void Init(){
 CMCON  = 0x07;                   // turn off comparators
 ADCON1 = 0x0F;                   // turn off analog inputs
 MEMCON.EBDIS = 1;                // disable external memory bus
 
 TRISD = 0;
 PORTD = 0xAA;

 TRISB |= 0b00000011;
 TRISE &= ~(1<<CHIP_SELECT);
 TRISE &= ~(1<<LD);
 
 SPI_init();
}

// DAC increments (0..4095) --> output voltage (0..Vref)
void DAC_Output(unsigned int Value){
 char temp;

  PORTE &= ~(1<<CHIP_SELECT);
  PORTE &= ~(1<<LD);        // Prepare for data transfer
  temp = hi(Value)&0x0F;    // Prepare hi-byte for transfer
  temp |= 0x30;             // It's a 12-bit number, so only
  SPI_write(temp);          // lower nibble of high byte is used
  temp = lo(Value);         // Prepare lo-byte for transfer
 
  SPI_write(temp);
  PORTE |= (1<<CHIP_SELECT);
  PORTE |= (1<<LD);
}

// main
void main(){

 Init();
 value = 2048;               // When program starts, DAC gives
 DAC_Output(value);          // the output in the mid-range

 while (1){
     if ((Button(&PORTB,0,1,1))&&(value < 4095)){ // Test button on B0 (increment)
       value++;
       PORTD = ~PORTD;
     }
     else
       if ((Button(&PORTB,1,1,1))&& (value > 0)){ // If RB0 is not active then test
          value--;                               // RB1 (decrement)
          PORTD= ~PORTD;
       }
     DAC_Output(value);                          // Perform output
     Delay_ms(100);                              // Slow down key repeat pace
 }
}

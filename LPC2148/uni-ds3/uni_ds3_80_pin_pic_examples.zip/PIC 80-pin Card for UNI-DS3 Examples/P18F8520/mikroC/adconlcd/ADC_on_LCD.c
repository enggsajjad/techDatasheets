/*
 * Project name:
     ADC_on_LCD (Displaying ADC result on LCD)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This code demonstrates how to use library function ADC_read, and library
     procedures and functions for LCD display (4 bit interface).
 * Test configuration:
     MCU:             P18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    LCD
     SW:              mikroC v6.0
 * NOTES:
     None.
 */

unsigned char ch;
int t;
unsigned short tcc;
char *tc, cflag;
long tlong;

void Display_Adc(int adcval);


void interrupt() {

    t  = Adc_Read(2);                          // get ADC value from 2nd channel
    cflag = 1;
  PIR1.TMR1IF = 0;
}//~!~

void Display_Adc(int adcval) {
  long longadc;
  char ch;

  PIR1.TMR1IE = 0;

  longadc = adcval * 5000;                     // use int multiplication instead of long
  asm{                                         // and fill the upper two bytes manually
    MOVFF  STACK_2, FLOC_Display_Adc+2
    MOVFF  STACK_3, FLOC_Display_Adc+3
  }
  adcval = longadc >> 10;
  ch     = adcval / 1000;                      // prepare value for diplay

  Lcd_Custom_Chr(2, 9, 48 + ch);               // write ASCII at 2nd row, 9th column
  Lcd_Custom_Chr_CP('.');
  ch    = (adcval / 100) % 10;
  Lcd_Custom_Chr_Cp(48 + ch);

  ch    = (adcval / 10) % 10;
  Lcd_Custom_Chr_Cp(48 + ch);

  ch    = adcval % 10;
  Lcd_Custom_Chr_Cp(48 + ch);
  Lcd_Custom_Chr_Cp('V');
  PIR1.TMR1IE = 1;

}//~

void main() {

  PORTC = 0;
  TRISC = 0;
  
  INTCON = 0;                                  // disable all interrupts
  ADCON1 |= 0x0C;

  Lcd_Custom_Config(&PORTD, 7,6,5,4,&PORTD, 0,3,1);
  Lcd_Custom_Cmd(LCD_CURSOR_OFF);              // send command to LCD (cursor off)
  Lcd_Custom_Cmd(LCD_CLEAR);                   // send command  to LCD (clear LCD)
  
  tc = "mikroElektronika";                     // assign text to string a
  Lcd_Custom_Out(1,1,tc);                      // print string a on LCD, 1st row, 1st column
  tc = "LCD example";                          // assign text to string a
  Lcd_Custom_Out(2,1,tc);                      // print string a on LCD, 2nd row, 1st column
  
  ADCON1     = 0x0B;                           // configure VDD as Vref, and analog channels
  TRISA      = 0xFF;                           // designate porta as input
  Delay_ms(2000);

  tc  = "voltage:";                            // assign text to string a
  Lcd_Custom_Out(2,1,tc);                      // print string a on LCD, 2nd row, 1st column
  

  tcc = 1;
  cflag = 0;
  //--- set up Timer1 for interrupt
  PIR1.TMR1IF = 0;
  TMR1L = TMR1H = 0;
  T1CON = 0b00110100;
  //--- global interrupt enable
  INTCON.PEIE = 1;
  INTCON.GIE = 1;
  //--- enable timer
  PIE1.TMR1IE = 1;
  T1CON.TMR1ON = 1;
  while (1) {                                  // endless loop
    if (cflag) {
      PORTC = 1;
      Display_Adc(t);
      cflag = 0;
    }
  }
}//~!


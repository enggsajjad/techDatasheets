/*
 * Project name:
     Lcd_Test (Simple demonstration of the LCD Library functions)
 * Copyright:
     (c) MikroElektronika, 2005.
 * Description:
     This is a simple demonstration of LCD library functions.

 * Test configuration:
    MCU:              P18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    LCD
     SW:              mikroC v6.0
 * NOTES:
     None.
 */

char *text = "mikroC_123";

void main() {
  unsigned short btnRes;
  
  CMCON |= 0x07;                                        // turn off comparators
  ADCON1 |= 0x0F;                                       // turn off analog inputs
  MEMCON.EBDIS = 1;                                     // disable external memory bus

  Lcd_Custom_Config(&PORTD, 7,6,5,4,&PORTD, 0,3,1);     // Initialize LCD connected to PORTB
  Lcd_Custom_Cmd(LCD_CLEAR);                            // Clear display
  Lcd_Custom_Cmd(LCD_CURSOR_OFF);                       // Turn cursor off
  Lcd_Custom_Out(1,1, text);                            // Print text to LCD, 2nd row, 1st column
  Lcd_Custom_Chr_CP('@');
  Lcd_Custom_Chr(1,14, '#');
  Lcd_Custom_Cmd(LCD_SECOND_ROW);
  Lcd_Custom_Out_CP(text);

  while (1) ;                                           // endless loop

}//~!


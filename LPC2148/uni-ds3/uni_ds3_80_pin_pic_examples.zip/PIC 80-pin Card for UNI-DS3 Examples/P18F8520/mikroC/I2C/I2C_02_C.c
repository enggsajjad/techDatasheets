/*
 * Project name:
     I2C_02_C (Advanced I2C Example)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This example features the advanced communication with the 24C02 EEPROM chip
     by introducing its own library of functions for this task: init, single
     write, single and sequential read. It performs write of a sequence of bytes
     (characters) into the EEPROM and writes this out at the first row on LCD.
     Then, data read from EEPROM is performed and the result is displayed at the
     second row on LCD.
 * Test configuration:
     MCU:             P18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    EEPROM 24C02
     SW:              mikroC v6.0
*/

#include "EEPROM_24C02.h"

const char DATA_LENGTH = 20;
char someData[20], otherData[20];
unsigned short ii ,tmpData;

//--------------- Main
void main() {                              
  unsigned char *ccc, *ddd;

  CMCON |= 0x07;                           // turn off comparators
  ADCON1 |= 0x0F;                          // turn off analog inputs
  MEMCON.EBDIS = 1;                        // disable external memory bus

  EEPROM_24C02_Init();
  Lcd8_Config(&PORTF, &PORTD, 2,4,3,7,6,5,4,3,2,1,0);
  Lcd8_Cmd(LCD_CLEAR);
  Lcd8_Cmd(LCD_CURSOR_OFF);

  ccc = "*mikroE-UNI-DS3*";
  strcpy(someData, ccc);

  // Example for single-byte write
  ii = 0;
  tmpData = 1;
  while ((tmpData = someData[ii]) != 0) {
    ii++;
    EEPROM_24C02_WrSingle(ii, tmpdata);
    Delay_ms(20);
    Lcd8_Chr(1,ii, tmpData);
  }
  ii++;
  EEPROM_24C02_WrSingle(ii, 0);
  Delay_ms(20);
  // Example for single-byte read
  ii = 1;
  tmpData = 1;
  while ((tmpData = EEPROM_24C02_RdSingle(ii)) != 0) {
    Lcd8_Chr(2,ii, tmpData);
    Delay_ms(500);
    ii++ ;
  }

  // Example for sequential data read
 /* EEPROM_24C02_RdSeq(1, otherData, DATA_LENGTH);
  LCD_Out(2,1,otherData);*/

}//~!


// String.h
//     mikroC_20050130

char * strcpy(char *to, char *from);


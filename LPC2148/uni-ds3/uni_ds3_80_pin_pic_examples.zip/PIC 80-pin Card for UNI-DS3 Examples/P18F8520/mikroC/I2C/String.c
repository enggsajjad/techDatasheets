
//-------------- Copies a string from <*from> to <*to> arrray
char * strcpy(char *to,  char *from) {
  char *cp;
  cp = to;
  while(*cp++ = *from++) ;
/*  do {
    *cp = *from;
    cp++;
    from++;
  } while(*cp);*/
  return to;
}//~

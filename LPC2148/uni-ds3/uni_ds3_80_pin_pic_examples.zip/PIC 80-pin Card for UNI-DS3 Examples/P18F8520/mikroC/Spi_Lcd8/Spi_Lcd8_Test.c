/*
 * Project name:
     Spi_LCD8_Test (How to use mikroC's Spi LCD 8-bit interface library)
 * Copyright:
     (c) mikroElektronika, 2005 - 2006
 * Revision History:
     20061103:
       - initial release;
 * Description:
     The code prints text on LCD (8-bit interface) via spi interface
 * Test configuration:
     MCU:             PIC18F8520
     Dev.Board:       UNI-DS3
     Oscillator:      HSPLL, 10.000MHz
     Ext. Modules:    mE Serial Lcd/Glcd Adapter, LCD w/ Hitachi HD44780U compatible LCD controller
     SW:              mikroC v6.2.1.0
 * NOTES:
     None.
 */

char *text = "mikroE";

void main() {
  Spi_Init();                                 // initialize spi interface
  Spi_Lcd8_Init();                            // intialize lcd in 8bit mode via spi
  Spi_Lcd8_Cmd(LCD_CLEAR);                    // Clear display
  Spi_Lcd8_Cmd(LCD_CURSOR_OFF);               // Turn cursor off
  Spi_Lcd8_Out(1,6, text);                    // Print text to LCD, 1st row, 7th column...
  Spi_Lcd8_Chr_CP('!');                       // append '!'
  Spi_Lcd8_Out(2,0, "mikroelektronika");      // Print text to LCD, 2nd row, 3rd column...
  Spi_Lcd8_Out(3,1, text);                    // for lcd modules with more than two raws
  Spi_Lcd8_Out(4,15, text);                   // for lcd modules with more than two raws
}//~!



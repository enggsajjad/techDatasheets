//-------------- Glcd_Fonts declarations

//extern const unsigned short defaultFont[];
extern const unsigned short FontSystem5x8[];
extern const unsigned short font5x7[];
extern const unsigned short System3x6[];
extern const unsigned short Character8x8[];


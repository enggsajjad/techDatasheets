/*
 * Project name:
     GLCD_Test (Demonstration of the GLCD library routines)
 * Target Platform:
     dsPIC
 * Copyright:
     (c) mikroElektronika, 2007
 * Revision History:
     20060512:
       - adapted for dsPIC;
     20050422:
       - initial release (for PIC18);
 * Description:
     This is a simple demonstration of the GLCD library routines:
     - Init and Clear (pattern fill)
     - Image display
     - Basic geometry - lines, circles, boxes and rectangles
     - Text display and handling
 * Test configuration:
     MCU:             dsPIC30F6014A
     Dev.Board:       UNI-DS3
     Oscillator:      XT-PLL, 10.000MHz
     Ext. Modules:    None.
     SW:              mikroC for dsPIC30/33 and PIC24 v4.
 * NOTES:
     - Fonts used in this example contain only uppercase letters.
 */

#include "bmp1.h"

char cArr[20];
char *someText;

void Delay2S(){
  delay_ms(2000);
}

void main() {
  unsigned short ii;
  unsigned int jj;

  sometext = cArr;

  //--- turn off A/D inputs
  ADPCFG = 0xFFFF;
  
  Glcd_Config(&PORTD, 8, &PORTD, 9, &PORTD, 10, &PORTD, 11, &PORTD, 13, &PORTD, 12, &PORTD, &PORTD, 1);
  Delay_100ms();

  lMainLoop:

  Glcd_Fill(0x00);
  Glcd_Image( maska_bmp );
  Delay2S();

  Glcd_Fill(0x00);
  Glcd_Circle(63,32, 20, 1);
  Delay2S();
  Glcd_Line(120,1, 5,60, 1);
  Glcd_Line(12,42, 5,60, 1);
  Delay2S();

  Glcd_Rectangle(12,20, 93,57, 1);
  Delay2S();

  Glcd_Line(120,12, 12,60, 1);
  Delay2S();

  Glcd_H_Line(5,15, 6, 1);
  Glcd_Line(0,12, 120,60, 1);
  Glcd_V_Line(7,63, 127, 1);
  Delay2S();

  for (ii = 1; ii <= 10; ii++)
    Glcd_Circle(63,32, 3*ii, 1);
  Delay2S();

  Glcd_Box(12,20, 70,57, 2);
  Delay2S();

  Glcd_Set_Font(defaultFont, 5,7, 48);
  someText = "BIG:ONE";
  Glcd_Write_Text(someText, 5,3, 2);
  Delay2S();


  someText = "SMALL:NOT:SMALLER";
  Glcd_Write_Text(someText, 20,5, 1);
  Delay2S();

  Glcd_Fill(0x00);
  Glcd_Set_Font(System3x6, 3, 6, 0x20);
  Glcd_Write_Text(someText, 10,5, 1);
  Delay2S();

  goto lMainLoop;
}


// * Project name:
//     RTC_Read (Reading date/time stamp from PCF8583 through I2C)
// * Copyright:
//     (c) mikroElektronika, 2007.
// * Revision History:
//     20050130:
//       - initial release;
// * Description:
//     This project is simple demonstration how to read date and time from PCF8583
//     RTC (real-time clock). Date and time are printed on LCD.
// * Test configuration:
//     MCU:             dsPIC30F6014A
//     Dev.Board:       UNI-DS3
//     Oscillator:      XT, 10.000MHz
//     Ext. Modules:    LCD 2x16 chars
//     SW:              mikroC for dsPIC30/33 and PIC24 v4.0
// * NOTES:
//     - Turn on SCL and SDA switches.

unsigned char sec, min1, hr, day, mn, year;
char *txt, tnum[4];

void Zero_Fill(char *value) {    // fill text repesentation
  if (value[1] == 0) {           //      with leading zero
    value[1] = value[0];
    value[0] = 48;
    value[2] = 0;
  }
}

//--------------------- Reads time and date information from RTC (PCF8583)
void Read_Time(char *sec, char *min, char *hr, char *day, char *mn, char *year) {
  I2C_Start();
  I2C_Write(0xA0);
  I2C_Write(2);
  I2c_Restart();
  I2C_Write(0xA1);
  *sec =I2c_Read(0);
  *min =I2c_Read(0);
  *hr =I2c_Read(0);
  *day =I2c_Read(0);
  *mn =I2c_Read(1);
  I2C_Stop();
}

//-------------------- Formats date and time
void Transform_Time(char  *sec, char *min, char *hr, char *day, char *mn, char *year) {
  *sec  =  ((*sec & 0xF0) >> 4)*10 + (*sec & 0x0F);
  *min  =  ((*min & 0xF0) >> 4)*10 + (*min & 0x0F);
  *hr   =  ((*hr & 0xF0) >> 4)*10 + (*hr & 0x0F);
  *year =  (*day & 0xC0) >> 6;
  *day  =  ((*day & 0x30) >> 4)*10 + (*day & 0x0F);
  *mn   =  ((*mn & 0x10) >> 4)*10 + (*mn & 0x0F);
}

//-------------------- Output values to LCD
void Display_Time(char sec, char min, char hr, char day, char mn, char year) {
  ByteToStr(day,tnum);
  txt = rtrim(tnum);
  Zero_Fill(txt);
  Lcd_Custom_Out(1,6,txt);
  ByteToStr(mn,tnum);
  txt = rtrim(tnum);
  Zero_Fill(txt);
  Lcd_Custom_Out(1,9,txt);
  Lcd_Custom_Chr(1,15,52+year);
  ByteToStr(hr,tnum);
  txt = rtrim(tnum);
  Zero_Fill(txt);
  Lcd_Custom_Out(2,6,txt);
  ByteToStr(min,tnum);
  txt = rtrim(tnum);
  Zero_Fill(txt);
  Lcd_Custom_Out(2,9,txt);
  ByteToStr(sec,tnum);
  txt = rtrim(tnum);
  Zero_Fill(txt);
  Lcd_Custom_Out(2,12,txt);
}

//------------------ Performs project-wide init
void Init_Main() {
  ADPCFG = 0xFFFF;
  
  Lcd_Custom_Config(&PORTD, 7, 6, 5, 4, &PORTD, 0, 2, 1);
  I2C_Init(100000);         // initialize I2C
  
  txt = "Date:";            // prepare and output static text on LCD
  Lcd_Custom_Out(1,1,txt);
  Lcd_Custom_Chr(1,8,':');
  Lcd_Custom_Chr(1,11,':');
  txt = "Time:";
  Lcd_Custom_Out(2,1,txt);
  Lcd_Custom_Chr(2,8,':');
  Lcd_Custom_Chr(2,11,':');
  txt = "200";
  Lcd_Custom_Out(1,12,txt);
  Lcd_Custom_Cmd(LCD_CURSOR_OFF);   // cursor off
}

//----------------- Main procedure
void main() {
  Init_Main();                                     // perform initialization
  while (1) {
    Read_Time(&sec,&min1,&hr,&day,&mn,&year);      // read time from RTC(PCF8583)
    Transform_Time(&sec,&min1,&hr,&day,&mn,&year); // format date and time
    Display_Time(sec, min1, hr, day, mn, year);    // prepare and display on LCD
    Delay_ms(1000);                                // wait 1s
    }
}

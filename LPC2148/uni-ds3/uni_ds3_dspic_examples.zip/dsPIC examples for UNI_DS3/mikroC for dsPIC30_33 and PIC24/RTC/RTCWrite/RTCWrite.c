// * Project name:
//     RTC_Write (Writing date/time data to PCF8583 through I2C)
// * Copyright:
//     (c) mikroElektronika, 2007.
// * Revision History:
//     20050130:
//       - initial release;
// * Description:
//     This project is simple demonstration how to set date and time on PCF8583
//     RTC (real-time clock).
//     The example sets the following:
//       TIME: 11:30:00
//       DATE: 08/24/2004
//     Please refer to PCF8583 datasheet for more information on config. word and
//     time format settings.
// * Test configuration:
//     MCU:             dsPIC30F6014A
//     Dev.Board:       UNI-DS3
//     Oscillator:      XT, 10.000MHz
//     Ext. Modules:
//     SW:              mikroC for dsPIC30/33 and PIC24 v4.0
// * NOTES:
//     - Turn on SCL and SDA switches.

void main() {
   ADPCFG = 0xFFFF;
   
   I2C_Init(10000);         // initialize full master mode
   I2C_Start();             // issue start signal
   I2C_Write(0xA0);         // address PCF8583
   I2C_Write(0);            // start from word at address 0 (configuration word)
   I2C_Write(0x80);         // write $80 to config. (pause counter...)
   I2C_Write(0);            // write 0 to cents word
   I2C_Write(0);            // write 0 to seconds word
   I2C_Write(0x30);         // write $30 to minutes word
   I2C_Write(0x11);         // write $11 to hours word
   I2C_Write(0x24);         // write $24 to year/date word
   I2C_Write(0x08);         // write $08 to weekday/month
   I2C_Stop();              // issue stop signal

   I2C_Start();             // issue start signal
   I2C_Write(0xA0);         // address PCF8530
   I2C_Write(0);            // start from word at address 0
   I2C_Write(0);            // write 0 to config word (enable counting)
   I2C_Stop();              // issue stop signal
}



// * Project name:
//     Uart1_Test (Usage of mikroC's UART libraries)
// * Target Platform:
//     dsPIC;
// * Copyright:
//     (c) mikroElektronika, 2007.
// * Revision History:
//     20060510:
//       - Initial release;
// * Description:
//     This simple example demonstrates usage of mikroC's UART1 library, through
//     a 'loopback' interface.
// * Test configuration:
//     MCU:             dsPIC30F6014A
//     Dev.Board:       UNI-DS3
//     Oscillator:      XT, 10.000MHz
//     Ext. Modules:    None.
//     SW:              mikroC for dsPIC30/33 and PIC24 v4.0
// * NOTES:
//     - Turn on RX232A and RX232B switches.



unsigned rx1;

void main() {

  Uart1_Init(19200);

  Uart1_Write_Char('s');           // signal start
  while(1){
    if (Uart1_Data_Ready())  {
      rx1 = Uart1_Read_Char();
      Uart1_Write_Char(rx1);
      }
    }
}
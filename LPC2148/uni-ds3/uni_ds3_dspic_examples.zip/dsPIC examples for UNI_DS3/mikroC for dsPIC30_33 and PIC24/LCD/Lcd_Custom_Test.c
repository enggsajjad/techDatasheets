/*
 * Project name:
     Lcd_Custom_Test (Simple demonstration of the LCD Library functions)
 * Target Platform:
     dsPIC;
 * Copyright:
     (c) MikroElektronika, 2007.
 * Revision History:
     20060515:
       - Initial release;
 * Description:
     This is a simple demonstration of LCD library functions. LCD is first
     initialized then some text is written at the first and the second row.
 * Test configuration:
     MCU:             dsPIC30F6014A
     Dev.Board:       UNI-DS3
     Oscillator:      XT-PLL8, 10.000MHz
     Ext. Modules:    None.
     SW:              mikroC for dsPIC30/33 and PIC24 v4.0.0.0
 * NOTES:
     None.
 */


char txt[10] = "mikro";

void main() {
  ADPCFG = 0xFFFF;

  Lcd_Custom_Config(&PORTD, 7, 6, 5, 4, &PORTD, 0, 2, 1);
  Lcd_Custom_Cmd(LCD_CLEAR);
  Lcd_Custom_Cmd(LCD_CURSOR_OFF);
  
  Lcd_Custom_Out(1,3, txt);
  Lcd_Custom_Out(2,6, txt);
  Lcd_Custom_Chr(2,7, 'a');
  Lcd_Custom_Out(1,10, txt);
  Lcd_Custom_Chr(1,11, 'o');
}


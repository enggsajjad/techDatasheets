// * Project name:
//     DAC Example
// * Copyright:
//     (c) MikroElektronika, 2007
// * Description:
//     This is a sample program which demonstrates communication between
//     the Microchip's MCP4921 12-bit D/A converter and dsPIC30/33 and PIC24 MCUs.
//     This device accepts digital input (number from 0..4095) and
//     transforms it to the output voltage, ranging from 0..Vref.
// * NOTES:
// * Test configuration:
//     MCU:             dsPIC30F6014A
//     Dev.Board:       UNI-DS3
//     Oscillator:      XS-PLL8, 10.000 MHz
//     Ext. Modules:    None
//     SW:              mikroC for dsPIC30/33 and PIC24 v4.0.
// * NOTES:
//     - Turn on SCK, MISO, MOSI, DAC-CS and DAC-LD switches.

unsigned int value;

void InitMain() {
  ADPCFG = 0xFFFF;                        // Set AN pins as digital

  Spi1_Init();                            // Initialize Spi1 module in 8-bit mode

  PORTC.F2 = 1;                           // Set CS
  PORTC.F3 = 1;                           // Set LD
  TRISC.F2 = 0;                           // Set CS pin as output
  TRISC.F3 = 0;                           // Set LD pin as output
}


// DAC increments (0..4095) --> output voltage (0..Vref)
void DAC_Output(unsigned int valueDAC) {
 char temp;

  PORTC.F2 = 0;                           // Select DAC module
  PORTC.F3 = 0;                           // Enable data transfer

  // Send 2 bytes of valueDAC variable
  temp = (valueDAC >> 8) & 0x0F;          // Prepare hi-byte for transfer
                                          // It's a 12-bit number, so only
                                          // lower nibble of high byte is used
  temp |= 0x30;                           // Set MCP4921 control bits
  Spi1_Write(temp);                       // Send data via SPI

  temp = valueDAC;                        // Prepare lo-byte for transfer
  Spi1_Write(temp);                       // Send data via SPI

  PORTC.F3 = 1;                           // Disable data transfer
  PORTC.F2 = 1;                           // Deselect DAC module
}


void main() {
  InitMain();

  value = 2047;                           // When program starts, DAC gives
                                          // the output in the mid-range

  while (1) {                             // Main loop
    DAC_Output(value++);
    if (value > 4095)
      value = 0;
    Delay_ms(5);
  }
}

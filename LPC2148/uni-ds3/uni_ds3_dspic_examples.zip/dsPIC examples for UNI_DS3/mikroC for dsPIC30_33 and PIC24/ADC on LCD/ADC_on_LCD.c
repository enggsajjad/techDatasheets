// * Project name:
//     ADC on LCD
// * Copyright:
//     (c) MikroElektronika, 2007
// * Description:
//     This project is a simple demonstration of mcp3204 with P30F6014A.
//     MCU communicates with MCP3204 using SPI communication.
//     Readings are written on LCD.
// * NOTES:
// * Test configuration:
//     MCU:             dsPIC30F6014A
//     Dev.Board:       UNI-DS3
//     Oscillator:      XS-PLL8, 10.000 MHz
//     Ext. Modules:    None
//     SW:              mikroC for dsPIC30/33 and PIC24 v4.0.
// * NOTES:
//     - Turn on SCK, MISO, MOSI and ADC-CS switches.

#include <spi_const.h>
unsigned int  measurement;

void Init() {
  ADPCFG = 0xFFFF;                            // Configure all AN pins as digital

  // Init LCD
  Lcd_Custom_Config(&PORTD, 7, 6, 5, 4, &PORTD, 0, 2, 1);
  Lcd_Custom_Cmd(LCD_CLEAR);
  Lcd_Custom_Cmd(LCD_CURSOR_OFF);

  // Init SPI in 16bit mode
  Spi1_Init_Advanced(_SPI_MASTER, _SPI_16_BIT, _SPI_PRESCALE_SEC_1, _SPI_PRESCALE_PRI_4,
  _SPI_SS_DISABLE, _SPI_DATA_SAMPLE_MIDDLE, _SPI_CLK_IDLE_HIGH, _SPI_ACTIVE_2_IDLE);

  
  PORTC.F1 = 1;                               // Set ADC_CS
  TRISC.F1 = 0;
}

unsigned int getADC(char channel) {           // returns 0..4096
 unsigned int tmp_word = 0;
  
  PORTC.F1 = 0;                               // select mcp3204
  // Send 0 0 0 0 0 0 0 0 0 1 1 x CH1 CH0 x x sequence, see MCP3204 datasheet
  tmp_word  = channel << 2;
  tmp_word |= 0x0060;
  Spi1_Write(tmp_word);

  tmp_word  = Spi1_Read(0);                   // Read result followed by 4 dummy bits
  tmp_word  = tmp_word >> 4;                  // pack result
  
  PORTC.F1 = 1;                               // deselect mcp3204
  
  return tmp_word;
}

void processValue(unsigned int pv, char channel) { // Writes Value to LCD
  char lcdRow, lcdCol;

  if (channel < 2)
    lcdRow=1;
  else
    lcdRow=2;
    
  if (channel%2 > 0 )
    lcdCol=13;
  else
    lcdCol=4;


  Lcd_Custom_Chr(lcdRow,lcdCol,    pv/1000    + 48);
  Lcd_Custom_Chr(lcdRow,lcdCol+1, (pv/100)%10 + 48);
  Lcd_Custom_Chr(lcdRow,lcdCol+2, (pv/10)%10  + 48);
  Lcd_Custom_Chr(lcdRow,lcdCol+3,  pv%10      + 48);

}


//main procedure
void main() {
  Init();                                     // Initialize SPI and LCD
  Lcd_Custom_Out(1,1,"C0=      C1=");
  Lcd_Custom_Out(2,1,"C2=      C3=");
  while (1) {
    measurement = getADC(0);                 // Get ADC result from Channel 0
    ProcessValue(measurement,0);             // print measurement on LCD
    measurement = getADC(1);                 // Get ADC result from Channel 1
    ProcessValue(measurement,1);             // print measurement on LCD
    measurement = getADC(2);                 // Get ADC result from Channel 2
    ProcessValue(measurement,2);             // print measurement on LCD
    measurement = getADC(3);                 // Get ADC result from Channel 3
    ProcessValue(measurement,3);             // print measurement on LCD
    Delay_ms(1000);
  }
}

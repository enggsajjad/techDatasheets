// * Project name:
//     Mmc_Fat16_Test (Demonstration on usage of Mmc_Fat16 library)
// * Platforms:
//     dsPIC, PIC24, PIC18;
// * Copyright:
//     (c) MikroElektronika, 2007.
//  * Revision History:
//      20060420:
//        - Initial release for the dsPIC platform;
//      20060201:
//        - added test for swap file creation, to reflect changes in the
//          mmc_fat16 library;
//      20051204:
//        - added test for file delete, to reflect changes in the mmc_fat16 library;
//      20050512:
//        - initial release;
// * Description:
//     This project consists of several blocks that demonstrat various aspects of
//     usage of the Mmc_Fat16 library. These are:
//     - Creation of new file and writing down to it;
//     - Opening existing file and re-writing it (writing from start-of-file);
//     - Opening existing file and appending data to it (writing from end-of-file);
//     - Opening a file and reading data from it (sending it to USART terminal);
//     - Creating and modifying several files at once;
//     - Reading file contents;
//     - Deleting file(s);
//     - Creating the swap file (see Help for details);
// * Test configuration:
//     <dsPIC>:
//       MCU:             dsPIC30F6014A
//       Dev.Board:       UNI-DS3
//       Oscillator:      XT-PLL8, 10.000MHz
//       Ext. Modules:    None.
//       SW:              mikroC for dsPIC30/33 and PIC24 v4.0
// * NOTES:
//     - Please make sure that MMC card is properly formatted (to FAT16 or just FAT)
//       before testing it on this example!
//     - The MMC uses hardware SPI for communication, so make sure that it gets
//       properly connected to the port where SPI module is located (PORTC for most
//       PICs)! For dsPICs, the MMC/SD module should be attached to Spi1 module (switch SW4);
//     - This example expects MMC card to be inserted before reset, otherwise,
//       the FAT_ERROR message is displayed!!!
//     - Turn on SCK, MISO, MOSI, RX232A and RX232B switches.
//     - Disable MMC jumpers for 3.3V microcontrollers.


#include <spi_const.h>

const char SWAP_FILE_MSG[] = "Swap file at: ";

char
 fat_txt[20] = "FAT16 not found",
 file_contents[50] = "XX MMC/SD FAT16 library by Anton Rieckert\n";

char
 filename[14] = "MIKRO00xTXT";          // File names
unsigned
 loop, loop2;
unsigned short
 caracter;
unsigned long
 i, size;
 
char Buffer[512];


//I-I-I--------- Writes string to USART
void I_Write_Str(char *ostr) {
  unsigned i;

  i = 0;
  while (ostr[i]) {
    Uart1_Write_Char(ostr[i++]);
  }
}

//M-M-M--------- Creates new file and writes some data to it
void M_Create_New_File() {
  filename[7] = 'A';
  Mmc_Fat_Assign(&filename, 0xA0);      // Will not find file and then create file
  Mmc_Fat_Rewrite();                    // To clear file and start with new data
  for(loop = 1; loop <= 99; loop++) {   //  We want 5 files on the MMC card
    Uart1_Write_Char('.');
    file_contents[0] = loop / 10 + 48;
    file_contents[1] = loop % 10 + 48;
    Mmc_Fat_Write(file_contents, 42);   // write data to the assigned file
  }
}

//M-M-M--------- Creates many new files and writes data to them
void M_Create_Multiple_Files() {
  for(loop2 = 'B'; loop2 <= 'Z'; loop2++) {
    Uart1_Write_Char(loop2);             // signal the progress
    filename[7] = loop2;                 // set filename
    Mmc_Fat_Assign(&filename, 0xA0);        // find existing file or create a new one
    Mmc_Fat_Rewrite();                   // To clear file and start with new data
    for(loop = 1; loop <= 44; loop++) {
      file_contents[0] = loop / 10 + 48;
      file_contents[1] = loop % 10 + 48;
      Mmc_Fat_Write(file_contents, 42);  // write data to the assigned file
    }
  }
}

//M-M-M--------- Opens an existing file and rewrites it
void M_Open_File_Rewrite() {
  filename[7] = 'C';
  Mmc_Fat_Assign(&filename, 0);
  Mmc_Fat_Rewrite();
  for(loop = 1; loop <= 55; loop++) {
    file_contents[0] = loop / 10 + 64;
    file_contents[1] = loop % 10 + 64;
    Mmc_Fat_Write(file_contents, 42);    // write data to the assigned file
  }
}

//M-M-M--------- Opens an existing file and appends data to it
//               (and alters the date/time stamp)
void M_Open_File_Append() {
     filename[7] = 'B';
     Mmc_Fat_Assign(&filename, 0);
     Mmc_Fat_Set_File_Date(2005,6,21,10,35,0);
     Mmc_Fat_Append();                                    // Prepare file for append
     Mmc_Fat_Write(" for mikroElektronika 2005\n", 27);   // Write data to assigned file
}

//M-M-M--------- Opens an existing file, reads data from it and puts it to USART
void M_Open_File_Read() {
  filename[7] = 'B';
  Mmc_Fat_Assign(&filename, 0);
  Mmc_Fat_Reset(&size);                 // To read file, procedure returns size of file
  for (i = 1; i <= size; i++) {
    Mmc_Fat_Read(&caracter);
    Uart1_Write_Char(caracter);         // Write data to USART
  }
}

//M-M-M--------- Deletes a file. If file doesn't exist, it will first be created
//               and then deleted.
void M_Delete_File() {
  filename[7] = 'F';
  Mmc_Fat_Assign(filename, 0);
  Mmc_Fat_Delete();
}

//M-M-M--------- Tests whether file exists, and if so sends its creation date
//               and file size via USART
void M_Test_File_Exist(char fLetter) {
  unsigned long fsize;
  unsigned int year;
  unsigned short month, day, hour, minute;
  unsigned char outstr[12];

  filename[7] = fLetter;
  if (Mmc_Fat_Assign(filename, 0)) {
    //--- file has been found - get its date
    Mmc_Fat_Get_File_Date(&year, &month, &day, &hour, &minute);
    WordToStr(year, outstr);
    I_Write_Str(outstr);
    ByteToStr(month, outstr);
    I_Write_Str(outstr);
    WordToStr(day, outstr);
    I_Write_Str(outstr);
    WordToStr(hour, outstr);
    I_Write_Str(outstr);
    WordToStr(minute, outstr);
    I_Write_Str(outstr);
    //--- get file size
    fsize = Mmc_Fat_Get_File_Size();
    LongToStr((signed long)fsize, outstr);
    I_Write_Str(outstr);
  }
  else {
    //--- file was not found - signal it
    Uart1_Write_Char(0x55);
    Delay_ms(1000);
    Uart1_Write_Char(0x55);
  }
}


//-------------- Tries to create a swap file, whose size will be at least 100
//               sectors (see Help for details)
void M_Create_Swap_File() {
  unsigned int i;

  for(i=0; i<512; i++)
    Buffer[i] = i;

  size = Mmc_Fat_Get_Swap_File(5000, "mikroE.txt", 0x20);   // see help on this function for details

  if (size) {
    LongToStr((signed long)size, fat_txt);
    I_Write_Str(fat_txt);

    for(i=0; i<5000; i++) {
      Mmc_Write_Sector(size++, Buffer);
      Uart1_Write_Char('.');
    }
  }
}

//-------------- Main. Uncomment the function(s) to test the desired operation(s)
void main() {
     
     ADPCFG = 0xFFFF;
     //--- set up USART for the file read
     Spi1_Init_Advanced(_SPI_MASTER, _SPI_8_BIT, _SPI_PRESCALE_SEC_1, _SPI_PRESCALE_PRI_64,
                        _SPI_SS_DISABLE, _SPI_DATA_SAMPLE_MIDDLE, _SPI_CLK_IDLE_HIGH, _SPI_ACTIVE_2_IDLE);

     Uart_Init(19200);
     Delay_ms(200);                      // wait for UART module to stabilize
     //--- init the FAT library
     if (!Mmc_Fat_Init(&PORTC,4)) {
      // reinitialize spi at higher speed
      Spi1_Init_Advanced(_SPI_MASTER, _SPI_8_BIT, _SPI_PRESCALE_SEC_1, _SPI_PRESCALE_PRI_4,
                      _SPI_SS_DISABLE, _SPI_DATA_SAMPLE_MIDDLE, _SPI_CLK_IDLE_HIGH, _SPI_ACTIVE_2_IDLE);

      I_Write_Str("Start");
      //--- Test routines. Uncomment them one-by-one to test certain features
      M_Create_New_File();
      M_Create_Multiple_Files();

      M_Open_File_Rewrite();
      M_Open_File_Append();
      M_Delete_File();
      M_Create_Swap_File();

      M_Open_File_Read();
      M_Test_File_Exist('F');         // this file will not exist here
      M_Test_File_Exist('B');         // this file will exist here

      }
     else {
       I_Write_Str(fat_txt);
     }
     //--- Test termination
     I_Write_Str("End");
}



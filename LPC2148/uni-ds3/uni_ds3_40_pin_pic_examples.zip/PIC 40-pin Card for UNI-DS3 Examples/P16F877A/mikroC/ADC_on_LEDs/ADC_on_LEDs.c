/*
 * Project name:
     ADC_on_LEDs (Displaying ADC result on port LEDs)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     The code demonstrates using library function for AD conversion. 10 bits
     result is displayed on PORTB (two most significant bits) and PORTD.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v6.0
*/

unsigned int temp_res;

void main() {
  ADCON1 = 0x80;              // Configure analog inputs and Vref
  TRISA  = 0xFF;              // PORTA is input
  TRISB  = 0x3F;              // Pins RB7, RB6 are outputs
  TRISD  = 0;                 // PORTD is output

  do {
    temp_res = ADC_Read(2);   // Get results of AD conversion
    PORTD = temp_res;         // Send lower 8 bits to PORTD
    PORTB = temp_res >> 2;    // Send 2 most significant bits to RB7, RB6
  } while(1);
}


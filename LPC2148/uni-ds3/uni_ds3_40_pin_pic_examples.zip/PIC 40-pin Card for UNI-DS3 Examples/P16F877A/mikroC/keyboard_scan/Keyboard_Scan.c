/*
 * Project name:
     Keyboard_Scan (Demonstration of TMRO interrupt)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This programme demonstrates simple usage of TMR0 interrupt on regular PICs.
     When interrupt occurs, it looks for changes on PORTB and mirrors them on
     PORTD.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v6.0
 * NOTES:
     In order to work properly, in this example, ports B and D must have pull-down
     resistors, also when a button is pressed high(VCC) voltage level should be
     applied (jumper J10)
*/

unsigned char tb;
unsigned char oldPortb;

void interrupt() {
  tb = 1 << TMR0IF;
  if (INTCON | tb) {                // Test if timer0 interrupt has occurred

     TMR0 = 78;                     // write 78 to TMRO
     if (oldPortb != PORTB) {       // Test if portb has changed
       oldPortb = PORTB;            // save new value
       PORTD    = PORTB;            // display changes of 4 most significant bits
     }
     INTCON = 0x20;                 // clear TMR0IF, set TMR0IE
  }
}//~

void main() {
  PORTC = 0;
  TRISC = 0;
  TRISB       = 255;                // designate portb as input
  oldPortb    =   0;                // initialize old-portb
  OPTION_REG  = 0xC7;               // assign prescaler to TMRO
  PORTD       =   0;                // initialize PORTD
  TRISD       =   0;                // designate PORTD as output
  PORTB       =   0;                // initialize PORTB
  INTCON      = 0xA0;               // enable TMR0IE
}//~!


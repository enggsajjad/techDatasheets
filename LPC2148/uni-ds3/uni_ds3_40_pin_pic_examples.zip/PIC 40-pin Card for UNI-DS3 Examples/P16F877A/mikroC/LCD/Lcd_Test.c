/*
 * Project name:
     Lcd_Test (Simple demonstration of the LCD Library functions)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This is a simple demonstration of LCD library functions. LCD is first
     initialized (PORTD, 4-bit data interface, default pin settings), then some
     text is written at the first row.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    LCD 2x16
     SW:              mikroC v6.0
 * NOTES:
     None.
*/

char *text = "mikroElektronika";

void main() {

  Lcd_Config(&PORTD,0,1,3,7,6,5,4); // Initialize LCD connected to PORTD
  LCD_Cmd(LCD_CLEAR);       // Clear display
  LCD_Cmd(LCD_CURSOR_OFF);  // Turn cursor off
  LCD_Out(1,1, text);       // Print text to LCD, 1st row, 1st column
  Delay_ms(1000);
  LCD_Out(2,6,"mikroE");
}//~!


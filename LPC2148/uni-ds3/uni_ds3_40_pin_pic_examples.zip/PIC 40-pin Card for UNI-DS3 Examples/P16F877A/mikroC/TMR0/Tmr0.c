/*
 * Project name:
     TMR0 (Simple 'Hello World' demonstration of interrupt handling)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This code demonstrates using interrupts in mikroC. Program turns on/off
     LEDs on PORTB approximately each second.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v6.0
 * NOTES:
     None.
 */

unsigned cnt;

void interrupt() {
  cnt++;                   // Increment value of cnt on every interrupt
  TMR0   = 96;
  INTCON = 0x20;           // Set T0IE, clear T0IF
}//~

void main() {
  OPTION_REG = 0x84;       // Assign prescaler to TMR0
  TRISB = 0;               // PORTB is output
  PORTB = 0xFF;            // Initialize PORTB
  TMR0  = 96;
  INTCON = 0xA0;           // Enable TMRO interrupt
  cnt = 0;                 // Initialize cnt

  do {
    if (cnt == 400) {
      PORTB = ~PORTB;      // Toggle PORTB LEDs
      cnt = 0;             // Reset cnt
    }
  } while(1);
}//~!


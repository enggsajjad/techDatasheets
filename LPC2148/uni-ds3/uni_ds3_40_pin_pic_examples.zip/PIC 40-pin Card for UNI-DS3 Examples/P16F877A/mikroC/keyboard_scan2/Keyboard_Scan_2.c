/*
 * Project name:
     Keyboard_Scan_2 (Usage of PORTB state change Interrupt)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This is a simple demonstration of pin change interrupt. When some of the
     pins RB4..RB7 changes state, interrupt is triggered and PORTD is then
     updated accordingly.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v5.0
 * NOTES:
     None.
 */

unsigned char tb;

void interrupt() {
  tb = 1 << RBIF;
  if (INTCON | tb) {                   // test if RBIF is set
    Delay_ms(5);                       // wait 5 mS
    PORTD  = PORTB & 0xF0;             // update value (upper half of portd)
    INTCON = 0x08;                     // clear RBIF, set RBIE
  }
}//~

void main() {
  PORTB  = 255;
  TRISB  = 255;
  TRISD  = 0x0F;
  INTCON = 0x89;
}//~!


//EEPROM 24C02 read/write library


//--------------- Performs 24C02 Init
void EEPROM_24C02_Init() {
  I2C_Init(100000);
}//~

//--------------- Writes data to 24C02 EEPROM - signle location
void EEPROM_24C02_WrSingle(unsigned short wAddr, unsigned short wData) {
    I2C_start();              // issue I2C start signal
    I2C_Wr(0xA2);             // send byte via I2C  (command to 24cO2)
    I2C_Wr(wAddr);            // send byte (address of EEPROM location)
    I2C_Wr(wData);            // send data (data to be written)
    I2C_Stop();
}//~

//--------------- Reads data from 24C02 EEPROM - single location (random)
unsigned short EEPROM_24C02_RdSingle(unsigned short rAddr) {
    unsigned short reslt;

    I2C_Start();              // issue I2C start signal
    I2C_Wr(0xA2);             // send byte via I2C  (device address + W)
    I2C_Wr(rAddr);            // send byte (data address)
    I2C_Repeated_Start();     // issue I2C signal repeated start
    I2C_Wr(0xA3);             // send byte (device address + R)
    reslt = I2C_Rd(0u);       // Read the data (NO acknowledge)
    while (!I2C_Is_Idle())
      asm nop;                // Wait for the read cycle to finish
    I2C_Stop();
    return reslt;
}//~

//--------------- Reads data from 24C02 EEPROM - sequential read
void EEPROM_24C02_RdSeq(unsigned short rAddr,
                        unsigned char *rdData,
                        unsigned short rLen) {
  unsigned short i;
  // C doesn't keep the char[] array length information, so it's up to
  //   the programmer to take care not to exceed it!!!
  I2C_Start();                // issue I2C start signal
  I2C_Wr(0xA2);               // send byte via I2C  (device address + W)
  I2C_Wr(rAddr);              // send byte (address of EEPROM location)
  I2C_Repeated_Start();       // issue I2C signal repeated start
  I2C_Wr(0xA3);               // send byte (device address + R)
  i = 0;
  while (i < rLen) {
    rdData[i] = I2C_Rd(1u);   // read data (YES acknowledge)
    Delay_ms(20);
    i++ ;
  }
  rdData[i] = I2C_Rd(0u);     // last data is red WITH ack
  I2C_Stop();
}//~

//Declarations
//--------------------------------------------------------------end-declarations
/*
 * Project name:
     I2c_02 (Advanced I2C Example)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This example features the advanced communication with the 24C02 EEPROM chip
     by introducing its own library of functions for this task: init, single
     write, single and sequential read. It performs write of a sequence of bytes
     (characters) into the EEPROM and writes this out at the first row on LCD.
     Then, data read from EEPROM is performed and the result is displayed at the
     second row on LCD.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    EEPROM (24C02), LCD
     SW:              mikroC v6.0
 * NOTES:
     None.
 */

#include "String.h"
#include "EEPROM_24C02.h"

const char DATA_LENGTH = 20;
char someData[20], otherData[20];
unsigned short ii ,tmpData;

//--------------- Main
void main() {
  unsigned char *ccc="mikroI2C_16F877A";

  Delay_ms(1000);
  
  EEPROM_24C02_Init();
  Lcd_Config(&PORTD,0,1,3,7,6,5,4); // Initialize LCD connected to PORTD
  LCD_Cmd(LCD_CLEAR);
  LCD_Cmd(LCD_CURSOR_OFF);

  ccc = "miI2C_16F877A";
  strcpy(someData, ccc);

  // Example for single-byte write
  ii = 0;
  tmpData = 1;
  while ((tmpData = someData[ii]) != 0) {
    ii++;
    EEPROM_24C02_WrSingle(ii, tmpdata);
    Delay_ms(20);
    LCD_Chr(1,ii, tmpData);
  }
  EEPROM_24C02_WrSingle(ii+1, 0);
  Delay_ms(20);
  // Example for single-byte read
  ii = 1;
  tmpData = 1;
  while ((tmpData = EEPROM_24C02_RdSingle(ii)) != 0) {
    LCD_Chr(2,ii, tmpData);
    Delay_ms(20);
    ii++ ;
  }
//   Example for sequential data read
/*  EEPROM_24C02_RdSeq(1, otherData, DATA_LENGTH);
  LCD_Out(2,1,otherData);  */

}//~!


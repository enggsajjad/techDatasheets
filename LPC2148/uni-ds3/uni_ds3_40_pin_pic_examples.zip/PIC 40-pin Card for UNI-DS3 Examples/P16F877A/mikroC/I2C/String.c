
//-------------- Copies a string from <*from> to <*to> arrray
char * strcpy(char *to,  char *from) {
	char *cp;
  cp = to;
	while(*cp++ = *from++) ;
	return to;
}//~

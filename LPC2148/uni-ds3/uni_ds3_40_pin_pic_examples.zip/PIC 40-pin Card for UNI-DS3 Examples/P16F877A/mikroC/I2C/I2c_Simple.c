/*
 * Project name:
     I2c_Simple (Simple test of I2C library routines)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This programme demonstrates usage of the I2C library routines in mikroC. It
     establishes I2C bus communication with 24C02 EEPROM chip, writes one byte
     of data on some location, then reads it and displays it on PORTB.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.000MHz
     Ext. Modules:    EEPROM (24C02)
     SW:              mikroC v5.0
 * NOTES:
     None.
 */

void main(){
 PORTB = 0;
 TRISB = 0;
 
 I2C_Init(100000);
 I2C_Start();              // issue I2C start signal
 I2C_Wr(0xA2);             // send byte via I2C  (command to 24cO2)
 I2C_Wr(2);                // send byte (address of EEPROM location)
 I2C_Wr(0xFF);             // send data (data to be written)
 I2C_Stop();
 
 Delay_100ms();
 
 I2C_Start();              // issue I2C start signal
 I2C_Wr(0xA2);             // send byte via I2C  (device address + W)
 I2C_Wr(2);                // send byte (data address)
 I2C_Repeated_Start();     // issue I2C signal repeated start
 I2C_Wr(0xA3);             // send byte (device address + R)
 PORTB = I2C_Rd(0u);       // Read the data (NO acknowledge)
 I2C_Stop();
 
}

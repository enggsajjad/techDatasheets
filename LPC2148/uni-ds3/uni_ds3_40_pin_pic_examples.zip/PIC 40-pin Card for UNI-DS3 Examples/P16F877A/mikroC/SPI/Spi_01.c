/*
 * Project name:
     Spi_01 (Demonstration of SPI Library usage)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This code demonstrates using library routines for SPI communication. Also,
     this example demonstrates working with max7219. Eight 7 segment displays
     are connected to MAX7219. MAX7219 is connected to RC1 and SDO, SDI, SCKL
     pins are connected accordingly.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       EasyPic4
     Oscillator:      HS, 08.0000 MHz
     Ext. Modules:    MAX7219
     SW:              mikroC v5.0
 * NOTES:
     None.
 */

#include "m7219.h"

unsigned char i;

void main() {
  SPI_init();               // standard configuration
                            //  instead of SPI_init, you can use SPI_init_Advanced as shown below
                            // SPI_init_Advanced(Master_OSC_div64, Data_SAMPLE_MIDDLE , CLK_Idle_HIGH , HIGH_2_LOW);
  TRISC &= 0xFD;
  max7219_init1();          // initialize  max7219
  for (i = 1; i<=8u; i++) {
    PORTC &= 0xFD;          // select max7219
    SPI_write(i-1);           // send i to max7219 (digit place)
    SPI_write(i);         // send i to max7219 (digit)
    PORTC |= 2;             // deselect max7219
  }
  TRISB = 0;
  PORTB = i;
}//~!


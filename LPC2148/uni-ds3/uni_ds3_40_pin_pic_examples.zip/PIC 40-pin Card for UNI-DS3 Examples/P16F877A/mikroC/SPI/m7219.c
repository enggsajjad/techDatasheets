//MAX 7219 chip_util Library


void max7219_init1() {
  PORTC &= 0xFD;           // SELECT MAX
  SPI_write(0x09);         // BCD mode for digit decoding
  SPI_write(0xFF);
  PORTC |= 2;              // DESELECT MAX

  PORTC &= 0xFD;           // SELECT MAX
  SPI_write(0x0A);
  SPI_write(0x0F);         // Segment luminosity intensity
  PORTC |= 2;              // DESELECT MAX

  PORTC &= 0xFD;           // SELECT MAX
  SPI_write(0x0B);
  SPI_write(0x07);         // Display refresh
  PORTC |= 2;              // DESELECT MAX

  PORTC &= 0xFD;           // SELECT MAX
  SPI_write(0x0C);
  SPI_write(0x01);         // Turn on the display
  PORTC |= 2;              // DESELECT MAX

  PORTC &= 0xFD;           // SELECT MAX
  SPI_write(0x00);
  SPI_write(0xFF);         // No test
  PORTC |= 2;              // DESELECT MAX
}


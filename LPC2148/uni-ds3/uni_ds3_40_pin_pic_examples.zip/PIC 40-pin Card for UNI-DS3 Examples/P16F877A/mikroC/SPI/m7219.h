//MAX 7219 chip_util Library header

void max7219_init1();

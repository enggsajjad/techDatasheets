/*
 * Project name:
     Timer1_01 (Using TMR1 to obtain interrupts)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This code demonstrates how to use TMR1 for interrupts. Program toggles LEDs
     on PORTB.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v5.0  or higher
 * NOTES:
     None.
 */

unsigned short cnt;
unsigned char tb;

void interrupt() {
  cnt++ ;
  PIR1.TMR1IF = 0;            // clear TMR1IF
}//~

void main() {
  TRISB = 0;
  T1CON = 1;
  PIR1.TMR1IF = 0;            // clear TMR1IF
  PIE1  =   1;                // enable interrupts
  PORTB = 0xF0;
  cnt =   0;                  // initialize cnt
  INTCON = 0xC0;

  do {
    if (cnt == 38) {
      PORTB  = ~PORTB;
      cnt = 0;
    }
  } while (1);
}//~!


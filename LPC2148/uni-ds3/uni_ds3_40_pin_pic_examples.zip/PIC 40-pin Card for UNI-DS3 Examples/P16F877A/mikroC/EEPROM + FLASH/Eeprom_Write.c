/*
 * Project name:
     Eeprom_Write (Use of PIC's internal EEPROM)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This is a demonstration of using library functions for handling of the
     PIC's internal EEPROM module. First, some data is written to EEPROM; then,
     the data is read from the same locations and displayed on PORTB.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v6.0
 * NOTES:
     None.
 */

char i = 0, j = 0;
                                        
void main() {                                   
  PORTB = 0;                                     
  TRISB = 0;
  
  j = 1;
  for (i = 0; i < 15u; i++)
    EEprom_Write(i, j++);
  
  Delay_ms(50);

  for (i = 0; i < 15u; i++) {
    PORTB = EEPROM_Read(i);
    Delay_ms(500);
  }
}//~!

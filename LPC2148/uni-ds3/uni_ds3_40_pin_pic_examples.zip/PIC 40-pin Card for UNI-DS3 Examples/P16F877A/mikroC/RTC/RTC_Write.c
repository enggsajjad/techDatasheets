/*
 * Project name:
     RTC_Write (Writing date/time data to PCF8583 through I2C)
 * Copyright:
     (c) mikroElektronika, 2005 - 2006
 * Revision History:
     20050130:
       - initial release;
 * Description:
     This project is simple demonstration how to set date and time on PCF8583
     RTC (real-time clock). The code can be used with any MCU that has MSSP
     module at PORTC.
     The example sets the following:
       TIME: 11:30:00
       DATE: 08/24/2004
     Please refer to PCF8583 datasheet for more information on config. word and
     time format settings.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.000MHz
     Ext. Modules:    RTC module (PCF8583)
     SW:              mikroC v5.0
 * NOTES:
     - In order to use the example, address pin A0 of PCF8583 must be set to 0V!
     - For proper I2C communication, pins on PORTC must be in the pull-up mode,
       and the LEDs on board switched OFF!
 */

void main() {

   TRISB  = 0;
   PORTB = 0xAA;

   I2C_Init(10000);      // initialize full master mode
   I2C_Start();          // issue start signal
   I2C_Wr(0xA0);         // address PCF8583
   I2C_Wr(0);            // start from word at address 0 (configuration word)
   I2C_Wr(0x80);         // write $80 to config. (pause counter...)
   I2C_Wr(0);            // write 0 to cents word
   I2C_Wr(0);            // write 0 to seconds word
   I2C_Wr(0x30);         // write $30 to minutes word
   I2C_Wr(0x11);         // write $11 to hours word
   I2C_Wr(0x24);         // write $24 to year/date word
   I2C_Wr(0x08);         // write $08 to weekday/month
   I2C_Stop();           // issue stop signal

   I2C_Start();          // issue start signal
   I2C_Wr(0xA0);         // address PCF8530
   I2C_Wr(0);            // start from word at address 0
   I2C_Wr(0);            // write 0 to config word (enable counting)
   I2C_Stop();           // issue stop signal
  PORTB = 0xFF;
}//~!




extern const unsigned short
 mikro_test_bmp[1024],
 maska_bmp[1024];


/*
 * Project name:
     Usart_Test (Simple usage of USART module library functions)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This code demonstrates how to use usart library routines. Upon receiving
     data via RS232, PIC MCU immediately sends it back to the sender.
 * Test configura     PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v6.0
 * NOTES:
     None.
*/

unsigned short i;

void main() {
   USART_init(2400);                      // initialize USART module                                   //  (8 bit, 2400 baud rate, no parity bit...
   while (1) {
     if (USART_Data_Ready()) {            // if data is received
       i = USART_Read();                  // read the received data
       USART_Write(i);                    // send data via USART
     }
   }
}//~!



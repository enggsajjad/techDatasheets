/*
 * Project name:
     LED_Blinking (Simple 'Hello World' project)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This is a simple 'Hello World' project. It turns on/off diodes connected to
     PORTC. It uses bitwise negation to toggle PORTB pins.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v6.0
 * NOTES:
     None.
*/

void main() {
  PORTC = 0;
  TRISC = 0;

 while(1) {
    PORTC =  ~PORTC;
    Delay_ms(1000);
  }
} //~!

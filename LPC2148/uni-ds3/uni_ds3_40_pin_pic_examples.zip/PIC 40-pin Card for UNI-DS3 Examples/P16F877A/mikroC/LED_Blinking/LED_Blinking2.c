/*
 * Project name:
     LED_Blinking2 (Simple 'Hello World' project)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This is a simple 'Hello World' project. It turns on/off diodes connected to
     PORTB. It demonstrates the usage of the SWITCH structure to access PORTB
     pins.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v6.0
 * NOTES:
     None.
*/



void main() {
  PORTB = 0;
  TRISB = 0;

  do {
    switch (PORTB) {
      case 0x00: PORTB = 0xFF; break;
      case 0xFF: PORTB = 0x00;
    }
    Delay_ms(1000);
  } while (1);
}//~!


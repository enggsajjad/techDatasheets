

void bre(){
 asm nop;
 asm nop;
}



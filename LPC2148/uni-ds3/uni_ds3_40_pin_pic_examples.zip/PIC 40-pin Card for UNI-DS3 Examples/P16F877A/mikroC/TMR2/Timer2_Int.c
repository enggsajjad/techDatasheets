/*
 * Project name:
     Timer2_Int (Using TMR2 to obtain interrupts)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This code demonstrates using interrupts and TMR2. Program toggles LEDs on
     PORTB and PORTD each second.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v5.0
 * NOTES:
     None.
 */

unsigned short i;

void Toggle() {
  PORTB = ~PORTB;
  PORTD = ~PORTD;
}//~

void interrupt() {
  if (PIR1 & TMR2IF) {
    i++ ;
    PIR1 &= ~(1<<TMR2IF);     // clears TMR2IF
  }
}//~

// main
void main() {
  i = 0;
  PORTB = 0xFF;
  TRISB =   0;
  PORTD = 0x00;
  TRISD =   0;
  T2CON = 0xFF;
  TMR2  =   0;
  PIE1 |= (1 << TMR2IE);      // enable interupt
  INTCON = 0xC0;              // for tmr2

  while (1) {                 // endless loop
    if (i > 30) {
      Toggle();               // toggle values on portb, portd
      i = 0;
    }
  }
}//~!


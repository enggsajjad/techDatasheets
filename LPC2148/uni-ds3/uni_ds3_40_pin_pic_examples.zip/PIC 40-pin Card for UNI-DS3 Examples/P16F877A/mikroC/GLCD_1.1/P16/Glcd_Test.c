/*
 * Project name:
     GLCD_Test (Demonstration of the GLCD library routines)
 * Copyright:
     (c) mikroElektronika, 2005 - 2006
 * Revision History:
     20050422:
       - initial release;
 * Description:
     This is a simple demonstration of the GLCD library routines:
     - Init and Clear (pattern fill)
     - Image display
 * Test configuration:
     MCU:             P16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    GLCD 128x64, KS108/107 controller
     SW:              mikroC v5.0
 * Notes:
     None.
*/

//Declarations------------------------------------------------------------------
#include "bmp1.h"
//--------------------------------------------------------------end-declarations


void delay2S(){
  delay_ms(2000);
}

void main() {
  unsigned short ii;
  unsigned int jj;
  char *someText;

  ADCON1 = 0x07;
  CMCON  = 0x07;


  Glcd_Init(&PORTA, 0,1,2,3,4,5, &PORTD);

  Glcd_Fill(0x00);

  lMainLoop:
  Glcd_Image( maska_bmp );
  Delay2S(); Delay2S();

  Glcd_Fill(0x00);
  Glcd_Line(120,1, 5,60, 1);
  Glcd_Line(12,42, 5,60, 1);
  delay2S();

  Glcd_Rectangle(12,20, 93,57, 1);
  delay2S();

  Glcd_Line(120,12, 12,60, 1);
  delay2S();

  Glcd_H_Line(5,15, 6, 1);
  Glcd_Line(0,12, 120,60, 1);
  Glcd_V_Line(7,63, 127, 1);
  delay2S();

  for (ii = 1; ii <= 10; ii++)
    Glcd_Circle(63,32, 3*ii, 1);
  delay2S();

  Glcd_Box(12,20, 70,57, 2);
  delay2S();

  someText = "BIG:LETTERS";
  Glcd_Write_Text(someText, 5,3, 2);
  delay2S();

  someText = "SMALL:NOT:SMALLER";
  Glcd_Write_Text(someText, 20,5, 1);
  delay2S();
  
  goto lMainLoop;

}//~!


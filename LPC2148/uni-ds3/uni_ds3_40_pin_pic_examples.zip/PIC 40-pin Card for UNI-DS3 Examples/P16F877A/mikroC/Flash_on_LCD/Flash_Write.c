/*
 * Project name:
     Flash_Write (Demonstration of writing to PIC's internal flash memory)
 * Copyright:
     (c) Mikroelektronika, 2005.
 * Description:
     This is a simple demonstration how to use to PIC's internal flash memory to
     store data. The data is being written starting from the given location;
     then, the same locations are read and the data is displayed on PORTB.
 * Test configuration:
     MCU:             PIC16F877A
     Dev.Board:       UNI-DS3
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC v5.0
 * NOTES:
     None.
 */
char i,j;
char *inputData = "MikroElektronika";
unsigned int addr, data[4];

void main() {

  addr = 0x0430;

  Lcd_Config(&PORTD,0,1,3,7,6,5,4); // Initialize LCD connected to PORTD
  LCD_Cmd(LCD_CURSOR_OFF);           // send command to LCD (cursor off)
  LCD_Cmd(LCD_CLEAR);                // send command  to LCD (clear LCD)

  LCD_Out(1,1,"Writing data");

  for (i = 0; i<4; i++){
      for (j = 0; j<4 ; j++){
          data[j] =  inputData[4*i+j];
      }
      Delay_ms(200);
      Flash_Write(addr,data);
      addr+=4;
      Lcd_Chr(1,i+13,'.');
  }
  Delay_ms(1000);
  Lcd_Cmd(LCD_CLEAR);
  LCD_Out(1,1,"Reading data:");

  Delay_ms(500);
  addr = 0x0430;

  for (i=0; i<19; i++){
      LCD_Chr(2,i+1,Flash_Read(addr++));
      Delay_ms(150);
  }
}//~!

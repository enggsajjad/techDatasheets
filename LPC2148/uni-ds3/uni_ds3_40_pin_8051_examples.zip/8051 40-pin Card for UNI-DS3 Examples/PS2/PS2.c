/*
 * Project name:
     PS2 Example (Demonstration on using mikroC's PS/2 keyboard library)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     In this example, key(s) pressed on the PS/2 keyboard are read and transferred
     to PC through USART. Various basic keyboard activities are tested:
     "normal" keys, keys with <Shift> pressed, keys with <Caps Lock>
     pressed, numerical keypad ON/OFF and keys. The result is visible on PC, on
     some common Serial port terminal tool.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS 3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    PS/2 standard 101-keys keyboard, PS2 connector
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - Pins used for PS/2 communication should be connected to pull-up resistors.
     - RX232A and TX232A UART switches on UNI-DS 3 should be turned on.
     - Some keyboards with various multimedia attachments on them (especially the
       cheap ones) tend to "choke" the communication by constantly sending
       requests on various multimedia objects' status (volume, mouse pos. etc.).
       This may slow down the communication pace with the MCU.
 */

char keydata = 0, special = 0, down = 0;
 
// PS2 module connections
sbit PS2_DATA  at P0.B0;
sbit PS2_CLOCK at P0.B1;
// end PS2 module connections

void main() {
  Uart_Init(4800);                                  // initialize UART module at 4800 bps
  Ps2_Config();                                     // initialize PS/2 Keyboard
  Delay_ms(100);                                    // wait for keyboard to finish
  
  do {                                              // endless loop
    if (Ps2_Key_Read(&keydata, &special, &down)) {  // if data was read from PS/2
      if (down && (keydata == 16)) {                // backspace read
        Uart_Write(0x08);                           // send Backspace to usart terminal
        }
      else if (down && (keydata == 13)) {           // Enter read
        Uart_Write('\r');                           // send carriage return to usart terminal
        //Uart_Write('\n');                         // uncomment this line if usart terminal also expects line feed
                                                    //   for new line transition
        }
      else if (down && !special && keydata) {       // common key read
        Uart_Write(keydata);                        // send key to usart terminal
        }
    }
    Delay_ms(10);                                   // debounce period
  } while (1);
}

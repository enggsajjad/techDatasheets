/*
 * Project name:
     Soft_SPI (Driving external Digital-to-Analog converter)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
      This is a sample program which demonstrates the use of the Microchip's
      MCP4921 12-bit D/A converter with 8051 MCUs. This device accepts digital
      input (number from 0..4095) and transforms it to the output voltage,
      ranging from 0..Vref. In this example the DAC communicates with MCU 
      through the Soft_SPI communication.
      Buttons PA.0 and PA.1 are used to change value sent to DAC.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - Connect reference jumper (J15) on UNI-DS3 board to Vcc or 4.096V to
       choose Vref input for MCP4921 DAC.
     - Turn on SPI and DAC-CS switches on UNI-DS3 board.
     - Put button jumper (J10) into GND position and pull-up PORTA.
 */
 
#include <built_in.h>
// DAC module connections
sbit Chip_Select at P1.B2;
sbit SoftSpi_CLK at P1.B7;
sbit SoftSpi_SDI at P1.B6;
sbit SoftSpi_SDO at P1.B5;
// End DAC module connections

unsigned int value;

void InitMain() {
  P0 = 255;                               // Set PORTA as input
  Soft_SPI_Init();                        // Initialize Soft_SPI
  P1.B3 = 0;                              // Set DAC-LD to zero
}
// DAC increments (0..4095) --> output voltage (0..Vref)
void DAC_Output(unsigned int valueDAC) {
 char temp;
 
  Chip_Select = 0;                        // Select DAC chip
  
  // Send High Byte                                         
  temp = (valueDAC >> 8) & 0x0F;          // Store valueDAC[11..8] to temp[3..0]
  temp |= 0x30;                           // Define DAC setting, see MCP4921 datasheet
  Soft_SPI_Write(temp);                   // Send high byte via Soft SPI
  
  // Send Low Byte
  temp = valueDAC;                        // Store valueDAC[7..0] to temp[7..0]
  Soft_SPI_Write(temp);                   // Send low byte via Soft SPI
  
  Chip_Select = 1;                        // Deselect DAC chip
}

void main() {
  InitMain();                             // Perform main initialization
  value = 2048;                           // When program starts, DAC gives
                                          //   the output in the mid-range

  while (1) {                             // Endless loop
    if ((!P0_0)/* && (value < 4095)*/) {  // If PA.0 is connected to GND
      value++;                            //   increment value
      }
      
    else {
      if ((!P0_1) && (value > (int)0)) {  // If PA.1 is connected to GND
        value--;                          //   decrement value
       }
    }
    DAC_Output(value);                    // Perform output
    Delay_ms(10);                         // Slow down key repeat pace
  }
}

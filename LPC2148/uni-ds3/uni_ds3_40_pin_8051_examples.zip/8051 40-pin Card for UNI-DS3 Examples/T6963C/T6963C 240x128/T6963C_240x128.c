/*
 * Project Name:
     T6963C_240x128 (GLCD Library demo for Toshiba's T6369 Controller)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release; Credits to Bruno Gavand.
 * Description:
     This code in intended to work with GLCD's based on TOSHIBA T6963C controller.
     Pressing buttons PORTC.0 .. PORTC.4 generates commands for text and graphic displaying.
     This parts may need a -15V power supply on Vee for LCD drive,
     a simple DC/DC converter can be made with a 2N2905, 220 �H self, diode & 47 �F cap,
     transistor base is driven with PWM thrue a current limiting resistor.
     This parts have a 8 Kb built-in display RAM, this allows 2 graphics panels
     and one text panel.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS 3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    mE T6369C 240x128 Parallel Adapter on PORTB(Data) and PORTA(Control),
                      T6369C display 240x128 pixels
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - Put button jumper (J10) into GND position.
     - Ports used in this example (PORTA, PORTB, PORTC) must be connected to pull-up resistors.
*/

#include        "T6963C.h"
                            
// T6963C module connections
unsigned char sfr   T6963C_dataPort at P0;     // PORTB DATA BUS port
unsigned char sfr   T6963C_ctrlPort at P1;     // PORTA CONTROL port

sbit   T6963C_ctrlwr  at P1.B2;                // WR write signal 
sbit   T6963C_ctrlrd  at P1.B1;                // RD read signal 
sbit   T6963C_ctrlcd  at P1.B0;                // CD command/data signal 
sbit   T6963C_ctrlrst at P1.B4;                // RST reset signal 
// End T6963C module connections

/*                                       
 * bitmap pictures stored in ROM
 */
const code char mc[] ;
const code char einstein[] ;

void main() {
  char idata txt1[] = " EINSTEIN WOULD HAVE LIKED mC";
  char idata txt[] =  " GLCD LIBRARY DEMO, WELCOME !";

  unsigned char  panel ;         // Current panel
  unsigned int   i ;             // General purpose register
  unsigned char  curs ;          // Cursor visibility
  unsigned int   cposx, cposy ;  // Cursor x-y position

  P1 = 0;                        // Clear T6963C ports
  P0 = 0;
  /*
   * init display for 240 pixel width and 128 pixel height
   * 8 bits character width
   * data bus on P0
   * control bus on P1
   * bit 2 is !WR
   * bit 1 is !RD
   * bit 0 is C!D
   * bit 4 is RST
   */

  // Initialize T6369C
  T6963C_init(240, 128, 8) ;

  /*
   * Enable both graphics and text display at the same time
   */
  T6963C_graphics(1) ;
  T6963C_text(1) ;

  panel = 0 ;
  i = 0 ;
  curs = 0 ;
  cposx = cposy = 0 ;

  /*
   * Text messages
   */
  T6963C_write_text(txt, 0, 0, T6963C_ROM_MODE_XOR) ;
  T6963C_write_text(txt1, 0, 15, T6963C_ROM_MODE_XOR) ;

  /*
   * Cursor
   */
  T6963C_cursor_height(8) ;       // 8 pixel height
  T6963C_set_cursor(0, 0) ;       // Move cursor to top left
  T6963C_cursor(0) ;              // Cursor off

  /*
   * Draw rectangles
   */
  T6963C_rectangle(0, 0, 239, 127, T6963C_WHITE) ;
  T6963C_rectangle(20, 20, 219, 107, T6963C_WHITE) ;
  T6963C_rectangle(40, 40, 199, 87, T6963C_WHITE) ;
  T6963C_rectangle(60, 60, 179, 67, T6963C_WHITE) ;

  /*
   * Draw a cross
   */
  T6963C_line(0, 0, 239, 127, T6963C_WHITE) ;
  T6963C_line(0, 127, 239, 0, T6963C_WHITE) ;

  /*
   * Draw solid boxes
   */
  T6963C_box(0, 0, 239, 8, T6963C_WHITE) ;
  T6963C_box(0, 119, 239, 127, T6963C_WHITE) ;

  /*
   * Draw circles
   */
  T6963C_circle(120, 64, 10, T6963C_WHITE) ;
  T6963C_circle(120, 64, 30, T6963C_WHITE) ;
  T6963C_circle(120, 64, 50, T6963C_WHITE) ;
  T6963C_circle(120, 64, 70, T6963C_WHITE) ;
  T6963C_circle(120, 64, 90, T6963C_WHITE) ;
  T6963C_circle(120, 64, 110, T6963C_WHITE) ;
  T6963C_circle(120, 64, 130, T6963C_WHITE) ;

  T6963C_sprite(76, 4, einstein, 88, 119) ;         // Draw a sprite

  T6963C_setGrPanel(1) ;                            // Select other graphic panel

  T6963C_sprite(0, 0, mc, 240, 128) ;               // Fill the graphic screen with a picture


  T6963C_image(mc) ;
  
  for(;;) {                                         // Endless loop
    /*
     * If P2_0 is pressed, toggle the display between graphic panel 0 and graphic 1
     */
    if(!P2_0) {
      panel++ ;
      panel &= 1 ;
      T6963C_displayGrPanel(panel) ;
      Delay_ms(300) ;
      }

    /*
     * If P2_1 is pressed, display only graphic panel
     */
    else if(!P2_1) {
      T6963C_graphics(1) ;
      T6963C_text(0) ;
      Delay_ms(300) ;
      }

    /*
     * If P2_2 is pressed, display only text panel
     */
    else if(!P2_2) {
      T6963C_graphics(0) ;
      T6963C_text(1) ;
      Delay_ms(300) ;
      }

    /*
     * If P2_3 is pressed, display text and graphic panels
     */
    else if(!P2_3) {
      T6963C_graphics(1) ;
      T6963C_text(1) ;
      Delay_ms(300) ;
      }

    /*
     * If P2_4 is pressed, change cursor
     */
    else if(!P2_4) {
      curs++ ;
      if(curs == 3) curs = 0 ;
      switch(curs) {
        case 0:
          // no cursor
          T6963C_cursor(0) ;
          break ;
        case 1:
          // blinking cursor
          T6963C_cursor(1) ;
          T6963C_cursor_blink(1) ;
          break ;
        case 2:
          // non blinking cursor
          T6963C_cursor(1) ;
          T6963C_cursor_blink(0) ;
          break ;
        }
      Delay_ms(300) ;
      }

    /*
     * Move cursor, even if not visible
     */
    cposx++ ;
    if(cposx == T6963C_txtCols) {
      cposx = 0 ;
      cposy++ ;
      if(cposy == T6963C_grHeight / T6963C_CHARACTER_HEIGHT) {
        cposy = 0 ;
        }
      }
    T6963C_set_cursor(cposx, cposy) ;

    Delay_ms(100) ;
    }
}

/*
 * Project name:
     Lcd (Demonstration of the Lcd library routines)
 * Copyright:
     (c) Mikroelektronika, 2008
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This code demonstrates how to use Lcd 4-bit library. Lcd is first
     initialized, then some text is written, then the text is moved.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    Lcd 2x16
     SW:              mikroC for 8051 v1.0
 * NOTES:
     -None.
*/

// Lcd module connections
sbit LCD_RS at P0.B0;
sbit LCD_EN at P0.B1;

sbit LCD_D7 at P0.B7;
sbit LCD_D6 at P0.B6;
sbit LCD_D5 at P0.B5;
sbit LCD_D4 at P0.B4;
// end Lcd module connections

char txt1[] = "mikroElektronika";      // text to be written on Lcd
char txt2[] = "UNI-DS 3";
char txt3[] = "Lcd";
char txt4[] = "example";

char i;                                // loop variable

void Move_Delay() {                    // function used for text moving
  Delay_ms(500);                       // you can change the moving speed here
}

void main(){

    Lcd_Init();                        // initialize Lcd
    Lcd_Cmd(LCD_CLEAR);                // clear display
    Lcd_Cmd(LCD_CURSOR_OFF);           // cursor off

    LCD_Out(1,7,txt3);                 // write text in first row
    LCD_Out(2,5,txt4);                 // write text in second row
    Delay_ms(2000);
    Lcd_Cmd(LCD_CLEAR);                // clear display

    LCD_Out(1,1,txt1);                 // write text in first row
    LCD_Out(2,5,txt2);                 // write text in second row
    Delay_ms(500);

// moving text
    for(i=0; i<4; i++) {               // move text to the right 4 times
      Lcd_Cmd(LCD_SHIFT_RIGHT);
      Move_Delay();
      }

    while(1) {                         // wndless loop
      for(i=0; i<8; i++) {             // move text to the left 7 times
        Lcd_Cmd(LCD_SHIFT_LEFT);
        Move_Delay();
        }

      for(i=0; i<7; i++) {             // move text to the right 7 times
        Lcd_Cmd(LCD_SHIFT_RIGHT);
        Move_Delay();
        }

      }
}

/*
 * Project Name:
     SPI_T6963C_240x128 (SPI_Glcd Library demo for Toshiba's T6369 Controller)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This code in intended to work with Glcd's based on TOSHIBA T6963C
     controller via SPI communication. Pressing buttons PA.0 .. PA.4 generates 
     commands for text and graphic displaying.
     This parts may need a -15V power supply on Vee for LCD drive,
     a simple DC/DC converter can be made with a 2N2905, 220 �H self, diode & 47 �F cap,
     transistor base is driven with PWM thrue a current limiting resistor.
     This parts have a 8 Kb built-in display RAM, this allows 2 graphics panels
     and one text panel.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS 3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    mE Serial Glcd Adapter 240x128 on PORTB, T6369C display 240x128 pixels
     SW:              mikroC for 8051 v1.0
 * NOTES:
      - Put button jumper (J10) into GND position and pull-up PORTB.
 */
 
#include        "Spi_T6963C.h"

/*
 * bitmap pictures stored in ROM
 */
extern const code char mc[] ;
extern const code char einstein[] ;

// Port Expander module connections
sbit  SPExpanderRST at P1.B0;
sbit  SPExpanderCS  at P1.B1;
// End Port Expander module connections

void main() {
  
 char idata txt1[] = " EINSTEIN WOULD HAVE LIKED mC";
 char idata txt[] =  " GLCD LIBRARY DEMO, WELCOME !";
 
 unsigned char   panel ;         // current panel
 unsigned int    i ;             // general purpose register
 unsigned char   curs ;          // cursor visibility
 unsigned int    cposx, cposy ;  // cursor x-y position
  
  P0 = 255;                      // Configure PORTA as input
  
  /*
   * init display for 240 pixel width and 128 pixel height
   * 8 bits character width
   * data bus on MCP23S17 portB
   * control bus on MCP23S17 portB
   * bit 2 is !WR
   * bit 1 is !RD
   * bit 0 is !CD
   * bit 4 is RST
   *
   * chip enable, reverse on, 8x8 font internaly set in library
   */
  
  // Initialize SPI module 
  Spi_Init_Advanced(MASTER_OSC_DIV4 | CLK_IDLE_LOW | IDLE_2_ACTIVE | DATA_ORDER_MSB);
  // Initialize SPI Toshiba 240x128
  Spi_T6963C_Config(240, 128, 8, 0, 2, 1, 0, 4) ;

  /*
   * Enable both graphics and text display at the same time
   */
  Spi_T6963C_graphics(1) ;
  Spi_T6963C_text(1) ;
  
  panel = 0 ;
  i = 0 ;
  curs = 0 ;
  cposx = cposy = 0 ;
  
  /*
   * Text messages
   */
  Spi_T6963C_write_text(txt, 0, 0, Spi_T6963C_ROM_MODE_XOR) ;
  Spi_T6963C_write_text(txt1, 0, 15, Spi_T6963C_ROM_MODE_XOR) ;
  
  /*
   * Cursor
   */
  Spi_T6963C_cursor_height(8) ;       // 8 pixel height
  Spi_T6963C_set_cursor(0, 0) ;       // move cursor to top left
  Spi_T6963C_cursor(0) ;              // cursor off
  
  /*
   * Draw rectangles
   */
  Spi_T6963C_rectangle(0, 0, 239, 127, Spi_T6963C_WHITE) ;
  Spi_T6963C_rectangle(20, 20, 219, 107, Spi_T6963C_WHITE) ;
  Spi_T6963C_rectangle(40, 40, 199, 87, Spi_T6963C_WHITE) ;
  Spi_T6963C_rectangle(60, 60, 179, 67, Spi_T6963C_WHITE) ;
  
  /*
   * Draw a cross
   */
  Spi_T6963C_line(0, 0, 239, 127, Spi_T6963C_WHITE) ;
  Spi_T6963C_line(0, 127, 239, 0, Spi_T6963C_WHITE) ;
  
  /*
   * Draw solid boxes
   */
  Spi_T6963C_box(0, 0, 239, 8, Spi_T6963C_WHITE) ;
  Spi_T6963C_box(0, 119, 239, 127, Spi_T6963C_WHITE) ;
  
  /*
   * Draw circles
   */
  Spi_T6963C_circle(120, 64, 10, Spi_T6963C_WHITE) ;
  Spi_T6963C_circle(120, 64, 30, Spi_T6963C_WHITE) ;
  Spi_T6963C_circle(120, 64, 50, Spi_T6963C_WHITE) ;
  Spi_T6963C_circle(120, 64, 70, Spi_T6963C_WHITE) ;
  Spi_T6963C_circle(120, 64, 90, Spi_T6963C_WHITE) ;
  Spi_T6963C_circle(120, 64, 110, Spi_T6963C_WHITE) ;
  Spi_T6963C_circle(120, 64, 130, Spi_T6963C_WHITE) ;
  
  Spi_T6963C_sprite(76, 4, einstein, 88, 119) ;  // Draw a sprite
  
  Spi_T6963C_setGrPanel(1) ;                     // Select other graphic panel
  
  Spi_T6963C_image(mc) ;                         // Fill the graphic screen with a picture
  
  for(;;) {                                      // Endless loop
  
    /*
     * If P0_0 is pressed, toggle the display between graphic panel 0 and graphic 1
     */
    if(!P0_0) {
      panel++ ;
      panel &= 1 ;
      Spi_T6963C_displayGrPanel(panel) ;
      Delay_ms(300) ;
      }
  
    /*
     * If P0_1 is pressed, display only graphic panel
     */
    else if(!P0_1) {
      Spi_T6963C_graphics(1) ;
      Spi_T6963C_text(0) ;
      Delay_ms(300) ;
      }
  
    /*
     * If P0_2 is pressed, display only text panel
     */
    else if(!P0_2) {
      Spi_T6963C_graphics(0) ;
      Spi_T6963C_text(1) ;
      Delay_ms(300) ;
      }
  
    /*
     * If P0_3 is pressed, display text and graphic panels
     */
    else if(!P0_3) {
      Spi_T6963C_graphics(1) ;
      Spi_T6963C_text(1) ;
      Delay_ms(300) ;
      }
  
    /*
     * If P0_4 is pressed, change cursor
     */
    else if(!P0_4) {
      curs++ ;
      if(curs == 3) curs = 0 ;
      switch(curs) {
        case 0:
          // no cursor
          Spi_T6963C_cursor(0) ;
          break ;
        case 1:
          // blinking cursor
          Spi_T6963C_cursor(1) ;
          Spi_T6963C_cursor_blink(1) ;
          break ;
        case 2:
          // non blinking cursor
          Spi_T6963C_cursor(1) ;
          Spi_T6963C_cursor_blink(0) ;
          break ;
        }
      Delay_ms(300) ;
      }
  
    /*
     * Move cursor, even if not visible
     */
    cposx++ ;
    if(cposx == Spi_T6963C_txtCols) {
      cposx = 0 ;
      cposy++ ;
      if(cposy == Spi_T6963C_grHeight / Spi_T6963C_CHARACTER_HEIGHT) {
        cposy = 0 ;
        }
      }
    Spi_T6963C_set_cursor(cposx, cposy) ;
  
    Delay_ms(100) ;
    }
  }

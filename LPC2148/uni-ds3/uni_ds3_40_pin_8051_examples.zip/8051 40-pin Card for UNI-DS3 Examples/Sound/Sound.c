/*
 * Project name:
     Sound (Usage of Sound library)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This project is a simple demonstration of how to use Sound Library 
     for playing tones on a piezo speaker. Pressing buttons PB.7 .. PB.3
     generates commands for playing sounds and melodies.      
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    Piezo speaker
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - Put button jumper (J10) into GND position and pull-up PORTA.
*/

// Sound connections
sbit Sound_Play_Pin at P0.B3;                // Sound Play Pin at PORTA.3
// End Sound connections


void Tone1() {
  Sound_Play(500, 200);                      // Frequency = 500Hz, Duration = 200ms
}

void Tone2() {
  Sound_Play(555, 200);                      // Frequency = 555Hz, Duration = 200ms
}

void Tone3() {
  Sound_Play(625, 200);                      // Frequency = 625Hz, Duration = 200ms
}

void Melody() {                              // Plays the melody "Yellow house"
  Tone1(); Tone2(); Tone3(); Tone3();
  Tone1(); Tone2(); Tone3(); Tone3();
  Tone1(); Tone2(); Tone3();
  Tone1(); Tone2(); Tone3(); Tone3();
  Tone1(); Tone2(); Tone3();
  Tone3(); Tone3(); Tone2(); Tone2(); Tone1();
}

void ToneA() {                  // Tones used in Melody2 function
  Sound_Play(1250, 20);
}
void ToneC() {
  Sound_Play(1450, 20);
}
void ToneE() {
  Sound_Play(1650, 80);
}

void Melody2() {                // Plays Melody2
 unsigned short i;
  for (i = 9; i > 0; i--) {
    ToneA(); 
    ToneC(); 
    ToneE();
    }
}

unsigned ww, ttl; volatile;


void main() {
   ww = 5000;
   asm nop;
   ttl = ww % 10;
  P1 = 255;                     // Configure PORTB as input
  Sound_Init();                 // Initialize sound pin
  
  Sound_Play(2000, 1000);       // Play starting sound, 2kHz, 1 second

  while (1) {                   // endless loop
  
    if (!(P1_7))                // If PORTB.7 is pressed play Tone1
      Tone1();                  // 
    while (!(P1_7)) ;           // Wait for button to be released

    if (!(P1_6))                // If PORTB.6 is pressed play Tone2
      Tone2();                  //
    while (!(P1_6)) ;           // Wait for button to be released

    if (!(P1_5))                // If PORTB.5 is pressed play Tone3
      Tone3();                  //
    while (!(P1_5)) ;           // Wait for button to be released

    if (!(P1_4))                // If PORTB.4 is pressed play Melody2
      Melody2();                //
    while (!(P1_4)) ;           // Wait for button to be released

    if (!(P1_3))                // If PORTB.3 is pressed play Melody
      Melody();                 //
    while (!(P1_3)) ;           // Wait for button to be released
  }
}

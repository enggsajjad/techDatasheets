/*
 * Project name:
     Glcd_Test (Demonstration of the Glcd library routines)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This is a simple demonstration of the Glcd library routines:
     - Init and Clear (pattern fill)
     - Image display
     - Basic geometry - lines, circles, boxes and rectangles
     - Text display and handling
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    Glcd 128x64, KS108/107 controller
     SW:              mikroC for 8051 v1.0
 * Notes:
     - Ports used in this example must be connected to pull-up resistors.
*/

//declarations------------------------------------------------------------------
const code char advanced8051_bmp[1024];
//--------------------------------------------------------------end-declarations

// Glcd module connections
sfr char GLCD_DataPort at P0;               // Glcd data port
                                                                                                                
sbit GLCD_CS1 at P2.B2;                     // Glcd chip select 1 signal
sbit GLCD_CS2 at P2.B3;                     // Glcd chip select 2 signal
sbit GLCD_RS  at P2.B4;                     // Glcd register select signal
sbit GLCD_RW  at P2.B5;                     // Glcd read/write signal
sbit GLCD_EN  at P2.B6;                     // Glcd enable signal
sbit GLCD_RST at P2.B7;                     // Glcd reset signal
// end Glcd module connections

void delay2S(){                             // 2 seconds delay function
  delay_ms(2000);
}                 

void main() {                       
  unsigned short ii;                      
  char *someText;

  Glcd_Init();                              // initialize Glcd
  Glcd_Fill(0x00);                          // clear Glcd

  while(1) {
    Glcd_Image(advanced8051_bmp);           // draw image
    delay2S(); delay2S();

    Glcd_Fill(0x00);

    Glcd_Box(62,40,124,56,1);               // draw box
    Glcd_Rectangle(5,5,84,35,1);            // draw rectangle
    Glcd_Line(0, 63, 127, 0,1);             // draw line

    delay2S();

    for(ii = 5; ii < 60; ii+=5 ){           // draw horizontal and vertical lines
      Delay_ms(250);
      Glcd_V_Line(2, 54, ii, 1);
      Glcd_H_Line(2, 120, ii, 1);
      }

    delay2S();

    Glcd_Fill(0x00);
    
    Glcd_Set_Font(Character8x8, 8, 8, 32);  // choose font, see __Lib_GLCDFonts.c in Uses folder
    Glcd_Write_Text("mikroE", 5, 7, 2);     // write string

    for (ii = 1; ii <= 10; ii++)            // draw circles
      Glcd_Circle(63,32, 3*ii, 1);
    delay2S();

    Glcd_Box(12,20, 70,57, 2);              // draw box
    delay2S();

    Glcd_Set_Font(FontSystem5x8, 5, 8, 32); // change font
    someText = "BIG:ONE";                   
    Glcd_Write_Text(someText, 5,3, 2);      // write string
    delay2S();

    someText = "SMALL:NOT:SMALLER";
    Glcd_Write_Text(someText, 20,5, 1);     // write string
    delay2S();

  }

}

/*
 * Project name:
     LED_Blinking (Simple 'Hello World' project)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This is a simple 'Hello World' project. It turns on/off diodes connected to
     PORT0, PORT1, PORT2 and PORT3. 
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC for 8051 v1.0
 * NOTES:
     None.
*/

void main() {
  do {        
    P0 = 0x00;        // Turn ON diodes on PORTA
    P1 = 0x00;        // Turn ON diodes on PORTB
    P2 = 0x00;        // Turn ON diodes on PORTC
    P3 = 0x00;        // Turn ON diodes on PORTD
    Delay_ms(1000);   // 1 second delay
    P0 = 0xFF;        // Turn OFF diodes on PORTA
    P1 = 0xFF;        // Turn OFF diodes on PORTB
    P2 = 0xFF;        // Turn OFF diodes on PORTC
    P3 = 0xFF;        // Turn OFF diodes on PORTD
    Delay_ms(1000);   // 1 second delay

  } while(1);         // Endless loop
}

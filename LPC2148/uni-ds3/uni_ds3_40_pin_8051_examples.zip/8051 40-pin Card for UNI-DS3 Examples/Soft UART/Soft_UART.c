/*
 * Project name:
     Soft_UART (Demonstration of using Soft UART library routines) 
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This code demonstrates how to use software uart library routines. 
     Upon receiving data via RS232, 8051 MCU immediately sends it back to the sender.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS 3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - RX232A and TX232B UART switches on UNI-DS 3 should be turned On.
*/

// Soft UART connections
sbit  Soft_Uart_RX at P3.B0;
sbit  Soft_Uart_TX at P3.B1;
// end Soft UART connections

char i, error, byte_read;                 // auxiliary variables

void main(){

  Soft_Uart_Init(4800, 0);                // initialize Soft UART at 4800 bps
  for (i = 'z'; i >= 'A'; i--) {          // send bytes from 'z' downto 'A'
    Soft_Uart_Write(i);
    Delay_ms(100);
    }    
   
  while(1) {                              // endless loop
    byte_read = Soft_Uart_Read(&error);   // read byte, then test error flag
    if (error)                            // if error was detected
      P0 = 0xAA;                          //   signal it on PORT0                             
    else
      Soft_Uart_Write(byte_read);         // if error was not detected, return byte read
    }      
}

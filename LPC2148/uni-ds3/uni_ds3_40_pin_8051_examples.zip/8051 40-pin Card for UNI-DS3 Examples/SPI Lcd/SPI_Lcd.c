/*
 * Project name:
     Spi_Lcd (Simple demonstration of the SPI LCD 4-bit Library functions)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This is a simple demonstration of SPI LCD 4-bit library functions.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    mE Serial Lcd Adapter, LCD 2x16 on PORTB
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - None.
*/

char *text = "mikroElektronika";

// Port Expander module connections
sbit  SPExpanderRST at P1.B0;
sbit  SPExpanderCS  at P1.B1;
// End Port Expander module connections

void main() {
  Spi_Init();                   // Initialize SPI
  Spi_Lcd_Config(0);            // Initialize LCD over SPI interface
  Spi_Lcd_Cmd(LCD_CLEAR);       // Clear display
  Spi_Lcd_Cmd(LCD_CURSOR_OFF);  // Turn cursor off
  Spi_Lcd_Out(1,6, "mikroE");   // Print text to LCD, 1st row, 6th column
  Spi_Lcd_Chr_CP('!');          // Append '!'
  Spi_Lcd_Out(2,1, text);       // Print text to LCD, 2nd row, 1st column
  Spi_Lcd_Out(3,1,"mikroE");    // For LCD with more than two rows
  Spi_Lcd_Out(4,15,"mikroE");   // For LCD with more than two rows
}

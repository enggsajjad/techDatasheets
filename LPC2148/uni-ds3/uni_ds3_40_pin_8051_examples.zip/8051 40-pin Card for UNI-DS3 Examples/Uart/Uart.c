/*
 * Project name:
     UART (Simple usage of UART module library functions)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This code demonstrates how to use uart library routines. Upon receiving
     data via RS232, 8051 MCU immediately sends it back to the sender.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS 3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    -                                                                          
     SW:              mikroC for 8051 v1.0                                                             
 * NOTES:
     - RX232A and TX232A UART switches on UNI-DS 3 should be turned on.
*/

char uart_rd;

void main() {

  Uart_init(4800);              // initialize UART module at 4800 bps
  Delay_ms(100);                // wait for UART module to stabilize
  
  while(1) {                    // endless loop
   if (Uart_Data_Ready()) {     // check if UART module has received data
      uart_rd = Uart_Read();    // read data
      Uart_Write(uart_rd);      // send the same data back
      }
   }
}

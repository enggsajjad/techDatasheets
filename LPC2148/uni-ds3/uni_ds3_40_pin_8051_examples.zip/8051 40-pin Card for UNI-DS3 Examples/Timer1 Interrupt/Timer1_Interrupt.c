/*
 * Project name:
     Timer1_Interrupt (Using TMR1 to obtain interrupts)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This code demonstrates how to use Timer1 and it's interrupt. 
     Program toggles LEDs on PORTA on each Timer1 interrupt.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS 3.
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - Turn on PORTA LEDs.
     - Ports used in this example must be connected to pull-up resistors.
*/

// interrupt handler routine
void Timer1InterruptHandler() org 0x1B{

  EA  = 0;           // clear global interrupt enable flag
  TR1 = 0;           // stop Timer1
  TH1 = 0x00;        // reset Timer1 high byte
  TL1 = 0x00;        // reset Timer1 low byte
  P0  = ~P0;         // toggle PORTA
  EA  = 1;           // set global interrupt enable flag
  TR1 = 1;           // run Timer1
}

void main() {
 
  P0  = 0;           // initialize PORTA
  TF1 = 0;           // ensure that Timer1 interrupt flag is cleared
  ET1 = 1;           // enable Timer1 interrupt
  EA  = 1;           // set global interrupt enable
    
  TMOD.T1_GATE = 0;  // clear this flag to enable Timer1 whenever TR1 bit is set.
  TMOD.T1_CT   = 0;  // set Timer operation: Timer1 counts the divided-down systam clock.
  TMOD.T1_M1   = 0;  // M1_M0 = 01    =>   Mode 1(16-bit Timer/Counter) 
  TMOD.T1_M0   = 1;   

  TR1 = 0;           // turn off Timer1
  TH1 = 0x00;        // set Timer1 high byte
  TL1 = 0x00;        // set Timer1 low byte
  TR1 = 1;           // run Timer1
}

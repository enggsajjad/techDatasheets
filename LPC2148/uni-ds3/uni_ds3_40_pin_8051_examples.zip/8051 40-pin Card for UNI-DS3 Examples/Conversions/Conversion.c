/*
 * Project name:
     Conversions
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This program demonstrates usage of mikroC Conversion library routines. 
     Compile and run the code through software simulator.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS 3
     Oscillator:      10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - None.
*/

char res;
int result;

void main() {
  char txt[14];

  ByteToStr(234,txt);
  WordToStr(432,txt);
  WordToStr(5679,txt);
  WordToStr(0xFFFF,txt);
  ShortToStr(12,txt);
  ShortToStr(-1,txt);
  ShortToStr(-127,txt);
  IntToStr(1224,txt);
  IntToStr(-1,txt);
  IntToStr(-12787,txt);
  LongWordToStr(12,txt);
  LongWordToStr(0xFFFFFFFF,txt);
  LongToStr(12,txt);
  LongToStr(-1,txt);
  LongToStr(0x7FFFFFFF,txt);
  FloatToStr(123.567,txt);
  FloatToStr(-123.567,txt);
  FloatToStr(14.67e12,txt);                                                
  FloatToStr(89.77e-5,txt);
  FloatToStr(-14.67e12,txt);
  FloatToStr(-89.77e-5,txt);
  res  = Dec2Bcd(23);
  result = Dec2Bcd16(4325);
  result = Bcd2Dec16(0x4325);

}

/*
 * Project name:
     SPI (Demonstration of SPI Library usage)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This code demonstrates using library routines for SPI communication for
     working with MAX7219. MAX7219 controls eight 7 segment displays on 
     mikroElektronika's Serial 7-seg Display2 extra board.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS 3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    mE Serial 7-seg Display2 board on PORT1
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - In order to make this example work properly, you should
       consider using external power supply
 */
 
// Serial 7-seg Display connections
sbit CHIP_SEL at P1.B0;    // chip Select pin definition
// end Serial 7-seg Display connections

void Select_max() {        // function for selecting MAX7219
  CHIP_SEL = 0;      
  Delay_us(1);
}

void Deselect_max() {      // function for deselecting MAX7219
  Delay_us(1);
  CHIP_SEL = 1;      
}

void Max7219_init() {      // initializing MAX7219
  Select_max();
  Spi_Write(0x09);         // BCD mode for digit decoding
  Spi_Write(0xFF);
  Deselect_max();

  Select_max();
  Spi_Write(0x0A);
  Spi_Write(0x0F);         // segment luminosity intensity
  Deselect_max();

  Select_max();
  Spi_Write(0x0B);
  Spi_Write(0x07);         // display refresh
  Deselect_max();

  Select_max();
  Spi_Write(0x0C);
  Spi_Write(0x01);         // turn on the display
  Deselect_max();

  Select_max();
  Spi_Write(0x00);
  Spi_Write(0xFF);         // no test
  Deselect_max();
}

char digit_position, digit_value; 

void main() {

  Spi_Init();   // initialize SPI module, standard configuration
                // instead of SPI_init, you can use SPI_init_Advanced as shown below
                //   Spi_Init_Advanced(MASTER_OSC_DIV4 | DATA_ORDER_MSB | CLK_IDLE_LOW | IDLE_2_ACTIVE);
                           
  Max7219_init();                                              // initialize  max7219

  while(1) {                                                   // endless loop
    for (digit_value=0; digit_value<=9; digit_value++) {
      for (digit_position=8; digit_position>=1; digit_position--) {
        Select_max();                                          // select max7219
        Spi_Write(digit_position);                             // send digit position
        Spi_Write(digit_value);                                // send digit value
        Deselect_max();                                        // deselect max7219
        Delay_ms(300);
      }
    }
  }
}

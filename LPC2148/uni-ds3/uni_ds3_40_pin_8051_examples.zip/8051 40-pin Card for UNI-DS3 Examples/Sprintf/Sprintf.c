/*
 * Project name:
     Sprintf  
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This is a demonstration of the standard C library sprintf routine usage.
     Three different representations of the same floating poing number obtained 
     by using the sprintf routine are sent via UART.        
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - RX and TX UART switches on UNI-DS3 should be turned On.
 */

double ww = -1.2587538e+1;
char  buffer[15];

// Function for sending string to UART 
void UartWriteText(char *txt) {
  while(*txt)
    Uart_Write(*txt++);     
}

// Function for sending const string to UART
void UartWriteConstText(const char *txt) {
  while(*txt)
    Uart_Write(*txt++);
}

void main(){

  Uart_Init(4800);                         // Initialize UART module at 4800 bps
  Delay_ms(10);    
  
  UartWriteConstText("Floating point number representation"); // Write message on UART

  sprintf(buffer, "%12e", ww);             // Format ww and store it to buffer
  UartWriteConstText("\r\ne format:");     // Write message on UART
  UartWriteText(buffer);                   // Write buffer on UART

  sprintf(buffer, "%12f", ww);             // Format ww and store it to buffer
  UartWriteConstText("\r\nf format:");     // Write message on UART
  UartWriteText(buffer);                   // Write buffer on UART
  
  sprintf(buffer, "%12g", ww);             // Format ww and store it to buffer
  UartWriteConstText("\r\ng format:");     // Write message on UART
  UartWriteText(buffer);                   // Write buffer on UART
}

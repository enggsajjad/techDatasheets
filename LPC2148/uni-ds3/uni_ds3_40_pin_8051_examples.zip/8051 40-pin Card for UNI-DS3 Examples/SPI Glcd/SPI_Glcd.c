/*
 * Project name:
     SPI_Glcd (Demonstration of using Spi_Glcd Library)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This is a simple demonstration of the serial Glcd library routines:
     - Init and Clear (pattern fill)
     - Image display
     - Drawing shapes
     - Writing text           
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS 3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    Serial Lcd/Glcd adapter on PORTB, Glcd 128x64(KS108/107 controller)
     SW:              mikroC for 8051 v1.0
 * Notes:
     - Ports used in this example must be connected to pull-up resistors.
*/

const code char advanced8051_bmp[];

// Port Expander module connections
sbit  SPExpanderRST at P1.B0;
sbit  SPExpanderCS  at P1.B1;
// end Port Expander module connections

void Delay2S(){                         // 2 seconds delay function
  Delay_ms(2000);
}

void main() {
  unsigned short ii;
  unsigned int jj;
  char *someText;

  // initialize SPI module
  Spi_Init_Advanced(MASTER_OSC_DIV4 | CLK_IDLE_LOW | IDLE_2_ACTIVE | DATA_ORDER_MSB);

  Spi_Glcd_Init(0);                             // initialize GLCD via SPI
  Spi_Glcd_Fill(0x00);                          // clear Glcd

  while(1) {
    Spi_Glcd_Image(advanced8051_bmp);           // draw image
    Delay2S(); Delay2S();

    Spi_Glcd_Fill(0x0);

    Spi_Glcd_Box(62,40,124,56,1);               // draw box
    Spi_Glcd_Rectangle(5,5,84,35,1);            // draw rectangle
    Spi_Glcd_Line(0, 63, 127, 0,1);             // draw line

    Delay2S();

    for(ii = 5; ii < 60; ii+=5 ) {              // draw horizontal and vertical line
      delay_ms(250);
      Spi_Glcd_V_Line(2, 54, ii, 1);
      Spi_Glcd_H_Line(2, 120, ii, 1);
      }

    Delay2S();

    Spi_Glcd_Fill(0x00);

    Spi_Glcd_Set_Font(Character8x8, 8, 8, 32);  // choose font, see __Lib_GlcdFonts.c in Uses folder
    Spi_Glcd_Write_Text("mikroE", 5, 7, 2);     // write string

    for (ii = 1; ii <= 10; ii++)                // draw circles
      Spi_Glcd_Circle(63,32, 3*ii, 1);
    Delay2S();

    Spi_Glcd_Box(12,20, 70,57, 2);              // draw box
    Delay2S();

    Spi_Glcd_Set_Font(FontSystem5x8, 5, 8, 32); // change font
    someText = "BIG:LETTERS";
    Spi_Glcd_Write_Text(someText, 5, 3, 2);     // write string
    Delay2S();

    someText = "SMALL:NOT:SMALLER";
    Spi_Glcd_Write_Text(someText, 20,5, 1);     // write string
    Delay2S();
    }

}

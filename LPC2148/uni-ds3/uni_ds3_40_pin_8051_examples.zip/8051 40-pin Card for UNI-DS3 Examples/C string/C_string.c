/*
 * Project name:
     C_string
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This program demonstrates usage of standard C string library routines. 
     Compile and run the code through software simulator.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - None.
*/

char *res;
int result;

void main(){
  char txt[] = "mikroelektronika";
  char txt_sub[10] = "mikr";

  /* memchr */
  res =  memchr(txt, 'e', 16);
  res =  memchr(txt, 'e', 5);

  /* memcmp */
  result =  memcmp(txt, txt_sub, 16);
  result =  memcmp(txt, txt_sub, 4);

  /* memcpy */
  res = memcpy(txt+4, txt_sub, 4);
  res = memcpy(txt+4, txt_sub, 2);

  /* memmove */
  res = memmove(txt+4, txt_sub, 4);
  res = memmove(txt+4, txt_sub, 2);

  /* memset */
  memset(txt_sub+5,'a',2);
      
  /* strcat */
  txt_sub[3] = 0;
  strcat(txt_sub,"_proba");

  /* strchr */
  res =  strchr(txt_sub, 'p');

  /* strcmp */
  result = strcmp(txt,txt_sub);

  /* strcpy */
  res = strcpy(txt, txt_sub);

  /* strlen - Returns length of given (null-terminated) string */
  result = strlen(txt);

  /* strncat */
  txt[3] = 0;
  txt_sub[4] = 0;
  res = strncat(txt,txt_sub,8);
  txt[3] = 0;
  res = strncat(txt,txt_sub,2);

  /* strncpy */
  txt_sub[4] = 0;
  res = strncpy(txt,txt_sub,8);

  /* strspn */
  result = strspn(txt,txt_sub);

  /* strcspn */
  result = strcspn(txt_sub,txt);
  result = strcspn(txt_sub,"dxc");

  /* strncmp */
  result =  strncmp(txt_sub,txt,3);
  result =  strncmp(txt_sub,txt,6);
  
  /* strpbrk */
  res =  strpbrk(txt_sub,txt);
  res =  strpbrk(txt_sub,txt);

  /* strrchr */
  res =  strrchr(txt_sub,'p');
  res =  strrchr(txt_sub,'k');

  /* strstr */
  res =  strstr(txt_sub,txt);
  txt[2] = 'P';
  res =  strstr(txt_sub,txt);

}

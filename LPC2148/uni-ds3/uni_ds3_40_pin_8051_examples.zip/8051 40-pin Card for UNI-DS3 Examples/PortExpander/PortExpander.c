/*
 * Project name:
     PortExpander (Demonstration of the Port Expander library routines)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This project is simple demonstration how to use Port Expander Library functions.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    mE Port Expander board on PORTB
     SW:              mikroC for 8051 v1.0
 * NOTES:
     None
 */

unsigned char i=0;

// Port Expander module connections
sbit  SPExpanderRST at P1.B0;
sbit  SPExpanderCS  at P1.B1;
// End Port Expander module connections

void main(){

  Spi_Init();                                 // Initialize SPI module

  Expander_Init(0);                           // Initialize Port Expander

  Expander_Set_DirectionPortA(0, 0x00);       // Set Expander's PORTA to be output

  Expander_Set_DirectionPortB(0,0xFF);        // Set Expander's PORTB to be input
  Expander_Set_PullUpsPortB(0,0xFF);          // Set pull-ups to all of the Expander's PORTB pins
  
  while(1) {                                  // Endless loop
    Expander_Write_PortA(0, i++);             // Write i to expander's PORTA
    P0 = Expander_Read_PortB(0);              // Read expander's PORTB and write it to PORTA
    Delay_ms(100);
    }
}

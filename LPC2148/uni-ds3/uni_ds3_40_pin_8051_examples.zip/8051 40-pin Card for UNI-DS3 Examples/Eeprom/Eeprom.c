/*
 * Project name:
     Eeprom (Demonstration of using EEPROM Library) 
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This is a demonstration of using library functions for handling of the
     8051's internal EEPROM module. First, some data is written to EEPROM 
     in byte and block mode; then the data is read from the same locations and 
     displayed on P0, P1 and P2.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - None.
*/

char dat[32], ii;                      // Data buffer, loop variable

void main(){
   for(ii = 31; dat[ii] = ii; ii--)    // Fill data buffer
     ;

   Eeprom_Write(2,0xAA);               // Write some data at address 2
   Eeprom_Write(0x732,0x55);           // Write some data at address 0x732
   Eeprom_Write_Block(0x100,dat);      // Write 32 bytes block at address 0x100

   Delay_ms(1000);                     // Blink P0 and P1 diodes
   P0 = 0xFF;                          //   to indicate reading start 
   P1 = 0xFF;
   Delay_ms(1000);
   P0 = 0x00;
   P1 = 0x00;
   Delay_ms(1000);

   P0 = Eeprom_Read(2);                // Read data from address 2 and display it on PORT0
   P1 = Eeprom_Read(0x732);            // Read data from address 0x732 and display it on PORT1
   Delay_ms(1000);

   for(ii = 0; ii < 32; ii++) {        // Read 32 bytes block from address 0x100 
     P2 = Eeprom_Read(0x100+ii);       //   and display data on PORT2
     Delay_ms(500);
     }
}

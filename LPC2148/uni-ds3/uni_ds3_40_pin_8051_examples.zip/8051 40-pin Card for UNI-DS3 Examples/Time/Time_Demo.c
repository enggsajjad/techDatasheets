/*
 * Project Name:
     Time_Demo (simplified c-like time library for 8051 MCU)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release; Author: Bruno Gavand.
 * Description  :
     Just run it in watch window and watch appropriate variables.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC for 8051 v1.0
 * NOTES:
     None.
 */

#include        "timelib.h"

TimeStruct ts1, ts2 ;
long epoch ;
long diff ;
        
void main() {
  ts1.ss = 0 ;
  ts1.mn = 7 ;
  ts1.hh = 17 ;
  ts1.md = 23 ;
  ts1.mo = 5 ;
  ts1.yy = 2006 ;

  /*
   * What is the epoch of the date in ts ?
   */
  epoch = Time_dateToEpoch(&ts1) ;


  /*
   * What date is epoch 1234567890 ?
   */
  epoch = 1234567890 ;
  Time_epochToDate(epoch, &ts2) ;

  /*
   * How much seconds between this two dates ?
   */
  diff = Time_dateDiff(&ts1, &ts2) ;
}

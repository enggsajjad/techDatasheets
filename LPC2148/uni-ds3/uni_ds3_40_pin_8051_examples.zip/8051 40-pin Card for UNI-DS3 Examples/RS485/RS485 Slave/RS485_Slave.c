/*
 * Project name:
     RS485_Slave (RS485 Library demo - Slave side)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This is a simple demonstration on how to use the mikroC for 8051 RS485 library.
     It is being used in pair with the Rs485_Master example project. Slave (this
     machine) initializes itself (on address 160) and waits to receive data from
     the Master. Then it increments the first byte of received data and sends it
     back to the Master. The data received is shown on PORTA, Error on receive
     (0xAA) is shown on PORTB.
     Several situations are shown here:
       - RS485 Slave Init sequence;
       - Data sending slave-to-master;
     Also shown here, but not strictly related to RS485 library, is:
       - Function calling from the interrupt routine - mikroC for 8051 limited 
         reentrancy support.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    None.
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - Turn on RS-485 lines on SW4.
     - Be careful to initialize the UART module before performing RS485 init.
*/

char dat[9];                         // Buffer for receving/sending messages
char i,j;

// RS485 module connections
sbit rs485_transceive at P3.B7;      // Transmit/Receive control set to P3.7
// End RS485 module connections

//-------------- Interrupt routine
void UartRxHandler() org 0x23 {
  EA = 0;                            // Clear global interrupt enable flag
  if(RI) {                           // Test UART receive interrupt flag
    Rs485slave_Receive(dat);         // UART receive interrupt detected,
                                     //   receive data using RS485 communication
    RI = 0;                          // Clear UART interrupt flag
  }
  EA = 1;                            // Set global interrupt enable flag
}

void main(){
  P0 = 0x00;                         // Clear ports
  P1 = 0x00;

  Uart_Init(9600);                   // Initialize UART module at 9600 bps
  Delay_ms(100);
  Rs485slave_Init(160);              // Intialize MCU as slave, address 160
  dat[4] = 0;                        // ensure that message received flag is 0
  dat[5] = 0;                        // ensure that error flag is 0

  ES = 1;                            // Enable UART interrupt
  RI = 0;                            // Clear UART RX interrupt flag
  EA = 1;                            // Enable interrupts

  while (1){                         // Endless loop

                                     // Upon completed valid message receiving
                                     //   data[4] is set to 255

    if (dat[5])  {                   // If error detected, signal it by
      P1 = 0xAA;                     //   setting PORTB to 0xAA
      }

    if (dat[4]) {                    // If message received successfully
      dat[4] = 0;                    // Clear message received flag
      j = dat[3];                    // Read number of message received bytes
      for (i = 1; i <= j; i++){
        P0 = dat[i-1];               // Show received data on PORTA
        }
      dat[0] = dat[0] + 1;           // Increment received dat[0]
      Delay_ms(10);
      Rs485slave_Send(dat,1);        // And send back to Master
    }
  }
}

/*
 * Project name:
     RS485_Master (RS485 Library demo - Master side)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This is a simple demonstration on how to use the mikroC for 8051 RS485 library.
     It is being used in pair with the Rs485_Slave example project. Master (this
     machine) initiates communication with slave by sending 1 byte of data to
     the slave with designated slave address (160). The Slave accepts data,
     increments it and sends it back to the Master.
     The data received is shown on PORTA, Error on receive (0xAA) and number of
     consecutive unsuccessful retries are shown on PORTB.
     Several situations are shown here:
       - RS485 Master Init sequence;
       - Data sending master-to-slave with designated slave address;
       - Data sending master-to-slave with broadcast slave address (50);
       - Handling of unsuccessful master-slave communication (connection reset);
     Also shown here, but not strictly related to RS485 library, is:
       - Function calling from the interrupt routine - mikroC for 8051 limited 
         reentrancy support.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    None.
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - Turn on RS-485 lines on SW4.
     - Be careful to initialize the UART module before performing RS485 init.
*/

char dat[10];                         // Buffer for receving/sending messages
char i,j;
long count = 0;

// RS485 module connections
sbit rs485_transceive at P3.B7;       // Transmit/Receive control set to P3.7
// End RS485 module connections

//-------------- Interrupt routine
void UartRxHandler() org 0x23 {
  EA = 0;                             // Clear global interrupt enable flag
  if(RI) {                            // Test UART receive interrupt flag
    Rs485master_Receive(dat);         // UART receive interrupt detected,
                                      //   receive data using RS485 communication
    RI = 0;                           // Clear UART interrupt flag
    }
  EA = 1;                             // Set global interrupt enable flag
}

void main(){
  P0.B0 = 0;                             // Clear ports
  P1 = 0;

  Uart_Init(9600);                    // Initialize UART module at 9600 bps
  Delay_ms(100);

  Rs485master_Init();                 // Intialize MCU as RS485 master
  dat[0] = 0x55;                      // Fill buffer
  dat[1] = 0x00;
  dat[2] = 0x00;
  dat[4] = 0;                         // Ensure that message received flag is 0
  dat[5] = 0;                         // Ensure that error flag is 0
  dat[6] = 0;
  Rs485master_Send(dat,1,160);        // Send message to slave with address 160
                                      //   message data is stored in dat
                                      //   message is 1 byte long

  ES = 1;                             // Enable UART interrupt
  RI = 0;                             // Clear UART RX interrupt flag
  EA = 1;                             // Enable interrupts

  while (1){                          // Endless loop

                                      // Upon completed valid message receiving
                                      //   data[4] is set to 255

    count++;                          // Increment loop pass counter

    if (dat[5])  {                    // If error detected, signal it by
      P1 = 0xAA;                      //   setting PORTB to 0xAA
      }

    if (dat[4]) {                     // If message received successfully
      count = 0;                      // Reset loop pass counter
      dat[4] = 0;                     // Clear message received flag
      j = dat[3];                     // Read number of message received bytes
      for (i = 1; i <= j; i++){
        P0 = dat[i-1];                // Show received data on PORTA
        }
      dat[0] = dat[0] + 1;            // Increment first received byte dat[0]

      Delay_ms(10);
      Rs485master_Send(dat,1,160);    // And send it back to Slave
      }

    if (count > 10000) {              // If loop is passed 100000 times with
                                      //   no message received
      P1++;                           // Signal receive message failure on PORTB
      count = 0;                      // Reset loop pass counter
      Rs485master_Send(dat,1,160);    // Retry send message
      if (P1 > 10) {                  // If sending failed 10 times
        P1 = 0;                       // Clear PORTB
        Rs485master_Send(dat,1,50);   // Send message on broadcast address
        }
      }
    }
}

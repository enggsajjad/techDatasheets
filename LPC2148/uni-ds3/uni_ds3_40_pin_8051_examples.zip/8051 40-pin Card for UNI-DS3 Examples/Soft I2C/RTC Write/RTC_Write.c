/*
 * Project name:
     RTC_Write (Demonstration on working with the RTC Module and Software I2C routines)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
      This project is simple demonstration how to set date and time on PCF8583
      RTC (real-time clock). The code can be used with any MCU that has
      the Soft I2C library implemented.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS 3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    RTC extra board on PORTB
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - I2C communication lines should be connected to pull-up resistors.
     - In order to use the example, address pin A0 of PCF8583 must be set to 0V.
       (on mikroElektronika's RTC module this is done by default)
*/

// software I2C connections
sbit Soft_I2C_Scl at P1.B3;
sbit Soft_I2C_Sda at P1.B4;
// end Software I2C connections

void main() {

   Soft_I2C_Init();       // initialize full master mode
   Soft_I2C_Start();      // issue start signal
   Soft_I2C_Write(0xA0);  // address PCF8583, see PCF8583 datasheet
   Soft_I2C_Write(0);     // start from address 0 (configuration memory location)
   Soft_I2C_Write(0x80);  // write $80 to configuration memory location (pause counter...)
   Soft_I2C_Write(0);     // write 0 to cents memory location
   Soft_I2C_Write(0);     // write 0 to seconds memory location
   Soft_I2C_Write(0x30);  // write $30 to minutes memory location
   Soft_I2C_Write(0x11);  // write $11 to hours memory location
   Soft_I2C_Write(0x24);  // write $24 to year/date memory location
   Soft_I2C_Write(0x08);  // write $08 to weekday/month memory location
   Soft_I2C_Stop();       // issue stop signal

   Soft_I2C_Start();      // issue start signal
   Soft_I2C_Write(0xA0);  // address PCF8530
   Soft_I2C_Write(0);     // start from address 0
   Soft_I2C_Write(0);     // write 0 to configuration memory location (enable counting)
   Soft_I2C_Stop();       // issue stop signal
}

/*
 * Project name:
     RTC_Read (Demonstration on working with the RTC Module and Software I2C routines)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
      This project is simple demonstration how to read date and time from
      PCF8583 RTC (real-time clock). The code can be used with any MCU that has
      the Soft I2C library implemented.
      Date and time are read from the RTC every 1 second and printed at Lcd.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS 3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    Lcd 2x16, RTC on PORTB
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - Ports used in this example must be connected to pull-up resistors.
     - In order to use the example, address pin A0 of PCF8583 must be set to 0V.
       (on mikroElektronika's RTC module this is done by default)
*/

char seconds, minutes, hours, day, month, year;    // global date/time variables

// software I2C connections
sbit Soft_I2C_Scl at P1.B3;
sbit Soft_I2C_Sda at P1.B4;
// end Software I2C connections

// Lcd module connections
sbit LCD_RS at P0.B0;
sbit LCD_EN at P0.B1;

sbit LCD_D7 at P0.B7;
sbit LCD_D6 at P0.B6;
sbit LCD_D5 at P0.B5;
sbit LCD_D4 at P0.B4;
// end Lcd module connections*/*/

// reads time and date information from RTC (PCF8583)
void Read_Time() {
  Soft_I2C_Start();               // issue start signal
  Soft_I2C_Write(0xA0);           // address PCF8583, see PCF8583 datasheet
  Soft_I2C_Write(2);              // start from address 2
  Soft_I2C_Start();               // issue repeated start signal
  Soft_I2C_Write(0xA1);           // address PCF8583 for reading R/W=1
  seconds = Soft_I2C_Read(1);     // read seconds byte
  minutes = Soft_I2C_Read(1);     // read minutes byte
  hours = Soft_I2C_Read(1);       // read hours byte
  day = Soft_I2C_Read(1);         // read year/day byte
  month = Soft_I2C_Read(0);       // read weekday/month byte
  Soft_I2C_Stop();                // issue stop signal
}

// formats date and time
void Transform_Time() {
  seconds  =  ((seconds & 0xF0) >> 4)*10 + (seconds & 0x0F);  // transform seconds
  minutes  =  ((minutes & 0xF0) >> 4)*10 + (minutes & 0x0F);  // transform months
  hours    =  ((hours & 0xF0)  >> 4)*10  + (hours & 0x0F);    // transform hours
  year     =   (day & 0xC0) >> 6;                             // transform year
  day      =  ((day & 0x30) >> 4)*10    + (day & 0x0F);       // transform day
  month    =  ((month & 0x10)  >> 4)*10 + (month & 0x0F);     // transform month
}

// Output values to Lcd
void Display_Time() {

   Lcd_Chr(1, 7, (day / 10)   + 48);    // print tens digit of day variable
   Lcd_Chr(1, 8, (day % 10)   + 48);    // print oness digit of day variable
   Lcd_Chr(1, 10, (month / 10) + 48);
   Lcd_Chr(1, 11, (month % 10) + 48);
   Lcd_Chr(1, 16,  year        + 56);    // print year vaiable + 8 (start from year 2008)

   Lcd_Chr(2, 7, (hours / 10)   + 48);
   Lcd_Chr(2, 8, (hours % 10)   + 48);
   Lcd_Chr(2, 10, (minutes / 10) + 48);
   Lcd_Chr(2, 11, (minutes % 10) + 48);
   Lcd_Chr(2,13, (seconds / 10) + 48);
   Lcd_Chr(2,14, (seconds % 10) + 48);
}

// performs project-wide init
void Init_Main() {
  
  Soft_I2C_Init();           // initialize Soft I2C communication
  
  Lcd_Init();                // initialize Lcd
  Lcd_Cmd(LCD_CLEAR);        // clear Lcd display
  Lcd_Cmd(LCD_CURSOR_OFF);   // turn cursor off

  LCD_Out(1,1,"Date:");      // prepare and output static text on Lcd
  LCD_Chr(1,9,':');
  LCD_Chr(1,12,':');
  LCD_Out(2,1,"Time:");
  LCD_Chr(2,9,':');
  LCD_Chr(2,12,':');
  LCD_Out(1,13,"200");
}

// main procedure
void main() {
  Init_Main();               // perform initialization
  
  while (1) {                // endless loop
    Read_Time();             // dead time from RTC(PCF8583)
    Transform_Time();        // format date and time
    Display_Time();          // prepare and display on Lcd
    Delay_ms(1000);          // wait 1 second
    }
}

/*
 * Project name:
     Button (Demonstration of using Button Library)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This program demonstrates usage on-board button as PORTA input.
     On every PORTA.B0 one-to-zero transition PORTC is inverted.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - Put button jumper (J11) into GND position (board specific).
     - Ports used in this example must be connected to pull-up resistors.
*/

// button connections
sbit Button_Pin at P0.B0;           // declare Button_Pin. it will be used by Button Library.
// end Button connections

bit oldstate;                       // old state flag

void main() {
  P0 = 255;                         // configure PORTA as input
  P2 = 0xFF;                        // initial PORTC value

  do {
    if (Button(1, 1))               // detect logical one
      oldstate = 1;                 // update flag
    if (oldstate && Button(1, 0)) { // detect one-to-zero transition
      P2 = ~P2;                     // invert PORTC
      oldstate = 0;                 // update flag
      }
  } while(1);                       // endless loop

}

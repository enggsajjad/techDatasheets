/*
 * Project name:
     ADC (Driving internal Analog-to-Digital converter via SPI interface)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
      This is a sample program which demonstrates the use of the Microchip's
      internal MCP3204 A/D converter with 8051 MCUs. This device accepts analog
      input voltage via potentiomenter, and displays it on the LCD In this example
      the ADC communicates with MCU through the SPI communication.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - Connect reference jumper (J15) on UNI-DS3 board to Vcc or 4.096V to
       choose Vref input for MCP3204 ADC.
     - Turn on SPI and ADC-CS switches on UNI-DS3 board.
     - Put button jumper (J10) into GND position.
 */

// ADC module connections
sbit CHIP_SEL at P1.B0;
// End ADC module connections

// LCD module connections
sbit LCD_RS at P0.B0;
sbit LCD_EN at P0.B1;

sbit LCD_D7 at P0.B7;
sbit LCD_D6 at P0.B6;
sbit LCD_D5 at P0.B5;
sbit LCD_D4 at P0.B4;

// End LCD module connections

unsigned int  measurement, lastValue;
// Initialize LCD and SPI
void Init() {
  Lcd_Init();                        // Initialize LCD
  Lcd_Cmd(LCD_CLEAR);                // Clear display
  Lcd_Cmd(LCD_CURSOR_OFF);           // Cursor off
  lastValue = 1;                     // Initialize and make them
  measurement = 0;                   //   different
  // Init SPI
  SPI_Init();
  CHIP_SEL = 1;                      // deselect ADC chip
}

unsigned int getADC(unsigned short channel) { // returns 0..4096
  unsigned int tmp;
  CHIP_SEL = 0;                               // select MCP3204
  SPI_Write(0x06);
  channel = channel << 6;
  tmp = SPI_read(channel) & (0x0F);           // bits 7 & 6 define ADC input
  tmp = tmp << 8;
  tmp |= SPI_read(0);                         // get ADC value
  CHIP_SEL = 1;
  return tmp;
}

void processValue(unsigned int pv) {  // Writes Value to LCD
  char i;
  if (lastValue != pv) {              // Write Value only if different
                                      //   than previous
      lastValue = pv;                 // Equalize the values
      i = pv /1000 + 48;
      LCD_Chr(2,1, i);
      Lcd_Chr(2,2, '.');              // write dot character
      pv %= 1000;
      i = pv /100 + 48;
      LCD_Chr(2,3, i);
      pv %= 100;
      i = pv /10 + 48;
      LCD_Chr(2,4, i);
      pv %= 10;
      i = pv + 48;
      LCD_Chr(2,5, i);                // Put number on display
      LCD_Chr(2,7, 'V');              // Write 'V' character
  }
}

// main procedure
void main() {
  Init();
  LCD_Out(1,1,"ADC value:");

  while (1) {
     measurement = getADC(0);         // Get ADC result from Channel 0
     ProcessValue(measurement);       // Do something with measurement
     Delay_ms(100);                   // Wait for a while
  }
  Delay_ms(100);                      // Wait for a while
}

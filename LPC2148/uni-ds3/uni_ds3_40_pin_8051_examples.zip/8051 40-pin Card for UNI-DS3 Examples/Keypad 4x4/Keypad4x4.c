/*
 * Project name:
     Keypad_Test (Demonstration on Usage of the Keypad Library)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
      A simple example of using the keypad library for mikroC for 8051. 
      It supports keypads with 1..4 rows and 1..4 columns. The code being 
      returned by the Keypad_Key_Press() and Keypad_Key_Click() functions is
      in range from 1..16. In this example, the code returned by the keypad 
      library functions is transformed into ASCII codes [0..9,A..F]. 
      In addition, a small single-byte counter displays in the second LCD row 
      number of key presses.
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    LCD 2x16, Keypad 4x3 or 4x4 module at PORTB
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - Port connected to keypad must be connected to pull-up resistors.
     - Since sampling lines for 8051 MCUs are activated by logical zero
       Keypad Library can not be used with hardwares that have protective diodes
       connected with anode to MCU side, such as mikroElektronika's 
       Keypad extra board HW.Rev v1.20.
 */

unsigned short kp, cnt, oldstate = 0;
char txt[5];

// Keypad module connections
sfr char  keypadPort at P1;
// End Keypad module connections

// lcd pinout definition
sbit LCD_RS at P0.B0;
sbit LCD_EN at P0.B1;

sbit LCD_D7 at P0.B7;
sbit LCD_D6 at P0.B6;
sbit LCD_D5 at P0.B5;
sbit LCD_D4 at P0.B4;
// end lcd definitions

void main() {
  cnt = 0;                                 // Reset counter
  Keypad_Init();                           // Initialize Keypad                              
  Lcd_Init();                              // Initialize LCD
  Lcd_Cmd(LCD_CLEAR);                      // Clear display
  Lcd_Cmd(LCD_CURSOR_OFF);                 // Cursor off

  Lcd_Out(1, 1, "Key  :");                 // Write message text on LCD
  Lcd_Out(2, 1, "Times:");

  do {
    kp = 0;                                // Reset key code variable

    // Wait for key to be pressed and released
    do
      kp = Keypad_Key_Click();             // Store key code in kp variable
    while (!kp);

    // Prepare value for output, transform key to it's ASCII value
    switch (kp) {
      //case 10: kp = 42; break;  // '*'   // Uncomment this block for keypad4x3
      //case 11: kp = 48; break;  // '0'   
      //case 12: kp = 35; break;  // '#'
      //default: kp += 48;

      case  1: kp = 49; break; // 1        // Uncomment this block for keypad4x4
      case  2: kp = 50; break; // 2
      case  3: kp = 51; break; // 3
      case  4: kp = 65; break; // A
      case  5: kp = 52; break; // 4
      case  6: kp = 53; break; // 5
      case  7: kp = 54; break; // 6
      case  8: kp = 66; break; // B        
      case  9: kp = 55; break; // 7
      case 10: kp = 56; break; // 8
      case 11: kp = 57; break; // 9
      case 12: kp = 67; break; // C
      case 13: kp = 42; break; // *
      case 14: kp = 48; break; // 0
      case 15: kp = 35; break; // #
      case 16: kp = 68; break; // D

    }

    if (kp != oldstate) {                  // Pressed key differs from previous 
      cnt = 1;
      oldstate = kp;
      }
    else {                                 // Pressed key is same as previous
      cnt++;
      }
    
    Lcd_Chr(1, 10, kp);                    // Print key ASCII value on LCD

    if (cnt == 255) {                      // If counter varialble overflow
      cnt = 0;
      Lcd_Out(2, 10, "   ");
      }
      
    WordToStr(cnt, txt);                   // Transform counter value to string  
    Lcd_Out(2, 10, txt);                   // Display counter value on LCD

  } while (1);
} 

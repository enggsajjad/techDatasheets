/*
 * Project name:
     Can_Spi_2nd (CAN Network demonstration with mikroE's CAN-SPI module)
 * Copyright:
     (c) Mikroelektronika, 2007.
 * Revision History:
     20071210:
       - initial release;
 * Description:
     This project demonstrates how to use CANSPI library functions and procedures.
     With minor adjustments, it should work with any other 8051 MCU that has a SPI module.     
     It is used together with the CanSpi_1st example (on second MCU), and it can
     be used to test the connection of MCU to the CAN network.
     This (2nd) node receives the data from 1st node, increments data by 1 and
     send it back to 1st node.          
 * Test configuration:
     MCU:             AT89S8253
     Dev.Board:       UNI-DS3
     Oscillator:      External Clock 10.0000 MHz
     Ext. Modules:    None
     SW:              mikroC for 8051 v1.0
 * NOTES:
     - Turn on CAN and SPI lines on SW2 and SW4.
     - The indicator of good communication in this example is, that the 1st
       node always displays even data on PORTA, whilst the 2nd node always
       displays odd data.
     - Consult the CAN standard about CAN bus termination resistance.
 */

unsigned char Can_Init_Flags, Can_Send_Flags, Can_Rcv_Flags;  // CAN flags
unsigned char Rx_Data_Len;                                    // Received data length in bytes
char RxTx_Data[8];                                            // CAN rx/tx data buffer
char Msg_Rcvd;                                                // Reception flag
long Tx_ID, Rx_ID;                                            // CAN rx and tx ID

// CANSPI module connections
sbit CanSpi_CS  at  P3.B5;
sbit CanSpi_Rst at  P3.B6;
// End CANSPI module connections

void main() {

  Can_Init_Flags = 0;                                         //
  Can_Send_Flags = 0;                                         // Clear flags
  Can_Rcv_Flags  = 0;                                         //

  Can_Send_Flags = CAN_TX_PRIORITY_0 &                        // Form value to be used
                   CAN_TX_XTD_FRAME &                         //   with CANSPIWrite
                   CAN_TX_NO_RTR_FRAME;

  Can_Init_Flags = CAN_CONFIG_SAMPLE_THRICE &                 // Form value to be used
                   CAN_CONFIG_PHSEG2_PRG_ON &                 //   with CANSPIInit
                   CAN_CONFIG_XTD_MSG &
                   CAN_CONFIG_DBL_BUFFER_ON &
                   CAN_CONFIG_VALID_XTD_MSG &
                   CAN_CONFIG_LINE_FILTER_OFF;

  Spi_Init();                                                 // Initialize SPI module
  CANSPIInitialize(1,3,3,3,1,Can_Init_Flags);                 // Initialize CAN-SPI module

  CANSPISetOperationMode(CAN_MODE_CONFIG,0xFF);               // Set CONFIGURATION mode

  CANSPISetMask(CAN_MASK_B1,-1,CAN_CONFIG_XTD_MSG);           // Set all mask1 bits to ones
  CANSPISetMask(CAN_MASK_B2,-1,CAN_CONFIG_XTD_MSG);           // Set all mask2 bits to ones
  CANSPISetFilter(CAN_FILTER_B2_F3,12111,CAN_CONFIG_XTD_MSG); // Set id of filter B2_F3 to 12111

  CANSPISetOperationMode(CAN_MODE_NORMAL,0xFF);               // Set NORMAL mode

  Tx_ID = 3;                                                  // Set tx ID

  while (1) {                                                                   // Endless loop
    Msg_Rcvd = CANSPIRead(&Rx_ID , RxTx_Data , &Rx_Data_Len, &Can_Rcv_Flags);   // Receive message
    if ((Rx_ID == 12111u) && Msg_Rcvd) {                                        // If message received check id
      P0 = RxTx_Data[0];                                                        // ID correct, output data at PORT0
      RxTx_Data[0]++ ;                                                          // Increment received data
      CANSPIWrite(Tx_ID, RxTx_Data, 1, Can_Send_Flags);                         // Send incremented data back
    }
  }
}

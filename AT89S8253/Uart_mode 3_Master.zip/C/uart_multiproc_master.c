/**
 * @file $RCSfile: uart_multiproc_master.c,v $
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file is an example to use uart with timer in 
 * multiprocessor mode.
 *
 * This file can be parsed by Doxygen for automatic documentation
 * generation.
 * Put here the functional description of this file within the software
 * architecture of your program.
 *
 * @version $Revision: 1.0 $ $Name:  $
 */

/* @section  I N C L U D E S */
#include "reg_c51.h"

char uart_data;
char exemple_send_data=0x55;
char TxOK=0;
/**
 * FUNCTION_PURPOSE: This file set up uart in mode 3 (9 bits uart) with
 * timer 1 in baud rate generator mode.
 * FUNCTION_INPUTS: P3.2(INT0)
 * FUNCTION_OUTPUTS: void
 */
void main (void) 
{
	SCON = 0xF0;					  /* uart in mode 3 (9 bit), REN=1 */
   SADDR=0x01;                  /* local address */ 
   SADEN=0xFF;                  /* address mask */
	TMOD = TMOD | 0x20 ;         /* Timer 1 in mode 2 */
	TH1  = 0xFD;                 /* 9600 Bds at 11.059MHz */
	TL1  = 0xFD; 				  	  /* 9600 Bds at 11.059MHz */
	ES = 1; 						     /* Enable serial interrupt */
	EA = 1;						     /* Enable global interrupt */
   TR1 = 1;                     /* Timer 1 run */

   while(1)                     /* endless */
   {
   while(P3_2);                 /* wait P3_2(INT0)=0 */ 
   while(!P3_2);                /* wait P3_2(INT0)=1 */ 

     TB8 = 1;                   /* address mode */ 
     TxOK=1;                    /* set software flag */ 
     SBUF = 0x03;               /* send slave adress */
     while(TxOK);               /* wait the stop bit transmition */

     TB8 = 0;                   /* data mode */
     TxOK=1;                    /* set software flag */ 
     SBUF = exemple_send_data;  /* send data */ 
     while(TxOK);               /* wait the stop bit transmition */
   }
}		

/**
 * FUNCTION_PURPOSE: serial interrupt.
 * FUNCTION_INPUTS: P3.0(RXD) serial input
 * FUNCTION_OUTPUTS: none
 */
void serial_IT(void) interrupt 4 
{
	if (TI == 1) 
	{				                 /* if reception occur */
      TI=0; 			           /* clear transmition flag for next transmition */
      TxOK=0; 			           /* clear software transmition flag */
   }

	if (RI == 1) 
	{				                 /* if reception occur */
	   RI = 0; 			           /* clear reception flag for next reception */
      if(RB8) SM2=0;            /* go into data mode */ 
      else
         {
         uart_data = SBUF;      /* Read receive data */
         SM2=1;                 /* return into address mode after receive data */
         }
	}
}


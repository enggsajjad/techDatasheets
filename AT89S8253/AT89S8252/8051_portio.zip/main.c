sfr P1 = 0x90;          /* SFR definition for Port 1 */
sfr P3 = 0xB0;          /* SFR definition for Port 3 */

/*------------------------------------------------
MAIN C Function
------------------------------------------------*/
void main (void)
{
unsigned char pval;     /* temp variable for port values */

P1 = 0xFF;              /* Setup P1 for Input */

/*--------------------------------------
Use the Toolbox buttons in the debugger
to change the value of P1.  Open the
Port 1 and Port 3 dialogs from the
Peripherals Menu to view their status.
--------------------------------------*/
while (1)
  {
  pval = P1;            /* Read P1 into pval */
  P3 = pval;            /* Write pval to P3 */
  }
}


void com_initialize (void);

void com_baudrate (
  unsigned baudrate);

char com_putchar (
  unsigned char c);

int com_getchar (void);

unsigned char com_rbuflen (void);

unsigned char com_tbuflen (void);












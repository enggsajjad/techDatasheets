#include <reg52.h>
#include <stdio.h>

/*------------------------------------------------
Timer 1 Interrupt Service Routine.

Set a breakpoint on 'overflow_count++' and run the
program in the debugger.  You will see this line
executes every 100 clock cycles (or 10,000 Hz).

So, overflow_count is actually a 1/10,000 sec
timer.
------------------------------------------------*/
static unsigned long overflow_count = 0;

void timer1_ISR (void) interrupt 3
{
overflow_count++;   /* Increment the overflow count */
}

/*------------------------------------------------
MAIN C function
------------------------------------------------*/
void main (void)
{
/*--------------------------------------
Set Timer1 for 8-bit timer with reload
(mode 2). The timer counts to 255,
overflows, is reloaded with 156, and
generates an interrupt.

Set the Timer1 Run control bit.
--------------------------------------*/
TMOD = (TMOD & 0x0F) | 0x20;  /* Set Mode (8-bit timer with reload) */
TH1 = 256 - 100;              /* Reload TL1 to count 100 clocks */
TL1 = TH1;
ET1 = 1;                      /* Enable Timer 1 Interrupts */
TR1 = 1;                      /* Start Timer 1 Running */
EA = 1;                       /* Global Interrupt Enable */

/*--------------------------------------
Do Nothing.  Actually, the timer 1
interrupt will occur every 100 clocks.
Since the oscillator runs at 12 MHz,
the interrupt will happen every 10 KHz.
--------------------------------------*/
while (1)
  {
  }
}


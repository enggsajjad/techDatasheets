/*C**************************************************************************
* NAME:         main.c
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      cc03-demo-spi-0_0_1      
* REVISION:     1.1.1.1     
*----------------------------------------------------------------------------
* PURPOSE: 
* This file contains an example of use the SPI drivers with AT89c51cc03
* 
*****************************************************************************/

/*_____ I N C L U D E S ____________________________________________________*/
#include "config.h"
#include "/lib_mcu/spi/spi_drv.h"
#include "intrins.h"

/*_____ M A C R O S ________________________________________________________*/


/*_____ D E F I N I T I O N S ______________________________________________*/



/*_____ D E C L A R A T I O N S ____________________________________________*/




/*F**************************************************************************
* NAME: main 
*----------------------------------------------------------------------------
* PARAMS:   none
* return:   none
*----------------------------------------------------------------------------
* PURPOSE: SPI drivers demo software
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE: 
*----------------------------------------------------------------------------
* REQUIREMENTS: 
*****************************************************************************/
void main (void)
{	
	Uchar temp;
	Uchar tab[10];
	Uchar index;

	//init data buffer
	for(index=0;index<10;index++) tab[index]=index;
	
	Set_x2_mode();
	Set_spi_x1_mode();
	spi_master_init(0,1,1,128); //SPI init CPOL=0, CPHA=1, SSDIS=1 bitrate=Fper/8

	//Send 2 bytes in polling mode
	spi_transmit_byte(0xAA);
	spi_transmit_byte(0x55);
	temp=spi_get_data();


	//Send 10 bytes in interrupt mode
	Enable_spi_interrupt();
	Enable_interrupt();
	spi_transmit_burst_it (tab, 10);

	//Send 10 bytes in polling mode
	while(b_spi_busy); //Wait end of transfer under interrupt
	for(index=0;index<10;index++) tab[index]=index; 	//init data buffer
	Disable_spi_interrupt();
	spi_transmit_burst_polling( tab, 10);
	while(1);

 }



README - cc03-demo-spi-0_0_1

Please read the LICENSE file.


DESCRIPTION
-----------
This software demontrates the SPI drivers for AT89C51CC03.
This application illustrates how to initialize the SPI module
in master mode to send some data in differents configuration: byte or burst mode.


DOWNLOAD
--------
This software program can be downloaded from the Atmel website:
http://www.atmel.com


PROBLEMS
--------
If you find any problems, please report them to Atmel Website:
http://www.atmel.com/support
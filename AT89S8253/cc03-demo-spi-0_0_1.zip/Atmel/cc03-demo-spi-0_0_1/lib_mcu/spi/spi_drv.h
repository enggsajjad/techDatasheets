/*H**************************************************************************
* NAME:         spi_drv.h         
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      cc03-demo-spi-0_0_1      
* REVISION:     1.1.1.1     
*----------------------------------------------------------------------------
* PURPOSE: 
* spi lib header file                                                 
*****************************************************************************/

#ifndef _spi_DRV_H_
#define _spi_DRV_H_

/*_____ I N C L U D E S ____________________________________________________*/
#include "config.h"

/*_____ D E F I N I T I O N ________________________________________________*/


#define SPI_RATIO_2			0x00
#define SPI_RATIO_4			0x01
#define SPI_RATIO_8			0x02
#define	SPI_RATIO_16		0x03
#define	SPI_RATIO_32		0x80
#define	SPI_RATIO_64		0x81
#define	SPI_RATIO_128		0x82
#define	SPI_RATIO_INVALID	0x83


/*_____ M A C R O S ________________________________________________________*/


#define Spif_set()					((SPSCR & MSK_SPSCR_SPIF) == MSK_SPSCR_SPIF)
#define Spte_set()          ((SPSCR & MSK_SPSCR_SPTE) == MSK_SPSCR_SPTE)

/*_____ D E C L A R A T I O N ______________________________________________*/



extern volatile bit b_spi_error;
extern volatile bit b_spi_transmit_completed;
extern volatile bit	b_spi_busy;
extern volatile Uchar *spi_string_ptr;
extern volatile Uchar spi_data_nb;
extern volatile Uchar spi_data;

void spi_master_init(bit cpol, bit cpha, bit ssdis,Uchar speed);
void spi_slave_init(bit cpol, bit cpha, bit ssdis);
bit spi_set_speed( unsigned char ratio );
unsigned char spi_transmit_byte(unsigned char to_transmit);
unsigned char spi_get_data();
void spi_put_data( unsigned char to_transmit);
void spi_transmit_burst_polling( unsigned char  *ptr_buf, unsigned char nb_data); 
bit  spi_transmit_burst_it (Uchar *string_ptr, Uchar data_nb);

#endif /* _SPI_DRV_H_ */

/*H**************************************************************************
* NAME:         at89c51cc03_drv.h         
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      cc03-demo-spi-0_0_1      
* REVISION:     1.5     
*----------------------------------------------------------------------------
* PURPOSE:
* This file contains the C51 driver definition
*****************************************************************************/

#ifndef _AT89C51CC03_DRV_H_
#define _AT89C51CC03_DRV_H_

/*_____ I N C L U D E S ____________________________________________________*/


/*_____ M A C R O S ________________________________________________________*/


/*_____ D E F I N I T I O N ________________________________________________*/
/* INTERRUPT NUMBER */
#define IRQ_INT0    0
#define IRQ_T0      1
#define IRQ_INT1    2
#define IRQ_T1      3
#define IRQ_UART    4
#define IRQ_PCA     5
#define IRQ_T2      6
#define IRQ_CAN     7
#define IRQ_ADC     8
#define IRQ_CAN_OVR 9
#define IRQ_SPI     10


/* SYSTEM MANAGEMENT */
#define MSK_SMOD1   0x80    /* PCON */
#define MSK_SMOD0   0x40
#define MSK_POF     0x10
#define MSK_GF1     0x08
#define MSK_GF0     0x04
#define MSK_PD      0x02
#define MSK_IDL     0x01

#define MSK_DPU     0x80    /* AUXR */
#define MSK_VPFDP   0x40
#define MSK_M0      0x20
#define MSK_XRS2    0x10
#define MSK_XRS1    0x08
#define MSK_XRS0    0x04
#define MSK_EXTRAM  0x02
#define MSK_AO      0x01


/* CLOCK */
#define MSK_X2      0x01    /* CKCON0 */
#define MSK_T0X2    0x02
#define MSK_T1X2    0x04
#define MSK_T2X2    0x08
#define MSK_UARTX2  0x10
#define MSK_PCAX2   0x20
#define MSK_WDX2    0x40
#define MSK_CANX2   0x80


#define MSK_SPIX2   0x01    /* CKCON1 */

/* TIMERS */
#define MSK_GATE1   0x80    /* TMOD */
#define MSK_C_T1    0x40
#define MSK_MO1     0x30
#define MSK_GATE0   0x08
#define MSK_C_T0    0x04
#define MSK_MO0     0x03


/* WATCHDOG */
#define MSK_WTO     0x07    /* WDTPRG*/

/* SPI */
#define MSK_SPSCR_SPIF		0x80
#define MSK_SPSCR_OVR		0x20
#define MSK_SPSCR_MODF		0x10
#define MSK_SPSCR_SPTE		0x08
#define MSK_SPSCR_UARTM		0x04
#define MSK_SPSCR_SPTEIE	0x02
#define MSK_SPSCR_MODFIE	0x01

#define MSK_SPCON_SPR2	0x80
#define MSK_SPCON_SPEN	0x40
#define MSK_SPCON_SSDIS	0x20
#define MSK_SPCON_MSTR	0x10
#define MSK_SPCON_CPOL	0x08
#define MSK_SPCON_CPHA	0x04
#define MSK_SPCON_SPR1	0x02
#define MSK_SPCON_SPR0	0x01

/*_____ D E C L A R A T I O N ______________________________________________*/

#define Set_x2_mode()           (CKCON0 |= MSK_X2)
#define Set_x1_mode()           (CKCON0 &= ~MSK_X2)
#define Mode_x2()               ((CKCON0 & MSK_X2) == MSK_X2)

#define Set_timer0_x1_mode()    (CKCON0 |= MSK_T0X2)
#define Set_timer0_x2_mode()    (CKCON0 &=~MSK_T0X2)
#define Set_timer1_x1_mode()    (CKCON0 |= MSK_T1X2)
#define Set_timer1_x2_mode()    (CKCON0 &=~MSK_T1X2)
#define Set_timer2_x1_mode()    (CKCON0 |= MSK_T2X2)
#define Set_timer2_x2_mode()    (CKCON0 &=~MSK_T2X2)
#define Set_uart_x1_mode()      (CKCON0 |= MSK_UARTX2)
#define Set_uart_x2_mode()      (CKCON0 &=~MSK_UARTX2)
#define Set_pca_x1_mode()()     (CKCON0 |= MSK_PCAX2)
#define Set_pca_x2_mode()       (CKCON0 &=~MSK_PCAX2)
#define	Set_watchdog_x1_mode()	(CKCON0 |= MSK_WDX2)
#define	Set_watchdog_x2_mode()	(CKCON0 &=~MSK_WDX2)
#define Set_can_x1_mode()		    (CKCON0 |= MSK_CANX2)
#define Set_can_x2_mode()       (CKCON0 &=~MSK_CANX2)
#define Set_spi_x1_mode()		    (CKCON1 |= MSK_SPIX2)
#define Set_spi_x2_mode()       (CKCON1 &=~MSK_SPIX2)


#define Set_idle_mode()         (PCON |= MSK_IDLE)
#define Set_power_down_mode()   (PCON |= MSK_PD)

#define Enable_xram()           (AUXR &= ~MSK_EXTRAM)
#define Disable_xram()          (AUXR |= MSK_EXTRAM)


#define Disable_ale()       (AUXR |= MSK_AO)
#define Enable_ale()        (AUXR &= ~MSK_AO)
#define Switch_ale()        (AUXR ^= MSK_AO)

#define Enable_interrupt()     		 (EA = 1)
#define Disable_interrupt()     	 (EA = 0)
#define Enable_int0_interrupt()      (EX0 = 1)
#define Disable_int0interrupt()      (EX0 = 0)
#define Enable_timer0_interrupt()    (ET0 = 1)
#define Disable_timer0_interrupt()   (ET0 = 0)
#define Enable_int1_interrupt()      (EX1 = 1)
#define Disable_int1_interrupt()     (EX1 = 0)
#define Enable_timer1_interrupt()    (ET1 = 1)
#define Disable_timer1_interrupt()   (ET1 = 0)
#define Enable_pca_interrupt()       (EC = 1)
#define Disable_pca_interrupt()      (EC = 0)
#define Enable_uart_interrupt()      (ES = 1)
#define Disable_uart_interrupt()     (ES = 0)
#define Enable_timer2_interrupt()    (ET2 = 1)
#define Disable_timer2_interrupt()   (ET2 = 0)
#define Enable_can_interrupt()       (ECAN = 1)
#define Disable_can_interrupt()      (ECAN = 0)
#define Enable_adc_interrupt()       (EADC = 1)
#define Disable_adc_interrupt()      (EADC = 0)
#define Enable_can_ovr_interrupt()   (ETIM = 1)
#define Disable_can_ovr_interrupt()  (ETIM = 0)
#define Enable_spi_interrupt()   		 (ESPI = 1)
#define Disable_spi_interrupt()			 (ESPI = 0)




#endif  /* _AT89C51CC03_DRV_H_ */


/**
 * @file $RCSfile: t1_m0_t_gh.c,v $
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file is an example to use timer1 in mode 0.
 *
 * This file can be parsed by Doxygen for automatic documentation
 * generation.
 * Put here the functional description of this file within the software
 * architecture of your program.
 *
 * @version $Revision: 1.0.0 $ $Name:  $
 */

/* @section  I N C L U D E S */
#include "reg_c51.h"


/**
 * FUNCTION_PURPOSE: This file set up timer 1 in mode 0 (13 bits timer) 
 * with a hardware gate.
 * The 13-bits register consist of all 8 bits of TH1 and the lower 5 bits   
 * of TL1. The upper 3 bits of TL1 are undeterminate and are ignored.   
 * FUNCTION_INPUTS: P3.3(INT1)=1 : GATE Input
 * FUNCTION_OUTPUTS: void
 */
void main(void)
{
	TMOD &= 0x0F;			   	/* Timer 1 mode 0 with hardware gate */
	TMOD |= 0x80;			   	/* GATE0=1; C/T0#=0; M10=0; M00=0; */
	
	TH1 = 0x00;				      /* init values */
	TL1 = 0x00;		
	ET1=1;						   /* enable timer1 interrupt */
	EA=1;                      /* enable interrupts */
	TR1=1;						   /* timer1 run */
	while(1);						/* endless  */
}  


/**
 * FUNCTION_PURPOSE: timer1 interrupt
 * FUNCTION_INPUTS: void
 * FUNCTION_OUTPUTS: P1.0 toggle period = 2 * 8192 cycles  
 */
void it_timer1(void) interrupt 3 /* interrupt address is 0x001b */
{
	TF1 = 0;                   /* reset  interrupt flag (already done by hardware)*/
	P1_0 = ~P1_0;					/* P1.0 toggle when interrupt. */
}

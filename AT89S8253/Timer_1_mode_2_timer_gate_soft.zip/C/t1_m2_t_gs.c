/**
 * @file $RCSfile: t1_m2_t_gs.c,v $
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file is an example to use timer1 in mode 2.
 *
 * This file can be parsed by Doxygen for automatic documentation
 * generation.
 * Put here the functional description of this file within the software
 * architecture of your program.
 *
 * @version $Revision: 1.0.0 $ $Name:  $
 */
/*_____ M A C R O S ________________________________________________________*/

/**
 * This is a macro local to this file .
 */
#define reload_value 0x36 /* reload value exemple */


/* @section  I N C L U D E S */
#include "reg_c51.h"


/**
 * FUNCTION_PURPOSE: This file set up timer 1 in mode 2 (8 bits auto reload
 * timer) with a software gate.
 * The 8-bits register consist of all 8 bits of TL1 and all 8 bits   
 * of TH1 for the reload value.TH1 is load in TL1 at timer1 overflow.   
 * FUNCTION_INPUTS: void
 * FUNCTION_OUTPUTS: void
 */
void main(void)
{
	TMOD &= 0x0F;			      /* Timer 1 mode 2 with software gate */
	TMOD |= 0x20;              /* GATE0=0; C/T0#=0; M10=1; M00=0; */
	
	TL1 = reload_value;        /* init values */
	TH1 = reload_value;        /* reload value */		
	ET1=1;                     /* enable timer1 interrupt */
	EA=1;				            /* enable interrupts */
	TR1=1;			     	      /* timer1 run */
	while(1);				      /* endless  */
}


/**
 * FUNCTION_PURPOSE: timer1 interrupt
 * FUNCTION_INPUTS: void
 * FUNCTION_OUTPUTS: P1.0 toggle period = 2 * (256-reload_value) cycles  
 */
void it_timer1(void) interrupt 3 /* interrupt address is 0x001b */
{
	TF1 = 0;							/* reset  interrupt flag (already done by hardware)*/
	P1_0 = ~P1_0;					/* P1.0 toggle when interrupt. */
}

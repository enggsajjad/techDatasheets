/*H***************************************************************************
* NAME: compiler.h           
*----------------------------------------------------------------------------
* PURPOSE: 
* Defines compiler dependant definitions to enhance program portability. 
* Allows to remap exotic syntaxes to another exotic syntaxe without changing 
* C source files.
*****************************************************************************/

#ifndef _COMPILER_H_
#define _COMPILER_H_

/*_____ M A C R O S ________________________________________________________*/
#define FALSE  0
#define TRUE   1

/*_____ D E F I N I T I O N ________________________________________________*/
typedef unsigned char   Uchar;
typedef unsigned short  Uint16;
typedef signed int      Int16;
typedef float           Float16;
typedef unsigned char   Bool;

/* KEIL compiler syntax redefinition */
#define Reentrant(x)    x reentrant
#define Sfr(x,y)        sfr x = y
#define Sbit(x,y,z)     sbit x = y ^ z
#define Interrupt(x,y)  x interrupt y
#define At(x)           _at_ x

#endif /* _COMPILER_H_ */


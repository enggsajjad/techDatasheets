/*H***************************************************************************
* NAME: myfile.h           
*----------------------------------------------------------------------------
* PURPOSE: 
*****************************************************************************/

#ifndef _CONFIG_H_
#define _CONFIG_H_

/*_____ I N C L U D E S ____________________________________________________*/
#include <reg51.h>
#include "compiler.h"

/* ______________________ User Configuration Section ______________________ */

#define HAVE_XRAM               /* Target chip: T89C51RD2 with on-chip XRAM */

/* ______________________ User Configuration Section ______________________ */
        

#ifdef HAVE_XRAM                /* If on-chip XRAM, disable the XRAM to access to the entire */
#define NO_XDATA 0x02           /* FLASH when mapped in the data area */ 
Sfr (AUXR, 0x8E);
#endif

#endif /* _CONFIG_H_ */



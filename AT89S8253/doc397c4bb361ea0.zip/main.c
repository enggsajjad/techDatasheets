/*C**************************************************************************
* NAME: main.c  
*----------------------------------------------------------------------------
* PURPOSE: 
* Main entry for ISP program and system initialization. 
* Main entry includes all the ISP sequence from FLASH erase to FLASH prog.
*****************************************************************************/

/*_____ I N C L U D E S ____________________________________________________*/
#include <stdio.h>
#include "config.h"
#include "isp.h"

/*F**************************************************************************
* NAME: _DEAD_ 
*----------------------------------------------------------------------------
* PURPOSE: 
* When a fatal error occurs, this function is called to end with a standard 
* error message and a never end loop.
*****************************************************************************/
void _DEAD_(void)
{
  printf("\nError: cannot continue!\n");
  while (1);
}

/*F**************************************************************************
* NAME: system_init 
*----------------------------------------------------------------------------
* PURPOSE: 
* Initializes the microcontroller: XRAM disabled to enable the FLASH mapping 
* into the data space and uart settings.
*****************************************************************************/
void system_init(void)
{
  /* Disable on-chip XRAM if exists */      
#ifdef HAVE_XRAM
  AUXR = NO_XDATA;              
#endif

  /* Initialize communication port */
  uart_init();
  EA = 1;      
}

/*F**************************************************************************
* NAME: main 
*----------------------------------------------------------------------------
* PURPOSE: 
* Program main entry. Manages the basic ISP sequence flow from FLASH ersure
* to FLASH programming.
*****************************************************************************/
void main(void)
{
  Uchar status;
  
  /* System initialization: IO, welcome message, ... */  
  system_init();
  printf("\n\n** Welcome to the ISP program! **\n\n");  
   
  /* Check the Flash manufacturer and device Id (Atmel=1F, 49HF010=17) */
  printf("Check if FLASH device is a Atmel AT49HF010... ");
  if (flash_id()==0x1F17)
  {
    printf("OK.\n");
  }
  else
  {
    printf("KO!\n");
    _DEAD_();
  }
  
  /* On-board FLASH erase operation */
  printf("\nErasing the on-board FLASH memory... ");
  flash_erase();  
  printf("OK.\n\n");
 
  /* FLASH erased: ready for programming */
  printf("Ready for FLASH programming.\n");
  printf("Send .hex file with the following terminal configuration:\n");
  printf("  - ASCII character transmission,\n"); 
  printf("  - 8 bits, 1 stop, parity none,\n"), 
  printf("  - XON-XOFF flow control.\n"); 
  printf("\nWaiting for download...\n");

  /* Parses the downloaded HEX file and program the on-board FLASH memory */
  uart_rx_enable();

  status = hex_parser();        

  uart_rx_disable();
      
  if (status == HEX_DEC_CSERR)
  {
    printf("\nChecksum error: external FLASH memory is not programmed!\n");
    _DEAD_();
  }
  else     
    printf("\nExternal FLASH memory is now programmed.\n");    

  /* Happy end! */ 
  while(1);
}               

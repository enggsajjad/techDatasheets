/*H***************************************************************************
* NAME: isp.h           
*----------------------------------------------------------------------------
* PURPOSE: Header file shared by all ISP C files. 
*****************************************************************************/

#ifndef _ISP_H_
#define _ISP_H_

/* Uart */
extern Uchar nb_rx_data;
void  uart_init(void);
void  uart_rx_enable(void);
void  uart_rx_disable(void);
Bool  rx_buffer_empty(void);
Uchar rx_buffer_rd(void);

/* HEX file parser */
#define HEX_DEC_OK    0x01
#define HEX_DEC_END   0x02
#define HEX_DEC_CSERR 0x03
Uchar hex_parser (void);

/* FLASH API's*/
void flash_erase(void);
void flash_prog(Uint16, Uchar value);
Uint16 flash_id(void);

#endif /* _ISP_H_ */

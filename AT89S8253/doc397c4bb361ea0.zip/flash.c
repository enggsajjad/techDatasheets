/*C**************************************************************************
* NAME: flash.c  
*----------------------------------------------------------------------------
* PURPOSE: 
*****************************************************************************/

/*_____ I N C L U D E S ____________________________________________________*/

#include "config.h"
#include "isp.h"

/*F**************************************************************************
* NAME: flash_wr 
*----------------------------------------------------------------------------
* PARAMS:  
* addr: FLASH address location mapped in the external data area
* val: Data value to write to the FLASH.
*----------------------------------------------------------------------------
* PURPOSE: 
* Writes a byte to the FLASH memory when located in the external data area.
*****************************************************************************/
void flash_wr(Uchar xdata *addr, Uchar val)
{
  *addr = val;          /* addr is a pointer to external data mem */
}

/*F**************************************************************************
* NAME: flash_rd 
*----------------------------------------------------------------------------
* PARAMS:  
* addr: FLASH address location mapped in the external data area
* return: Byte value read from the FLASH memory 
*----------------------------------------------------------------------------
* PURPOSE: 
* Reads a byte from the FLASH memory when located in the external data area.
*****************************************************************************/
Uchar flash_rd(Uchar xdata *addr)
{  
  return *addr;  
}

/*F**************************************************************************
* NAME: flash_cmd 
*----------------------------------------------------------------------------
* PARAMS:  
* cmd: FLASH command used by the FLASH command sequence
*----------------------------------------------------------------------------
* PURPOSE: 
* Performs a FLASH command sequence (on-FLASH memory controller configuration) 
* The command is defined by the cmd code (erase, chip-id access, ...)
*****************************************************************************/
void flash_cmd(Uchar cmd)
{
  flash_wr(0x5555, 0xAA);
  flash_wr(0x2AAA, 0x55);
  flash_wr(0x5555, cmd);
} 

/*F**************************************************************************
* NAME: flash_erase 
*----------------------------------------------------------------------------
* PURPOSE: 
* Erases the entire FLASH memory. 
*****************************************************************************/
void flash_erase(void)
{
  Uchar pol_n, pol_n_1;

  /* Erase command sequence */
  flash_cmd(0x80);
  flash_cmd(0x10);
  
  /* Toggle bit algorithm: IO6 toggles each time a data read occurs */
  /* End of toggoling signals end of erase */  
  pol_n_1 = flash_rd(0x5555);
  pol_n   = flash_rd(0x5555);
  
  while ((pol_n ^ pol_n_1) == 0x40) /* Checks if bit6 has changed between 
                                       2 polls */
  {
    pol_n_1 = pol_n;
    pol_n   = flash_rd(0x5555);
  }
}

/*F**************************************************************************
* NAME: flash_prog 
*----------------------------------------------------------------------------
* PARAMS:  
* addr: FLASH address location mapped in the external data area
* val: Data value to program to the FLASH.
*----------------------------------------------------------------------------
* PURPOSE: 
* Programs one byte to the FLASH memory.
*****************************************************************************/
void flash_prog(Uint16 addr, Uchar value)
{                  
  /* Programming command */
  flash_cmd(0xA0);
  
  flash_wr(addr, value); 

  /* Wait until end of programming: IO7 is negated until end of programming */
  while (flash_rd(addr) != value);
} 

/*F**************************************************************************
* NAME: flash_id 
*----------------------------------------------------------------------------
* PARAMS:  
* return: FLASH memory manufacturer id and device id bytes.
*         MSB is Manufacturer Id and LSB Device Id.
*----------------------------------------------------------------------------
* PURPOSE: 
* Read the manufactuer and device Id's.
*****************************************************************************/
Uint16 flash_id()
{
  Uint16 flash_id=0;

  /* Product Id Entry mode */
  flash_cmd(0x90);    
  
  /* @0000: manufacturer, @0001: device */
  flash_id = flash_rd(0x0000) << 8 | flash_rd(0x0001);  

  /* Exit from Product Id */
  flash_cmd(0xF0);
    
  return flash_id;            
}










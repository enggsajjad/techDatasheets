/**
 * @file $RCSfile: t0_m2_t_gs.c,v $
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file is an example to use timer0 in mode 2.
 *
 * This file can be parsed by Doxygen for automatic documentation
 * generation.
 * Put here the functional description of this file within the software
 * architecture of your program.
 *
 * @version $Revision: 1.0.0 $ $Name:  $
 */
/*_____ M A C R O S ________________________________________________________*/

/**
 * This is a macro local to this file .
 */
#define reload_value 0x36 /* reload value exemple */


/* @section  I N C L U D E S */
#include "reg_c51.h"


/**
 * FUNCTION_PURPOSE: This file set up timer 0 in mode 2 (8 bits auto reload
 * timer) with a software gate.
 * The 8-bits register consist of all 8 bits of TL0 and all 8 bits   
 * of TH0 for the reload value.TH0 is loaded in TL0 at timer0 overflow.   
 * FUNCTION_INPUTS: void
 * FUNCTION_OUTPUTS: void
 */
void main(void)
{
	TMOD &= 0xF0;			      /* Timer 0 mode 2 with software gate */
	TMOD |= 0x02;              /* GATE0=0; C/T0#=0; M10=1; M00=0; */
	
	TL0 = reload_value;        /* init values */
	TH0 = reload_value;        /* reload value */		
	ET0=1;                     /* enable timer0 interrupt */
	EA=1;				            /* enable interrupts */
	TR0=1;			     	      /* timer0 run */
	while(1);				      /* endless  */
}


/**
 * FUNCTION_PURPOSE: timer0 interrupt
 * FUNCTION_INPUTS: void
 * FUNCTION_OUTPUTS: P1.0 toggle period = 2 * (256-reload_value) cycles  
 */
void it_timer0(void) interrupt 1 /* interrupt address is 0x000b */
{
	TF0 = 0;							/* reset  interrupt flag (already done by hardware)*/
	P1_0 = ~P1_0;					/* P1.0 toggle when interrupt. */
}

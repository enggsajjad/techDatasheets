/**
 * @file $RCSfile: t2_m1_t.c,v $
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file is an example to use timer2 in mode 1.
 *
 * This file can be parsed by Doxygen for automatic documentation
 * generation.
 * Put here the functional description of this file within the software
 * architecture of your program.
 *
 * @version $Revision: 1.0 $ $Name:  $
 */

/* @section  I N C L U D E S */
#include "reg_c51.h"
#include <stdio.h>


unsigned int RCAP2=0x0000;/*16 bits capture value*/
unsigned int nb_overflows=0x0000;/*number of overflow*/
unsigned int nb_overflows_old=0x0000;//previous number of overflow*/
unsigned int RCAP2H_16=0x0000;/*msb capture value on 16 bits*/

unsigned int RCAP2_old=0x0000;/*previous 16 bits capture value*/
unsigned int RCAP2H_old=0x0000;/*previous msb capture value on 16 bits*/
unsigned char RCAP2L_old=0x00;/*previous lsb capture value*/

unsigned char RCAP2H_tmp=0x00;/*temp lsb capture value*/
unsigned char RCAP2L_tmp=0x00;/*temp lsb capture value*/
char first_passage=1;
float value;/*time between two negatives transitions*/
char nb_samples=0;
/**
 * FUNCTION_PURPOSE: This file set up timer 2 in mode 0 (16 bits auto-reload
 * down counting timer).
 * The 16-bits register consist of all 8 bits of TH2 and all 8 bits   
 * of TL2.
 * FUNCTION_INPUTS: P1.1(T2EX) is a periodic signal : 50 us to 1 Hour
 * FUNCTION_OUTPUTS: void
 */
void main(void)
{

T2MOD &= 0xFC;			      /* T2OE=0;DCEN=0; */
T2MOD |= 0x00;			      

EXF2=0;                    /* reset flag */
TCLK=0;RCLK=0;             /* disable baud rate generator */
EXEN2=1;                   /* enable events detect on T2EX */ 
C_T2=0;                    /* timer mode */
CP_RL2=1;                  /* capture mode */
EA=1;                      /* interupt enable */
ET2=1;                     /* enable timer2 interrupt */
TR2=1;                     /* timer2 run */

while(1)/* main task */
{
   if(first_passage==1 && nb_samples>1)
   {
      first_passage=0;   
      RCAP2H_16=RCAP2H;/* convert 8 bits to 16 bits */
      RCAP2_old=((RCAP2H_old<<8)&0xFF00)|RCAP2L_old;
      RCAP2=((RCAP2H_16<<8)&0xFF00)|RCAP2L;
      value=RCAP2 + 0x10000 * nb_overflows_old - RCAP2_old;
      /* value = (signal period / cycle period) */
   }
}


}


/**
 * FUNCTION_PURPOSE: timer2 interrupt
 * FUNCTION_INPUTS: void
 * FUNCTION_OUTPUTS: void 
 */
void it_timer2(void) interrupt 5 /* interrupt address is 0x002b */
{
if(TF2) nb_overflows++;
if(EXF2)
{
   nb_samples++;
   RCAP2L_old=RCAP2L_tmp;
   RCAP2H_old=RCAP2H_tmp;
   RCAP2L_tmp=RCAP2L;
   RCAP2H_tmp=RCAP2H;
   nb_overflows_old=nb_overflows;//save number of overflow
   nb_overflows=0x0000;//reset number of overflow
   if(nb_samples>1) EXEN2=0;//end of capture
}
EXF2=0;                    /* reset flag */
TF2 = 0;							/* reset interrupt flag */
}


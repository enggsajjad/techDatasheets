/**
 * @file $RCSfile: TWI.c,v $
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file is an example to use Watchdog.
 *
 * This file can be parsed by Doxygen for automatic documentation
 * generation.
 * Put here the functional description of this file within the software
 * architecture of your program.
 *
 * @version $Revision: 1.0 $ $Name:  $
 */

/* @section  I N C L U D E S */
#include "reg_C51.h"

/**
 * FUNCTION_PURPOSE:this function setup Watchdog.
 * FUNCTION_INPUTS:void
 * FUNCTION_OUTPUTS:void
 */
void main(void)
{

/*
Selected Time-out

mode X1 12 clock periods per peripheral clock cycle.
mode X2  6 clock periods per peripheral clock cycle.

WDTPRG|=0x00   (2^14 - 1) machine cycles, 16. 3 ms @ FOSCA =12 MHz
WDTPRG|=0x01   (2^15 - 1) machine cycles, 32.7 ms @ FOSCA=12 MHz
WDTPRG|=0x02   (2^16 - 1) machine cycles, 65. 5 ms @ FOSCA=12 MHz
WDTPRG|=0x03   (2^17 - 1) machine cycles, 131 ms @ FOSCA=12 MHz
WDTPRG|=0x04   (2^18 - 1) machine cycles, 262 ms @ FOSCA=12 MHz
WDTPRG|=0x05   (2^19 - 1) machine cycles, 542 ms @ FOSCA=12 MHz
WDTPRG|=0x06   (2^20 - 1) machine cycles, 1.05 s @ FOSCA=12 MHz
WDTPRG|=0x07   (2^21 - 1) machine cycles, 2.09 s @ FOSCA=12 MHz

*/

WDTPRG|=0x07;/*2.275s @ FOSCA=11.059200 MHz */

/* watchdog start sequence */
WDTRST=0x1E;
WDTRST=0xE1;

while(1)                         /* end less */
{
/***********************************************
*                 PROGRAM                      *
************************************************/

   /* watchdog reset sequence */
   WDTRST=0x1E;
   WDTRST=0xE1;
}

}


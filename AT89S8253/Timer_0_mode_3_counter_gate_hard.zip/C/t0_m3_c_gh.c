/**
 * @file $RCSfile: t0_m3_c_gh.c,v $
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file is an example to use timer0 in mode 3.
 *
 * This file can be parsed by Doxygen for automatic documentation
 * generation.
 * Put here the functional description of this file within the software
 * architecture of your program.
 *
 * @version $Revision: 1.0 $ $Name:  $
 */

/* @section  I N C L U D E S */
#include "reg_c51.h"


/**
 * FUNCTION_PURPOSE: This file set up timer 0 in mode 3 (Split Timer/counter)
 * with a hardware gate.When timer 0 is placed in this mode, it essentially
 * becomes two separate 8-bits timers.
 * One consist of TL0 (8bits counter) and can be gated by software 
 * The other consist of TH0 (8bits),is always in timer mode and cannot be gated.
 * TR0 bit is used to run TL0 and TR1 bit is used to run TH0 and timer1 always running.
 * You can use this mode if you need to have two separate timers and,
 * additionally,a baud rate generator.In such case you can use the timer1 as baud
 * rate generator and use TH0/TL0 as two separate timers.
 * FUNCTION_INPUTS: P3.2(INT0)=1 : GATE Input
 *                  P3.4(T0) must be controlled by an external clock
 * FUNCTION_OUTPUTS: void
 */
void main(void)
{
	TMOD &= 0xF0;			      /* Timer 0 mode 3 with hardware gate */
	TMOD |= 0x0F;              /* GATE0=1; C/T0#=1; M10=1; M00=1; */
	
	TH0 = 0x00;			         /* init values */
	TL0 = 0x00;		
	ET0=1;                     /* enable timer0 interrupt */
	ET1=1;                     /* enable timer1 interrupt */
	EA=1;				            /* enable interrupts */
	TR0=1;			     	      /* run TL0 */
	TR1=1;			     	      /* run TH0 */

	while(1);				      /* endless  */
}


/**
 * FUNCTION_PURPOSE: timer0 interrupt
 * FUNCTION_INPUTS: void
 * FUNCTION_OUTPUTS: P1.0 toggle period = 2 * 8192 * P3.4(T0) period  
 */
void it_timer0(void) interrupt 1 /* interrupt address is 0x000b */
{
	TF0 = 0;							/* reset  interrupt flag (already done by hardware)*/
	P1_0 = ~P1_0;					/* P1.0 toggle when interrupt. */
}


/**
 * FUNCTION_PURPOSE: timer1 interrupt is set at TH0 overflow and not influenced by TH1
 * FUNCTION_INPUTS: void
 * FUNCTION_OUTPUTS: P1.1 toggle period = 2 * 8192 cycles  
 */
void it_timer1(void) interrupt 3 /* interrupt address is 0x001b */
{
	TF1 = 0;							/* reset  interrupt flag (already done by hardware)*/
	P1_1 = ~P1_1;					/* P1.1 toggle when interrupt. */
}

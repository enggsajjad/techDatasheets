/**
 * @file $RCSfile: t2_m0_c.c,v $
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file is an example to use timer2 in mode 0.
 *
 * This file can be parsed by Doxygen for automatic documentation
 * generation.
 * Put here the functional description of this file within the software
 * architecture of your program.
 *
 * @version $Revision: 1.0.0 $ $Name:  $
 */
/*_____ M A C R O S ________________________________________________________*/

/**
 * This is a macro local to this file .
 */
#define MSB_reload_value 0x36 /* msb reload value exemple */
#define LSB_reload_value 0x36 /* lsb reload value exemple */


/* @section  I N C L U D E S */
#include "reg_c51.h"


/**
 * FUNCTION_PURPOSE: This file set up timer 2 in mode 0 (16 bits auto-reload
 * up/down counter).
 * The 16-bits register consist of all 8 bits of TH2 and all 8 bits   
 * of TL2. The EXF2 bit toggles when timer2 overflow or underflow occurs.
 * EXF2 does not generate interrupt. This bit can be used to provide 17-bit resolution   
 * FUNCTION_INPUTS: P1.0(T2) must be controlled by an external clock 
 *                  P1.1(T2EX)=0 for down counting or 1 for up counting.
 * FUNCTION_OUTPUTS: void
 */
void main(void)
{
T2MOD &= 0xFC;			      /* T2OE=0;DCEN=1; */
T2MOD |= 0x01;			      

EXF2=0;                    /* reset flag */
TCLK=0;RCLK=0;             /* disable baud rate generator */
EXEN2=0;                   /* ignore events on T2EX */ 
TH2=MSB_reload_value;		/* Init msb_value */
TL2=LSB_reload_value;		/* Init lsb_value */
RCAP2H=MSB_reload_value;	/* reload msb_value */
RCAP2L=LSB_reload_value;	/* reload lsb_value */
C_T2=1;                    /* counter mode */
CP_RL2=0;                  /* reload mode */
EA=1;                      /* interupt enable */
ET2=1;                     /* enable timer2 interrupt */
TR2=1;                     /* timer2 run */

while(1);				      /* endless  */
}


/**
 * FUNCTION_PURPOSE: timer2 interrupt
 * FUNCTION_INPUTS: void
 * FUNCTION_OUTPUTS: P1.2 toggle period = 2 * (65536-reload_value) * P1.0(T2) period 
 */
void it_timer2(void) interrupt 5 /* interrupt address is 0x002b */
{
   P1_2 = ~P1_2;					/* P1.2 toggle when interrupt. */
	TF2 = 0;							/* reset interrupt flag */
}

/**
 * @file $RCSfile: t2_m2.c,v $
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file is an example to use timer2 in mode 2.
 *
 * This file can be parsed by Doxygen for automatic documentation
 * generation.
 * Put here the functional description of this file within the software
 * architecture of your program.
 *
 * @version $Revision: 1.0.0 $ $Name:  $
 */
/*_____ M A C R O S ________________________________________________________*/

/**
 * This is a macro local to this file .
 */
#define MSB_reload_value 0x36 /* msb reload value exemple */
#define LSB_reload_value 0x36 /* lsb reload value exemple */


/* @section  I N C L U D E S */
#include "reg_c51.h"


/**
 * FUNCTION_PURPOSE: This file set up timer 2 in mode 1 (clock-out mode and 
 * negative transition detector).
 * The 16-bits register consist of all 8 bits of TH2 and all 8 bits of TL2.
 * TF2 does not generate interrupt.   
 * A negative transition on P1.1(T2EX) generate an interrupt.
 * FUNCTION_INPUTS: void
 * FUNCTION_OUTPUTS: P1.0(T2) as clock output : Fout = Fperiph / (2*(65536-RCAP2)).
 */
void main(void)
{
T2MOD &= 0xFE;			      /* T2OE=1;DCEN=0; */
T2MOD |= 0x02;			      
EXF2=0;                    /* reset flag */
TCLK=0;RCLK=0;             /* disable baud rate generator */
EXEN2=1;                   /* enable events on T2EX */ 
TH2=MSB_reload_value;		/* Init msb_value */
TL2=LSB_reload_value;		/* Init lsb_value */
RCAP2H=MSB_reload_value;	/* reload msb_value */
RCAP2L=LSB_reload_value;	/* reload lsb_value */
C_T2=0;                    /* timer mode */
CP_RL2=0;                  /* reload mode */
EA=1;                      /* interupt enable */
ET2=1;                     /* enable timer2 interrupt */
TR2=1;                     /* timer2 run */

while(1);				      /* endless  */
}


/**
 * FUNCTION_PURPOSE: timer2 interrupt
 * FUNCTION_INPUTS: void
 * FUNCTION_OUTPUTS: P1.2 toggle period = 2 *  P1.1(T2EX) period 
 */
void it_timer2(void) interrupt 5 /* interrupt address is 0x002b */
{
   P1_2 = ~P1_2;					   /* P1.2 toggle when interrupt. */
	EXF2 = 0;							/* reset interrupt flag */
}

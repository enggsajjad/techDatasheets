#include "serial.h"

void print_hexbyte(unsigned char i);
void delay(char d);


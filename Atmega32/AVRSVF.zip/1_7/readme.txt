AVRsvf v.1.7
2007 (c) Atmel Corporation

This is a commandline software that can be used to generate Serial Vector Format (SVF) files.

Use the -h option for a list of available options and examples of use. 

Visit http://www.atmel.com to get a copy of the latest version of this software.
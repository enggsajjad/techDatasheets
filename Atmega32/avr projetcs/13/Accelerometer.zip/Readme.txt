All of the files included in Accelerometter.zip file are downloaded from http://www.serasidis.gr
and are property of Michalis karaoglanidis  

email: icarus1@in.gr



+-------------------------------+
| (c) 2004 by Serasidis Vasilis |
|     http:www.serasidis.gr     |
|     info@serasidis.gr         |
+-------------------------------+
This source code is designed for any standard C++ compiler.

Tested with Cygwin G++: 'g++ -o update.exe *.cpp'
Tested with Bloodshed Dev-C++ 4.9.9.0 (http://www.bloodshed.net/devcpp.html)

A compiled version resides in 'pctools' directory.
Compiled with Bloodshed Dev-C++ 4.9.9.0

To port the code to other platforms, e.g. Linux, modify the serial port code.


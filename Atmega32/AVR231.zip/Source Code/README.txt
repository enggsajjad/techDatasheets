Read the README.txt files in the IAR and PC subdirectories.

Atmel Microcontroller IBIS models
=================================
The IBIS (I/O Buffer Information Specification) is an international standard for the
electrical specification of chip drivers and receivers. It provides a standard for
recording parameters like driver output impedance, rise/fall time, and input loading.
Note that there are different libraries for each AVR family of microcontrollers.
The files can be found on http://www.atmel.com.

Naming convention
-----------------
IBIS development software requires the name of the IBIS model to be in DOS8.3 format,
all lowercase. The resulting file names may be somewhat cryptic.

A guide to their interpretation follows:

Example:

  Temperature span is always -55/27/125 degrees Celsius. 
  ATmega169 @ 3.3V (10%) in TQFP64.

    m1693t64.ibs
    ||  |||
    ||  |||Number of package pins. This can be 1-2 figures long.
    ||  ||  Note! A 100-pin package is "00", 208 is "08", i.e. the
    ||  ||  leading zero is NOT deleted in this case.
    ||  ||
    ||  ||Type of package: t = TQFP
    ||  |                  m = MLF
    ||  |                  p = PDIP
    ||  |                  s = SOIC
    ||  |                  o = SOP
    ||  |                  l = PLCC
    ||  |
    ||  |Supply voltage: 2 = 1.8V/2.0V/2.2V
    ||                   3 = 3.0V/3.3V/3.6V 
    ||                   5 = 4.5V/5.0V/5.5V
    ||
    ||Microcontroller number. This can be 1-3 figures long.
    |  Note! Check device numbers >3 figures long below !
    |
    |  X-ref:(ATmega) 1280 = 280
    |        (ATmega) 1281 = 281
    |        (ATmega) 2560 = 560
    |        (ATmega) 2561 = 561
    |        (ATmega) 3250 = 250
    |        (ATmega) 6450 = 450
    |        (ATmega) 3290 = 290
    |        (ATmega) 6490 = 490
    |        (ATmega) 8515 = 851
    |        (ATmega) 8535 = 853
    |
    |        (ATtiny) 2313 =  23
    |
    |
    |Microcontroller family: m = ATmega
                             t = ATtiny

Rise/Fall curves - 50/2000 ohm load
-----------------------------------
These models contain Rise/Fall curves for both 50 ohms and 2000 ohms load
(previously only 2000 ohms). While the 50 ohm curves are indeed recommended
by the IBIS standard (to be included if load >100 ohms) and give valuable
information about output impedance, they will report errors at 2 volts and 50 ohms 
if run through a utility like IBISCHK. Note that this is not due to an error in the model, 
but operation outside the drive capability of the circuit.

===================================
Atmel Norway, June 2006, Lars Snith

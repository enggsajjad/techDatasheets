/*****************************************************************
* File: defines.h
* 
* revision and date: 
*       1.0: 2002.11.04
*
* Author: JLL
*
* Description:
*        General project header file
*
*****************************************************************/
#include <inavr.h>
#include <ioavr.h>

#define TRUE  1
#define FALSE 0
